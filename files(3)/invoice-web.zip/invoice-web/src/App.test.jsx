import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import App from './App.jsx';
import { sessionStore } from './session.js';

describe('App', () => {
  beforeEach(() => {
    sessionStore.clear();
    window.location.hash = '#/signin';
  });

  it('shows the sign-in screen to people who are not signed in', () => {
    render(<App />);
    expect(screen.getByRole('heading', { name: 'Sign in' })).toBeTruthy();
    expect(screen.getByLabelText(/Phone number/)).toBeTruthy();
  });
});
