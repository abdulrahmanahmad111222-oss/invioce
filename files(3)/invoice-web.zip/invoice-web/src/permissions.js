// Mirrors the server's matrix so the interface only offers what the server will accept.
// The server is the real check; this only hides buttons.
const ALL = [
  'billing.manage', 'members.invite', 'members.manage', 'settings.payouts', 'integrations.manage', 'billing.view',
  'invoices.view', 'invoices.create', 'invoices.edit', 'invoices.void',
  'payments.record', 'payments.refund', 'reports.view', 'audit.view'
];

export const PERMISSIONS = {
  owner: ALL,
  admin: ALL.filter((p) => p !== 'billing.manage'),
  manager: ['invoices.view', 'invoices.create', 'invoices.edit', 'invoices.void', 'payments.record', 'payments.refund', 'reports.view', 'audit.view'],
  staff: ['invoices.view', 'invoices.create', 'invoices.edit', 'payments.record'],
  accountant: ['invoices.view', 'reports.view', 'audit.view', 'billing.view']
};

export const ROLE_RANK = { owner: 5, admin: 4, manager: 3, staff: 2, accountant: 2 };
export const ASSIGNABLE_ROLES = ['admin', 'manager', 'staff', 'accountant'];

export function can(role, permission) {
  return Object.hasOwn(PERMISSIONS, role) && PERMISSIONS[role].includes(permission);
}

// Roles this person may invite or give to someone else.
export function grantableRoles(role) {
  return ASSIGNABLE_ROLES.filter((r) => ROLE_RANK[r] < (ROLE_RANK[role] ?? 0));
}
