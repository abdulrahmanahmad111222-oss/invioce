// Hash routing: #/b/<businessId>/invoices, #/join?token=..., and so on.
export function parseRoute(hash) {
  const raw = (hash || '').replace(/^#/, '') || '/';
  const [path, query = ''] = raw.split('?');
  return { parts: path.split('/').filter(Boolean), query: new URLSearchParams(query), path: path || '/' };
}

export function go(path) {
  window.location.hash = path;
}
