import { describe, it, expect } from 'vitest';
import { naira, invoiceNo, whatsappLink } from './format.js';

describe('format', () => {
  it('formats kobo as naira with two decimals', () => {
    expect(naira(150000)).toBe('₦1,500.00');
    expect(naira(0)).toBe('₦0.00');
    expect(naira(undefined)).toBe('₦0.00');
  });

  it('numbers invoices with four digits', () => {
    expect(invoiceNo(7)).toBe('INV-0007');
  });

  it('builds a WhatsApp link with the message encoded', () => {
    expect(whatsappLink('2348012345678', 'Pay here: https://x.test/pay/a b')).toBe(
      'https://wa.me/2348012345678?text=Pay%20here%3A%20https%3A%2F%2Fx.test%2Fpay%2Fa%20b'
    );
  });
});
