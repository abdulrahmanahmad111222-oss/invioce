export function Notice({ kind = 'info', children }) {
  return <div className={`notice ${kind}`} role={kind === 'error' ? 'alert' : 'status'}>{children}</div>;
}

export function Button({ variant = 'primary', className = '', ...props }) {
  return <button className={`btn ${variant} ${className}`.trim()} {...props} />;
}

export function Field({ label, children, hint }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {hint && <small className="muted">{hint}</small>}
    </label>
  );
}

export function StatusPill({ status }) {
  const cls = { Unpaid: 'due', 'Partly paid': 'part', Paid: 'paid', Void: 'void' }[status] ?? 'due';
  return <span className={`pill ${cls}`}>{status}</span>;
}
