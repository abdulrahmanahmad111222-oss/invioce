import { go } from '../nav.js';
import { can } from '../permissions.js';

// A tab is current when the URL starts with its path.
function Tab({ href, children }) {
  const current = window.location.hash.startsWith(href) ? 'active' : undefined;
  return <a href={href} className={current} aria-current={current ? 'page' : undefined}>{children}</a>;
}

export default function Frame({ session, business, role, children }) {
  return (
    <div className="frame">
      <header className="top">
        <a className="brand" href="#/businesses"><span className="brand-mark" aria-hidden="true">₦</span>Invoices</a>
        {business && <strong className="biz">{business.name}</strong>}
        <div className="spacer" />
        {session.signedIn && <button className="linkish" onClick={session.onSignOut}>Sign out</button>}
      </header>
      {business && role && (
        <nav className="tabs" aria-label="Business">
          {can(role, 'invoices.view') && <Tab href={`#/b/${business.id}/invoices`}>Invoices</Tab>}
          {can(role, 'members.manage') && <Tab href={`#/b/${business.id}/team`}>Team</Tab>}
          {can(role, 'billing.view') && <Tab href={`#/b/${business.id}/billing`}>Billing</Tab>}
          {(can(role, 'integrations.manage') || can(role, 'audit.view')) && <Tab href={`#/b/${business.id}/settings`}>Settings</Tab>}
          <button className="linkish" onClick={() => go('/businesses')}>All businesses</button>
        </nav>
      )}
      <main className="content">{children}</main>
    </div>
  );
}
