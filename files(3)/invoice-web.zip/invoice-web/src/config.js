// Set these in .env.local for the web app.
export const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000';
export const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID ?? '';
