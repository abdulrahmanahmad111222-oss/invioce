import { API_URL } from './config.js';
import { sessionStore } from './session.js';

export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// Every request goes through here. Errors carry the server's message, which is written for people.
export function createApi(baseUrl, getToken) {
  async function request(method, path, body) {
    const headers = { 'content-type': 'application/json' };
    const token = getToken();
    if (token) headers.authorization = `Bearer ${token}`;
    const res = await fetch(baseUrl + path, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body)
    });
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
    if (!res.ok) throw new ApiError(res.status, data?.error ?? `Something went wrong (${res.status}).`);
    return data;
  }
  return {
    get: (path) => request('GET', path),
    post: (path, body = {}) => request('POST', path, body),
    patch: (path, body = {}) => request('PATCH', path, body),
    del: (path) => request('DELETE', path)
  };
}

export const api = createApi(API_URL, () => sessionStore.get());
