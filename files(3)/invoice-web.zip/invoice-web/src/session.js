const KEY = 'inv_token';

export const sessionStore = {
  get: () => window.localStorage.getItem(KEY),
  set: (token) => window.localStorage.setItem(KEY, token),
  clear: () => window.localStorage.removeItem(KEY)
};
