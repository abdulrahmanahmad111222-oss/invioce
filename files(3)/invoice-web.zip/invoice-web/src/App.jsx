import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import { sessionStore } from './session.js';
import { parseRoute, go } from './nav.js';
import { SignIn, Join } from './pages/Auth.jsx';
import Businesses from './pages/Businesses.jsx';
import BusinessShell from './pages/BusinessShell.jsx';

export default function App() {
  const [hash, setHash] = useState(window.location.hash);
  const [signedIn, setSignedIn] = useState(Boolean(sessionStore.get()));
  const [memberships, setMemberships] = useState(null);
  const [me, setMe] = useState(null);

  useEffect(() => {
    const onHash = () => setHash(window.location.hash);
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const reload = useCallback(async () => {
    if (!sessionStore.get()) return;
    try {
      setMemberships(await api.get('/me/businesses'));
    } catch (e) {
      if (e.status === 401) { sessionStore.clear(); setSignedIn(false); }
    }
  }, []);

  useEffect(() => {
    if (!signedIn) return;
    reload();
    api.get('/me').then(setMe).catch(() => {});
  }, [signedIn, reload]);

  const session = {
    signedIn,
    me,
    memberships,
    reload,
    onSignedIn: () => setSignedIn(true),
    onSignOut: async () => {
      try { await api.post('/auth/logout'); } catch { /* the token may already be gone */ }
      sessionStore.clear();
      setSignedIn(false);
      setMemberships(null);
      go('/signin');
    }
  };

  const { parts, query, path } = parseRoute(hash);

  if (parts[0] === 'join') {
    return <Shell><Join token={query.get('token')} session={session} /></Shell>;
  }
  if (!signedIn) {
    const next = path === '/signin' || path === '/' ? '/businesses' : path + (hash.includes('?') ? '?' + hash.split('?')[1] : '');
    return <Shell><SignIn next={next} onSignedIn={session.onSignedIn} /></Shell>;
  }
  if (parts[0] === 'b' && parts[1]) {
    return <BusinessShell session={session} bizId={parts[1]} section={parts.slice(2)} />;
  }
  return <Businesses session={session} />;
}

function Shell({ children }) {
  return <div className="auth-shell">{children}</div>;
}
