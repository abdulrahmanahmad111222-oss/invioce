import { describe, it, expect, vi, afterEach } from 'vitest';
import { createApi, ApiError } from './api.js';

describe('API client', () => {
  afterEach(() => vi.restoreAllMocks());

  it('sends the bearer token and parses JSON', async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({ ok: true }), { status: 200 }));
    vi.stubGlobal('fetch', fetchMock);
    const api = createApi('https://api.test', () => 'tok-123');
    const data = await api.get('/me/businesses');
    expect(data).toEqual({ ok: true });
    expect(fetchMock.mock.calls[0][1].headers.authorization).toBe('Bearer tok-123');
    vi.unstubAllGlobals();
  });

  it('turns server errors into ApiError with the server message', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'your plan allows 2 team members' }), { status: 402 })));
    const api = createApi('https://api.test', () => null);
    const err = await api.post('/x', {}).catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err.status).toBe(402);
    expect(err.message).toBe('your plan allows 2 team members');
    vi.unstubAllGlobals();
  });

  it('does not send an authorization header when signed out', async () => {
    const fetchMock = vi.fn(async () => new Response('', { status: 200 }));
    vi.stubGlobal('fetch', fetchMock);
    await createApi('https://api.test', () => null).get('/x');
    expect(fetchMock.mock.calls[0][1].headers.authorization).toBeUndefined();
    vi.unstubAllGlobals();
  });
});
