// Amounts from the API are kobo (1 naira = 100 kobo).
export const naira = (kobo) =>
  '₦' + (Number(kobo ?? 0) / 100).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const invoiceNo = (n) => 'INV-' + String(n).padStart(4, '0');

export const ROLE_LABELS = { owner: 'Owner', admin: 'Admin', manager: 'Manager', staff: 'Staff', accountant: 'Accountant' };

export const PLAN_NAMES = { starter: 'Starter', growth: 'Growth', scale: 'Scale' };

export const STATE_LABELS = {
  trial: 'Free trial',
  active: 'Active',
  cancelled: 'Cancelled (ends at period end)',
  past_due: 'Payment failed (grace period)',
  expired: 'Expired',
  none: 'No subscription'
};

// 234XXXXXXXXXX -> wa.me digits
export const whatsappLink = (phone, text) => `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
