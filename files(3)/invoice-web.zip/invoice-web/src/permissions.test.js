import { describe, it, expect } from 'vitest';
import { can, grantableRoles } from './permissions.js';

describe('permissions in the interface', () => {
  it('matches the server for the rules that matter most', () => {
    expect(can('owner', 'billing.manage')).toBe(true);
    expect(can('admin', 'billing.manage')).toBe(false);
    expect(can('staff', 'payments.refund')).toBe(false);
    expect(can('manager', 'payments.refund')).toBe(true);
    expect(can('accountant', 'invoices.create')).toBe(false);
    expect(can('hacker', 'invoices.view')).toBe(false);
  });

  it('offers only roles below the person\'s own', () => {
    expect(grantableRoles('owner')).toEqual(['admin', 'manager', 'staff', 'accountant']);
    expect(grantableRoles('admin')).toEqual(['manager', 'staff', 'accountant']);
    expect(grantableRoles('staff')).toEqual([]);
  });
});
