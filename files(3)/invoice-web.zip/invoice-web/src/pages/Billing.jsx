import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { can } from '../permissions.js';
import { naira, PLAN_NAMES, STATE_LABELS } from '../format.js';
import { Notice, Button, Field } from '../components/ui.jsx';

export default function Billing({ bizId, role }) {
  const [sub, setSub] = useState(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [email, setEmail] = useState('');

  const load = () => api.get(`/businesses/${bizId}/subscription`).then(setSub).catch((e) => setError(e.message));
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [bizId]);

  async function buy(plan, interval) {
    setError(''); setNote('');
    try {
      const r = await api.post(`/businesses/${bizId}/subscription/checkout`, { plan, interval, email });
      window.location.href = r.authorizationUrl;
    } catch (e) { setError(e.message); }
  }

  async function cancel() {
    if (!window.confirm('Cancel the subscription? You keep access until the period ends.')) return;
    setError(''); setNote('');
    try {
      const r = await api.post(`/businesses/${bizId}/subscription/cancel`);
      setNote(`Cancelled. Access continues until ${new Date(r.accessUntil).toLocaleDateString('en-NG')}.`);
      await load();
    } catch (e) { setError(e.message); }
  }

  if (error && !sub) return <Notice kind="error">{error}</Notice>;
  if (!sub) return <p>Loading…</p>;

  const owner = can(role, 'billing.manage');
  const { usage, limits } = sub;

  return (
    <div>
      <h1>Billing</h1>
      {error && <Notice kind="error">{error}</Notice>}
      {note && <Notice kind="ok">{note}</Notice>}

      {sub.state === 'expired' && <Notice kind="error">Your subscription has ended. You can still view and receive payments, but new work is paused until you renew.</Notice>}
      {sub.state === 'past_due' && <Notice kind="error">A renewal payment failed. Renew before {new Date(sub.graceUntil).toLocaleDateString('en-NG')} to keep your account open.</Notice>}

      <dl className="summary">
        <dt>Status</dt><dd>{STATE_LABELS[sub.state] ?? sub.state}</dd>
        {sub.plan && <><dt>Plan</dt><dd>{PLAN_NAMES[sub.plan]} ({sub.interval})</dd></>}
        {sub.periodEnd && <><dt>Current period ends</dt><dd>{new Date(sub.periodEnd).toLocaleDateString('en-NG')}</dd></>}
        <dt>Team members</dt><dd>{usage.members} of {limits.members ?? '∞'}</dd>
        <dt>Invoices this month</dt><dd>{usage.invoicesThisMonth} of {limits.invoicesPerMonth ?? '∞'}</dd>
        <dt>Gmail sending</dt><dd>{limits.gmail ? 'Included' : 'Not in this plan'}</dd>
      </dl>

      <h2>Plans</h2>
      {!owner && <p className="muted">Only the owner can change the subscription.</p>}
      {owner && (
        <Field label="Email for receipts" hint="Paystack sends the payment receipt here.">
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </Field>
      )}
      <div className="plans">
        {sub.plans.map((p) => (
          <div className="plan card" key={p.key}>
            <h3>{p.name}</h3>
            <p className="price">{naira(p.prices.monthly)} <span className="muted">/ month</span></p>
            <p className="muted">or {naira(p.prices.yearly)} / year</p>
            <ul>
              <li>{p.limits.members} team members</li>
              <li>{p.limits.invoicesPerMonth ?? 'Unlimited'} invoices a month</li>
              <li>{p.limits.gmail ? 'Gmail sending' : 'No Gmail sending'}</li>
            </ul>
            {owner && (
              <div className="row">
                <Button disabled={!email} onClick={() => buy(p.key, 'monthly')}>Monthly</Button>
                <Button variant="ghost" disabled={!email} onClick={() => buy(p.key, 'yearly')}>Yearly</Button>
              </div>
            )}
          </div>
        ))}
      </div>

      {owner && sub.state !== 'none' && sub.state !== 'cancelled' && (
        <div className="danger-zone"><Button variant="danger" onClick={cancel}>Cancel subscription</Button></div>
      )}
    </div>
  );
}
