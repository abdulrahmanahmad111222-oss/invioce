import { useEffect, useState } from 'react';
import { api } from '../../api.js';
import { can } from '../../permissions.js';
import { naira, invoiceNo } from '../../format.js';
import { Notice, Button, StatusPill } from '../../components/ui.jsx';

export default function InvoiceList({ bizId, role }) {
  const [invoices, setInvoices] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get(`/businesses/${bizId}/invoices`).then(setInvoices).catch((e) => setError(e.message));
  }, [bizId]);

  return (
    <div>
      <div className="row between">
        <h1>Invoices</h1>
        {can(role, 'invoices.create') && <Button onClick={() => { window.location.hash = `/b/${bizId}/invoices/new`; }}>New invoice</Button>}
      </div>
      {error && <Notice kind="error">{error}</Notice>}
      {!invoices && !error && <p>Loading…</p>}
      {invoices?.length === 0 && (
        <div className="empty">
          <strong>No invoices yet</strong>
          {can(role, 'invoices.create') ? 'Create your first invoice and send it to a customer on WhatsApp or email.' : 'Invoices your team creates will appear here.'}
        </div>
      )}
      {invoices?.length > 0 && (
        <div className="scroll">
          <table>
            <thead><tr><th>Number</th><th>Client</th><th className="r">Total</th><th className="r">Balance</th><th>Status</th></tr></thead>
            <tbody>
              {invoices.map((inv) => (
                <tr key={inv.no}>
                  <td data-label="Number"><a href={`#/b/${bizId}/invoices/${inv.no}`}>{invoiceNo(inv.no)}</a></td>
                  <td data-label="Client">{inv.client}</td>
                  <td data-label="Total" className="r">{naira(inv.total)}</td>
                  <td data-label="Balance" className="r">{naira(Math.max(inv.total - inv.paid, 0))}</td>
                  <td data-label="Status"><StatusPill status={inv.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
