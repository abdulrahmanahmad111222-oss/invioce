import { useEffect, useState } from 'react';
import { api } from '../../api.js';
import { can } from '../../permissions.js';
import { naira, invoiceNo, whatsappLink } from '../../format.js';
import { Notice, Button, StatusPill } from '../../components/ui.jsx';
import { API_URL } from '../../config.js';

export default function InvoiceDetail({ bizId, role, no }) {
  const [inv, setInv] = useState(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const load = () => api.get(`/businesses/${bizId}/invoices/${no}`).then(setInv).catch((e) => setError(e.message));
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [bizId, no]);

  async function run(action) {
    setError(''); setNote(''); setBusy(true);
    try { await action(); await load(); } catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  if (error && !inv) return <Notice kind="error">{error}</Notice>;
  if (!inv) return <p>Loading…</p>;

  const payUrl = `${API_URL}/pay/${inv.paymentReference}`;
  const balance = Math.max(inv.total - inv.paid, 0);
  const shareText = `Invoice ${invoiceNo(inv.no)} is ready. Total ${naira(inv.total)}. Pay here: ${payUrl}`;

  return (
    <div>
      <div className="row between">
        <h1>{invoiceNo(inv.no)}</h1>
        <StatusPill status={inv.status} />
      </div>
      <p className="muted">{inv.client}{inv.clientEmail ? ` · ${inv.clientEmail}` : ''}{inv.due ? ` · Due ${inv.due}` : ''}</p>

      {error && <Notice kind="error">{error}</Notice>}
      {note && <Notice kind="ok">{note}</Notice>}

      <div className="scroll">
        <table>
          <thead><tr><th>Item</th><th className="r">Qty</th><th className="r">Price</th></tr></thead>
          <tbody>
            {inv.lines.map((l, i) => (
              <tr key={i}><td data-label="Item">{l.desc}</td><td data-label="Qty" className="r">{l.qty}</td><td data-label="Price" className="r">{naira(Math.round(l.qty * l.price * 100))}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <dl className="summary card-summary">
        <dt>Subtotal</dt><dd>{naira(inv.subtotal)}</dd>
        {inv.vat && <><dt>VAT 7.5%</dt><dd>{naira(inv.tax)}</dd></>}
        <dt>Total</dt><dd>{naira(inv.total)}</dd>
        <dt>Paid</dt><dd>{naira(inv.paid)}</dd>
        <dt><strong>Balance</strong></dt><dd><strong>{naira(balance)}</strong></dd>
      </dl>

      <h2>Share</h2>
      <div className="row">
        <a className="btn ghost" href={whatsappLink(inv.phone, shareText)} target="_blank" rel="noopener">Send on WhatsApp</a>
        <Button variant="ghost" onClick={() => { navigator.clipboard?.writeText(payUrl); setNote('Payment link copied.'); }}>Copy payment link</Button>
        {inv.clientEmail && can(role, 'invoices.create') && inv.status !== 'Void' && (
          <Button variant="ghost" disabled={busy} onClick={() => run(async () => { await api.post(`/businesses/${bizId}/invoices/${no}/email`); setNote('Invoice emailed.'); })}>
            Email to client
          </Button>
        )}
      </div>

      {can(role, 'invoices.void') && inv.status !== 'Void' && inv.paid === 0 && (
        <div className="danger-zone">
          <Button variant="danger" disabled={busy} onClick={() => {
            if (window.confirm(`Cancel ${invoiceNo(inv.no)}? This can't be undone.`)) {
              run(async () => { await api.post(`/businesses/${bizId}/invoices/${no}/void`); setNote('Invoice cancelled.'); });
            }
          }}>Cancel invoice</Button>
        </div>
      )}
      <p className="muted small">Customers pay at {payUrl}</p>
    </div>
  );
}
