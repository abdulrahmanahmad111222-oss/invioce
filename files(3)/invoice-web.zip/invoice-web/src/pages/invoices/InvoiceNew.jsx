import { useState } from 'react';
import { api } from '../../api.js';
import { Notice, Button, Field } from '../../components/ui.jsx';

const blankLine = () => ({ desc: '', qty: 1, price: '' });

export default function InvoiceNew({ bizId }) {
  const [form, setForm] = useState({ client: '', clientEmail: '', phone: '', due: '', vat: true });
  const [lines, setLines] = useState([{ desc: 'Logo design', qty: 1, price: '150000' }]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const setLine = (i, k, v) => setLines(lines.map((l, j) => (j === i ? { ...l, [k]: v } : l)));

  // Prices are entered in naira. The API takes naira too.
  const subtotal = lines.reduce((sum, l) => sum + (Number(l.qty) || 0) * (Number(l.price) || 0), 0);
  const tax = form.vat ? subtotal * 0.075 : 0;

  async function submit(e) {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      const inv = await api.post(`/businesses/${bizId}/invoices`, {
        client: form.client,
        clientEmail: form.clientEmail || undefined,
        phone: form.phone,
        due: form.due || undefined,
        vat: form.vat,
        lines: lines.map((l) => ({ desc: l.desc, qty: Number(l.qty), price: Number(l.price) }))
      });
      window.location.hash = `/b/${bizId}/invoices/${inv.no}`;
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  return (
    <div>
      <h1>New invoice</h1>
      {error && <Notice kind="error">{error}</Notice>}
      <form onSubmit={submit} className="stack">
        <div className="grid2">
          <Field label="Client name"><input value={form.client} onChange={set('client')} required /></Field>
          <Field label="Client WhatsApp number"><input inputMode="tel" value={form.phone} onChange={set('phone')} placeholder="08012345678" required /></Field>
          <Field label="Client email" hint="Needed to email the invoice. Optional."><input type="email" value={form.clientEmail} onChange={set('clientEmail')} /></Field>
          <Field label="Due date"><input type="date" value={form.due} onChange={set('due')} /></Field>
        </div>

        <h2>Items</h2>
        {lines.map((l, i) => (
          <div className="line" key={i}>
            <input aria-label="Description" placeholder="Description" value={l.desc} onChange={(e) => setLine(i, 'desc', e.target.value)} required />
            <input aria-label="Quantity" type="number" min="1" value={l.qty} onChange={(e) => setLine(i, 'qty', e.target.value)} required />
            <input aria-label="Unit price in naira" type="number" min="1" step="any" value={l.price} onChange={(e) => setLine(i, 'price', e.target.value)} required />
            <button type="button" className="linkish" disabled={lines.length === 1} onClick={() => setLines(lines.filter((_, j) => j !== i))} aria-label="Remove item">×</button>
          </div>
        ))}
        <Button type="button" variant="ghost" onClick={() => setLines([...lines, blankLine()])}>Add item</Button>

        <label className="check"><input type="checkbox" checked={form.vat} onChange={set('vat')} /> Add 7.5% VAT</label>
        <p className="totals">Subtotal ₦{subtotal.toLocaleString('en-NG', { minimumFractionDigits: 2 })} · VAT ₦{tax.toLocaleString('en-NG', { minimumFractionDigits: 2 })} · Total ₦{(subtotal + tax).toLocaleString('en-NG', { minimumFractionDigits: 2 })}</p>

        <Button type="submit" disabled={busy}>{busy ? 'Saving…' : 'Create invoice'}</Button>
      </form>
    </div>
  );
}
