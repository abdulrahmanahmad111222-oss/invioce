import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { can, grantableRoles, ROLE_RANK } from '../permissions.js';
import { ROLE_LABELS } from '../format.js';
import { Notice, Button, Field } from '../components/ui.jsx';

export default function Team({ bizId, role, session }) {
  const [members, setMembers] = useState(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [invite, setInvite] = useState({ contact: '', kind: 'phone', role: 'staff' });
  const roles = grantableRoles(role);

  const load = () => api.get(`/businesses/${bizId}/members`).then(setMembers).catch((e) => setError(e.message));
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [bizId]);

  // You can only change or remove people with a lower role than yours.
  const canManage = (m) => m.role !== 'owner' && m.userId !== session.me?.id && ROLE_RANK[role] > ROLE_RANK[m.role];

  async function run(fn, message) {
    setError(''); setNote('');
    try { await fn(); setNote(message); await load(); } catch (e) { setError(e.message); }
  }

  async function sendInvite(e) {
    e.preventDefault();
    const body = invite.kind === 'phone' ? { phone: invite.contact, role: invite.role } : { email: invite.contact, role: invite.role };
    await run(async () => {
      const r = await api.post(`/businesses/${bizId}/invitations`, body);
      setInvite({ ...invite, contact: '' });
      return r;
    }, 'Invitation sent.');
  }

  if (!can(role, 'members.manage')) return <Notice kind="error">Only owners and admins can manage the team.</Notice>;

  return (
    <div>
      <h1>Team</h1>
      {error && <Notice kind="error">{error}</Notice>}
      {note && <Notice kind="ok">{note}</Notice>}

      {!members ? <p>Loading…</p> : (
        <div className="scroll">
          <table>
            <thead><tr><th>Contact</th><th>Role</th><th /></tr></thead>
            <tbody>
              {members.map((m) => (
                <tr key={m.userId}>
                  <td>{m.phone ?? m.email}</td>
                  <td>
                    {canManage(m) ? (
                      <select aria-label={`Role for ${m.phone ?? m.email}`} value={m.role}
                        onChange={(e) => run(() => api.patch(`/businesses/${bizId}/members/${m.userId}`, { role: e.target.value }), 'Role updated.')}>
                        {grantableRoles(role).map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
                        <option value={m.role}>{ROLE_LABELS[m.role]}</option>
                      </select>
                    ) : ROLE_LABELS[m.role]}
                  </td>
                  <td className="r">
                    {canManage(m) && (
                      <button className="linkish danger-text" onClick={() => {
                        if (window.confirm('Remove this person from the business?')) {
                          run(() => api.del(`/businesses/${bizId}/members/${m.userId}`), 'Member removed.');
                        }
                      }}>Remove</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <h2>Invite someone</h2>
      {roles.length === 0 ? (
        <p className="muted">Your role can't invite anyone.</p>
      ) : (
        <form onSubmit={sendInvite} className="stack">
          <div className="grid2">
            <Field label="How to reach them">
              <select value={invite.kind} onChange={(e) => setInvite({ ...invite, kind: e.target.value, contact: '' })}>
                <option value="phone">WhatsApp / phone</option>
                <option value="email">Email</option>
              </select>
            </Field>
            <Field label={invite.kind === 'phone' ? 'Phone number' : 'Email address'}>
              <input type={invite.kind === 'phone' ? 'tel' : 'email'} value={invite.contact} onChange={(e) => setInvite({ ...invite, contact: e.target.value })} required />
            </Field>
            <Field label="Role">
              <select value={invite.role} onChange={(e) => setInvite({ ...invite, role: e.target.value })}>
                {roles.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
              </select>
            </Field>
          </div>
          <Button type="submit">Send invitation</Button>
          <p className="muted small">The invitation expires after 48 hours and works once.</p>
        </form>
      )}
    </div>
  );
}
