import { useEffect, useRef, useState } from 'react';
import { api } from '../api.js';
import { sessionStore } from '../session.js';
import { go } from '../nav.js';
import { GOOGLE_CLIENT_ID } from '../config.js';
import { Notice, Button, Field } from '../components/ui.jsx';

export function SignIn({ next = '/businesses', onSignedIn }) {
  const [step, setStep] = useState('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const googleRef = useRef(null);

  function finish(token) {
    sessionStore.set(token);
    onSignedIn();
    go(next || '/businesses');
  }

  async function requestCode(e) {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      await api.post('/auth/otp/request', { phone });
      setStep('code');
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  async function verifyCode(e) {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      const r = await api.post('/auth/otp/verify', { phone, code });
      finish(r.token);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  // Google sign-in: loads Google's button and sends the ID token to our API.
  useEffect(() => {
    if (!GOOGLE_CLIENT_ID || !googleRef.current) return;
    const init = () => {
      window.google.accounts.id.initialize({
        client_id: GOOGLE_CLIENT_ID,
        callback: async ({ credential }) => {
          try {
            const r = await api.post('/auth/google', { idToken: credential });
            finish(r.token);
          } catch (err) { setError(err.message); }
        }
      });
      window.google.accounts.id.renderButton(googleRef.current, { theme: 'outline', size: 'large', width: 300 });
    };
    if (window.google?.accounts?.id) { init(); return; }
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.onload = init;
    document.head.appendChild(script);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="auth-shell">
      <a className="brand" href="#/signin"><span className="brand-mark" aria-hidden="true">₦</span>Invoices</a>
      <div className="auth">
      <h1>Sign in</h1>
      <p className="lede">Invoices, payments and your team, in one place.</p>
      {error && <Notice kind="error">{error}</Notice>}

      {step === 'phone' ? (
        <form onSubmit={requestCode} className="stack">
          <Field label="Phone number" hint="We'll send a code on WhatsApp, or by SMS if WhatsApp isn't available.">
            <input inputMode="tel" autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="08012345678" required />
          </Field>
          <Button type="submit" disabled={busy}>{busy ? 'Sending…' : 'Send code'}</Button>
        </form>
      ) : (
        <form onSubmit={verifyCode} className="stack">
          <Field label="6-digit code">
            <input inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value)} maxLength={6} required />
          </Field>
          <Button type="submit" disabled={busy}>{busy ? 'Checking…' : 'Sign in'}</Button>
          <Button type="button" variant="ghost" onClick={() => { setStep('phone'); setCode(''); }}>Use a different number</Button>
        </form>
      )}

      {GOOGLE_CLIENT_ID && (
        <>
          <div className="divider">or</div>
          <div ref={googleRef} />
        </>
      )}
      </div>
    </div>
  );
}

export function Join({ token, session }) {
  const [state, setState] = useState({ status: 'idle' });

  useEffect(() => {
    if (!session.signedIn || !token) return;
    setState({ status: 'working' });
    api.post('/invitations/accept', { token })
      .then(() => { setState({ status: 'done' }); session.reload(); })
      .catch((err) => setState({ status: 'error', message: err.message }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session.signedIn, token]);

  if (!token) return <div className="auth-shell"><div className="auth"><Notice kind="error">This invitation link is incomplete. Ask for a new one.</Notice></div></div>;
  if (!session.signedIn) {
    return <SignIn next={`/join?token=${encodeURIComponent(token)}`} onSignedIn={session.onSignedIn} />;
  }
  if (state.status === 'working' || state.status === 'idle') return <p>Joining…</p>;
  if (state.status === 'error') return <div className="auth-shell"><div className="auth"><Notice kind="error">{state.message}</Notice></div></div>;
  return (
    <div className="auth-shell">
      <div className="auth stack">
        <Notice kind="ok">You've joined the business.</Notice>
        <Button className="block" onClick={() => go('/businesses')}>Go to your businesses</Button>
      </div>
    </div>
  );
}
