import Frame from '../components/Frame.jsx';
import { Notice } from '../components/ui.jsx';
import InvoiceList from './invoices/InvoiceList.jsx';
import InvoiceNew from './invoices/InvoiceNew.jsx';
import InvoiceDetail from './invoices/InvoiceDetail.jsx';
import Team from './Team.jsx';
import Billing from './Billing.jsx';
import Settings from './Settings.jsx';

// Picks the page for the URL and checks membership before showing anything.
export default function BusinessShell({ session, bizId, section }) {
  if (!session.memberships) return <Frame session={session}><p>Loading…</p></Frame>;

  const membership = session.memberships.find((m) => m.business.id === bizId);
  if (!membership) {
    return <Frame session={session}><Notice kind="error">You're not a member of this business.</Notice></Frame>;
  }

  const { business, role } = membership;
  const common = { session, bizId, business, role };
  const [a, b] = section;
  let page;
  if (a === 'invoices' && b === 'new') page = <InvoiceNew {...common} />;
  else if (a === 'invoices' && b) page = <InvoiceDetail {...common} no={b} />;
  else if (!a || a === 'invoices') page = <InvoiceList {...common} />;
  else if (a === 'team') page = <Team {...common} />;
  else if (a === 'billing') page = <Billing {...common} />;
  else if (a === 'settings') page = <Settings {...common} />;
  else page = <Notice kind="error">Page not found.</Notice>;

  return <Frame session={session} business={business} role={role}>{page}</Frame>;
}
