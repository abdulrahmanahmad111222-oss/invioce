import { useState } from 'react';
import { api } from '../api.js';
import { go } from '../nav.js';
import Frame from '../components/Frame.jsx';
import { Notice, Button, Field } from '../components/ui.jsx';
import { ROLE_LABELS } from '../format.js';

export default function Businesses({ session }) {
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function create(e) {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      const biz = await api.post('/businesses', { name });
      await session.reload();
      go(`/b/${biz.id}/invoices`);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  return (
    <Frame session={session}>
      <h1>Your businesses</h1>
      {!session.memberships && <p>Loading…</p>}
      {session.memberships?.length === 0 && (
        <div className="empty"><strong>No businesses yet</strong>Create one below, or open an invitation link from a colleague.</div>
      )}
      <ul className="list">
        {session.memberships?.map(({ business, role }) => (
          <li key={business.id}>
            <a href={`#/b/${business.id}/invoices`}>{business.name}</a>
            <span className="muted"> · {ROLE_LABELS[role] ?? role}</span>
          </li>
        ))}
      </ul>
      <h2>Create a business</h2>
      <div className="card">
        {error && <Notice kind="error">{error}</Notice>}
        <form onSubmit={create} className="stack">
          <Field label="Business name"><input value={name} onChange={(e) => setName(e.target.value)} minLength={2} maxLength={80} required /></Field>
          <div><Button type="submit" disabled={busy}>{busy ? 'Creating…' : 'Create business'}</Button></div>
        </form>
        <p className="muted small" style={{ margin: '12px 0 0' }}>New businesses start with a 14-day free trial.</p>
      </div>
    </Frame>
  );
}
