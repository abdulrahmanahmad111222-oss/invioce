import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { can } from '../permissions.js';
import { Notice, Button } from '../components/ui.jsx';

export default function Settings({ bizId, role, business }) {
  const [gmail, setGmail] = useState(null);
  const [audit, setAudit] = useState(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const params = new URLSearchParams(window.location.hash.split('?')[1] ?? '');

  useEffect(() => {
    const status = params.get('gmail');
    if (status === 'connected') setNote('Gmail is connected. Invoices will be sent from that address.');
    if (status === 'denied') setError('Gmail was not connected, because the request was cancelled.');
    if (can(role, 'integrations.manage')) {
      api.get(`/businesses/${bizId}/gmail`).then(setGmail).catch((e) => setError(e.message));
    }
    if (can(role, 'audit.view')) {
      api.get(`/businesses/${bizId}/audit`).then((rows) => setAudit(rows.slice(-50).reverse())).catch((e) => setError(e.message));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bizId, role]);

  async function connect() {
    setError('');
    try {
      const r = await api.get(`/businesses/${bizId}/gmail/connect`);
      window.location.href = r.url;
    } catch (e) { setError(e.message); }
  }

  async function disconnect() {
    if (!window.confirm('Disconnect Gmail? Invoice and invitation emails will stop until you reconnect.')) return;
    setError('');
    try {
      await api.del(`/businesses/${bizId}/gmail`);
      setGmail({ connected: false });
      setNote('Gmail disconnected.');
    } catch (e) { setError(e.message); }
  }

  return (
    <div>
      <h1>Settings</h1>
      <p className="muted">{business.name}</p>
      {error && <Notice kind="error">{error}</Notice>}
      {note && <Notice kind="ok">{note}</Notice>}

      {can(role, 'integrations.manage') && (
        <section>
          <h2>Email sending (Gmail)</h2>
          {!gmail ? <p>Loading…</p> : gmail.connected ? (
            <>
              <p>Sending from <strong>{gmail.email}</strong>.</p>
              <Button variant="danger" onClick={disconnect}>Disconnect Gmail</Button>
            </>
          ) : (
            <>
              <p className="muted">Connect a Gmail account to send invoices and invitations from your own address. Your plan must include Gmail sending.</p>
              <Button onClick={connect}>Connect Gmail</Button>
            </>
          )}
        </section>
      )}

      {can(role, 'audit.view') && (
        <section>
          <h2>Recent activity</h2>
          {!audit ? <p>Loading…</p> : audit.length === 0 ? <p className="muted">Nothing yet.</p> : (
            <ul className="activity card">
              {audit.map((e) => (
                <li key={e.id}>
                  <span className="muted">{new Date(e.at).toLocaleString('en-NG')}</span> {e.action.replace(/[._]/g, ' ')}{e.target ? ` · ${e.target}` : ''}
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </div>
  );
}
