import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles.css';

// Links from emails and the server (for example /join?token=...) arrive as real paths.
// Move them into the hash so the app can route them.
if (window.location.pathname !== '/') {
  window.history.replaceState(null, '', '/#' + window.location.pathname + window.location.search);
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
