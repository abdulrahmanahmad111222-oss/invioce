// End-to-end flow: the real React app, the real API, and a real PostgreSQL database.
// Runs only when E2E_BACKEND_DIR and E2E_DB_URL are set. The backend prints sign-in codes to its console
// (development mode with no messaging channels configured), and the test reads them from there.
import { describe, it, expect, beforeAll, afterAll, afterEach, vi } from 'vitest';
import { spawn } from 'node:child_process';
import { render, screen, fireEvent, waitFor, within, cleanup } from '@testing-library/react';
import { sessionStore } from './session.js';

const BACKEND = process.env.E2E_BACKEND_DIR;
const DB_URL = process.env.E2E_DB_URL;
const PORT = 3999;

describe.skipIf(!BACKEND || !DB_URL)('full flow against the real API', () => {
  let child;
  let output = '';
  let App;

  beforeAll(async () => {
    vi.stubEnv('VITE_API_URL', `http://127.0.0.1:${PORT}`);
    child = spawn('node', ['src/index.js'], {
      cwd: BACKEND,
      env: {
        ...process.env,
        DATABASE_URL: DB_URL,
        TOKEN_SECRET: 'e2e-secret-e2e-secret-e2e-secret-00',
        PAYSTACK_SECRET_KEY: 'sk_test_e2e',
        PORT: String(PORT),
        APP_URL: 'http://localhost:5173',
        NODE_ENV: 'development'
      }
    });
    child.stdout.on('data', (d) => { output += d; });
    child.stderr.on('data', (d) => { output += d; });
    await waitFor(() => expect(output).toContain('listening'), { timeout: 20000 });
    ({ default: App } = await import('./App.jsx'));
  }, 40000);

  afterEach(() => cleanup());
  afterAll(() => child?.kill());

  async function codeFor(phone) {
    const re = new RegExp(`\\[dev\\] code for ${phone}: (\\d{6})`);
    await waitFor(() => expect(output).toMatch(re), { timeout: 5000 });
    return output.match(re)[1];
  }

  it('signs in, creates a business and an invoice, and invites a teammate', async () => {
    window.location.hash = '#/signin';
    render(<App />);

    fireEvent.change(screen.getByLabelText(/Phone number/), { target: { value: '08011112222' } });
    fireEvent.click(screen.getByRole('button', { name: 'Send code' }));
    const code = await codeFor('2348011112222');
    fireEvent.change(await screen.findByLabelText(/6-digit code/), { target: { value: code } });
    fireEvent.click(screen.getByRole('button', { name: 'Sign in' }));

    await screen.findByRole('heading', { name: 'Your businesses' });
    fireEvent.change(screen.getByLabelText('Business name'), { target: { value: 'Ada Designs' } });
    fireEvent.click(screen.getByRole('button', { name: 'Create business' }));

    await screen.findByRole('heading', { name: 'Invoices' });
    await screen.findByText('No invoices yet');

    fireEvent.click(screen.getByRole('button', { name: 'New invoice' }));
    await screen.findByRole('heading', { name: 'New invoice' });
    fireEvent.change(screen.getByLabelText('Client name'), { target: { value: 'Tunde Bello' } });
    fireEvent.change(screen.getByLabelText('Client WhatsApp number'), { target: { value: '08012345678' } });
    fireEvent.click(screen.getByRole('button', { name: 'Create invoice' }));

    // The default item is ₦150,000 plus 7.5% VAT, so ₦161,250.00.
    await screen.findByRole('heading', { name: 'INV-0001' });
    expect(screen.getAllByText('₦161,250.00').length).toBeGreaterThan(0);
    expect(screen.getByRole('link', { name: 'Send on WhatsApp' }).getAttribute('href')).toContain('wa.me/2348012345678');

    const tabs = within(screen.getByRole('navigation', { name: 'Business' }));
    fireEvent.click(tabs.getByRole('link', { name: 'Invoices' }));
    await screen.findByRole('link', { name: 'INV-0001' });

    fireEvent.click(tabs.getByRole('link', { name: 'Team' }));
    await screen.findByRole('heading', { name: 'Team' });
    fireEvent.change(screen.getByLabelText('Phone number'), { target: { value: '08022223333' } });
    fireEvent.click(screen.getByRole('button', { name: 'Send invitation' }));
    await screen.findByText('Invitation sent.');
  }, 40000);

  it('an invited person follows the link, signs in, and joins the business', async () => {
    const link = output.match(/\[dev\] invitation for 2348022223333: (\S+)/)[1];
    const token = new URL(link).searchParams.get('token');

    // A fresh visitor: nobody is signed in on this device yet.
    sessionStore.clear();
    window.location.hash = `#/join?token=${token}`;
    render(<App />);

    // Not signed in yet, so the invitation page asks them to sign in first.
    fireEvent.change(await screen.findByLabelText(/Phone number/), { target: { value: '08022223333' } });
    fireEvent.click(screen.getByRole('button', { name: 'Send code' }));
    const code = await codeFor('2348022223333');
    fireEvent.change(await screen.findByLabelText(/6-digit code/), { target: { value: code } });
    fireEvent.click(screen.getByRole('button', { name: 'Sign in' }));

    await screen.findByText("You've joined the business.");
    fireEvent.click(screen.getByRole('button', { name: 'Go to your businesses' }));
    await screen.findByRole('link', { name: 'Ada Designs' });
  }, 40000);
});
