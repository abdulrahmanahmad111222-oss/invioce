# Invoice web app

React single-page app for the invoice platform. It talks to the backend API over HTTPS.

## Screens

- **Sign in:** phone code (WhatsApp or SMS), or Google sign-in when configured.
- **Businesses:** list your businesses and your role in each. Create one. New businesses start with a 14-day trial.
- **Invoices:** list, create (with VAT and due date), share on WhatsApp, copy the payment link, email to the client, and cancel unpaid invoices.
- **Team:** invite by phone or email, change roles, remove people. Only roles below yours are offered.
- **Billing:** plan and usage, buy monthly or yearly through Paystack, cancel. Only the owner can change the subscription.
- **Settings:** connect or disconnect the business's Gmail, and recent activity.
- **Join:** accept an invitation from its link.

The interface hides actions your role can't use, but the server is the real check.

## Setup

```
npm install
cp .env.example .env.local      # then edit the values
npm run dev                     # http://localhost:5173
npm test                        # unit and render tests
npm run build                   # static files in dist/
```

Environment variables (must start with `VITE_`):

| Variable | Purpose |
|---|---|
| `VITE_API_URL` | Public URL of the backend API, e.g. `https://api.example.com` |
| `VITE_GOOGLE_CLIENT_ID` | Google OAuth client ID for the sign-in button (optional) |

## Backend settings that must match

- `APP_URL` on the backend is the exact origin of this web app, e.g. `https://app.example.com`. The API only accepts browser requests from that origin.
- `API_URL` on the backend is the origin of the API itself. Customer payment pages and the Gmail callback are served from it.
- The Gmail redirect URI registered with Google is `API_URL/auth/gmail/callback`.

## Hosting

Build with `npm run build` and host the `dist/` folder on any static host (Netlify, Vercel, Cloudflare Pages, S3 with CloudFront, or nginx).

**Important:** the host must serve `index.html` for these real paths, because links from emails and Paystack return to them:
- `/join` (invitation links, e.g. `https://app.example.com/join?token=...`)
- `/b/...` (the billing return after checkout, e.g. `https://app.example.com/b/<id>/billing`, and the Gmail return, e.g. `/b/<id>/settings?gmail=connected`)

Most static hosts have a single "rewrite everything to /index.html" setting. Turn it on. Other routes use `#` links and don't need it.

## Tests

- `npm test` runs the unit tests and the sign-in render test.
- The end-to-end flows in `src/flow.e2e.test.jsx` run the real app against the real API and a real PostgreSQL database. They cover sign-in, creating a business, creating an invoice with VAT, inviting a teammate, and accepting the invitation through its link. To run them, point them at the backend folder and a test database:

```
E2E_BACKEND_DIR=../invoice-backend E2E_DB_URL=postgres://postgres:postgres@localhost:5432/invoice_e2e npm test
```

The database must exist and be empty when you start. The test starts the backend itself and reads the sign-in codes from its console, which is how the backend behaves when no WhatsApp or SMS channel is configured in development.

## Design

The interface uses one accent colour, warm neutrals, and the IBM Plex Sans font. On phones, tables become stacked cards, and the tabs scroll sideways. Forms use 16px text so phones don't zoom in. Focus rings are visible for keyboard users, and motion is reduced when the device asks for it. Have a designer review it before launch.

## Not yet verified in a real browser

The end-to-end tests drive the app with jsdom, not a real browser. Before launch, check these on a phone and a desktop: the Google sign-in button, the Paystack checkout round trip (use Paystack's test mode), the Gmail connect redirect, the WhatsApp share link, and copying the payment link. Also check the layout on narrow screens, since the styling is functional rather than designed.
