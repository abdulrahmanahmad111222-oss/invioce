import { createDb } from '../src/db.js';
import { migrate } from '../src/migrate.js';

const db = createDb(process.env.DATABASE_URL);
const applied = await migrate(db);
console.log(applied.length ? `Applied: ${applied.join(', ')}` : 'Database is up to date.');
await db.close();
