#!/usr/bin/env bash
# Nightly database backup. Schedule with cron, and copy the output to storage outside this server.
# Usage: DATABASE_URL=postgres://... ./scripts/backup.sh /path/to/backups
# NOT TESTED in the build environment (pg_dump isn't available there). Run a restore test before relying on it:
#   pg_restore --clean --if-exists -d <test_database> <file>
set -euo pipefail
: "${DATABASE_URL:?set DATABASE_URL}"
DIR="${1:?usage: backup.sh <directory>}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
mkdir -p "$DIR"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
FILE="$DIR/invoice-$STAMP.dump"
pg_dump --format=custom --no-owner --file="$FILE" "$DATABASE_URL"
echo "wrote $FILE"
find "$DIR" -name 'invoice-*.dump' -mtime +"$RETENTION_DAYS" -delete
