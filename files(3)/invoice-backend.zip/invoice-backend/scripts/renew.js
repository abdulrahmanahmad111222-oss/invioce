// Run once a day, e.g. from cron: node scripts/renew.js
// Charges saved cards for subscriptions whose period has ended, and moves failed renewals into grace or suspension.
import { createDb } from '../src/db.js';
import { migrate } from '../src/migrate.js';
import { createAudit } from '../src/audit.js';
import { createBox } from '../src/crypto-box.js';
import { createBilling } from '../src/billing/billing.js';
import { createPaystackClient } from '../src/providers/paystack.js';

const db = createDb(process.env.DATABASE_URL);
await migrate(db);
const billing = createBilling({
  db,
  audit: createAudit({ db }),
  box: createBox(process.env.ENCRYPTION_KEY),
  paystack: createPaystackClient({ secretKey: process.env.PAYSTACK_SECRET_KEY }),
  appUrl: process.env.APP_URL
});
const summary = await billing.runRenewals();
console.log(JSON.stringify({ at: new Date().toISOString(), ...summary }));
await db.close();
