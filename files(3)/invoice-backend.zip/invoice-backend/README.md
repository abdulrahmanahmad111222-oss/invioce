# Invoice backend

Node.js backend for an invoicing and payment platform for small businesses and freelancers. It covers sign-in (phone code or Google), multi-user businesses with roles, invitations, WhatsApp/SMS/Gmail delivery, Paystack payments, and monthly or yearly subscriptions with limits.

## Stack

- Node.js 18+ with Express
- PostgreSQL (schema in `migrations/`, applied in order, each once)
- Paystack for payments and subscriptions
- WhatsApp Cloud API, Termii SMS, and Gmail API for messages
- Google OAuth for sign-in and per-business Gmail connections

## Setup

1. Install Node.js 18+ and Docker.
2. Start PostgreSQL and create two databases:
   ```
   docker compose up -d
   docker compose exec db psql -U postgres -c "CREATE DATABASE invoice_dev;"
   docker compose exec db psql -U postgres -c "CREATE DATABASE invoice_test;"
   ```
3. Copy `.env.example` to `.env` and fill it in (see the table below).
4. `npm install`

## Run the tests

Tests run against a real PostgreSQL database. The helper wipes it, so it refuses any database whose name doesn't end in `_test`.

```
TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/invoice_test npm test
```

The suite covers the permission matrix, tenancy and team rules, the payment webhook (including concurrent duplicates), invoice numbering under concurrency, delivery fallback, Gmail (with a fake Google), and billing (trial, checkout, limits, renewals, grace periods, cancellation, and overlapping renewal runs). External services are replaced with fakes. Live delivery and live payments still need a test with real credentials.

## Run the server

```
npm run migrate    # applies migrations/ once each
npm start
```

In development, codes and links print to the console when no delivery channel is configured. In production the server refuses to start without WhatsApp or SMS credentials.

## Environment

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection |
| `TEST_DATABASE_URL` | Test database (name must end in `_test`) |
| `TOKEN_SECRET` | Signs session tokens and Gmail connection links. At least 32 random characters. |
| `ENCRYPTION_KEY` | 32 random bytes, base64. Encrypts Gmail and card tokens. Losing it means every business reconnects Gmail and renewals stop. |
| `PAYSTACK_SECRET_KEY` | Paystack secret key (test or live) |
| `APP_URL` | Public address of the web app. Invitation, payment, and billing links use it. |
| `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN` | WhatsApp Cloud API (primary channel for codes and invitations) |
| `TERMII_API_KEY`, `TERMII_SENDER_ID` | Termii SMS (fallback) |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Google sign-in and Gmail OAuth client |
| `GMAIL_REDIRECT_URI` | `https://<api>/auth/gmail/callback`, registered with Google |
| `PORT` | Server port (default 3000) |
| `API_URL` | Public URL of this API. Customer payment pages and the Gmail callback use it. |
| `TRUST_PROXY` | Set to the number of proxies in front of the API (for example `1`) so rate limits see real client addresses. |

## Users and businesses

- A **user** signs in with a phone number (one-time code) or a Google account. The two can be linked to one user. Linking is always an explicit action; accounts are never merged by email.
- A **business** has members with roles: owner, admin, manager, staff, and accountant. One person can be owner of one business and staff in another.
- A non-member gets `404`, not `403`, so business IDs can't be probed.
- The owner can't be changed or removed. Nobody can change their own role. You can only manage people with a lower role than yours, and only grant roles below your own.
- Removing a member takes effect on their next request.
- Invitations go to a phone number or a verified email, are single-use, and expire after 48 hours. The invitation token is sent only to the invitee and is never returned to the inviter.
- Every team, invoice, payment, and billing change is written to an append-only audit log, which a database trigger protects.

## Permissions

Defined once in `src/permissions.js` and checked on the server for every request.

| Permission | Owner | Admin | Manager | Staff | Accountant |
|---|---|---|---|---|---|
| billing.manage (buy, cancel) | yes | no | no | no | no |
| billing.view | yes | yes | no | no | yes |
| members.invite / members.manage | yes | yes | no | no | no |
| integrations.manage (Gmail) | yes | yes | no | no | no |
| invoices.create / edit / view | yes | yes | yes | yes | view |
| invoices.void, payments.refund | yes | yes | yes | no | no |
| payments.record | yes | yes | yes | yes | no |
| reports.view, audit.view | yes | yes | yes | no | yes |

## Messages

Codes and invitations go out through the first channel that works:

1. **WhatsApp** (Meta WhatsApp Cloud API) is tried first.
2. **SMS** (Termii) is the fallback.
3. **Email** goes through the business's connected Gmail account, for invoices, email invitations, and owner notices.

Setup:
- **WhatsApp:** create a WhatsApp Business app in Meta's dashboard and add a phone number. Create three message templates and wait for Meta to approve them: `otp_code` (authentication template with a copy-code button), `business_invite` (three body parameters: business name, role, link), and `subscription_payment_failed` (two body parameters: business name, date). Template names and layouts can be changed in `src/providers/whatsapp.js`.
- **SMS:** register a sender ID with Termii.

Rules:
- If an invitation can't be delivered, the server returns 502 and revokes it, so nothing is left that nobody can use.
- If every channel fails for a sign-in code, the user gets 503 and can retry immediately.
- The `notifications` table logs each attempt with its channel and status. It keeps only the last four digits of the recipient. Codes are never stored.

## Gmail (email from each business's own account)

Each business connects its own Gmail account, so invoices and invitations come from that business's address.

Setup:
1. In Google Cloud Console, enable the Gmail API and add the scope `https://www.googleapis.com/auth/gmail.send` to the OAuth consent screen.
2. Register `GMAIL_REDIRECT_URI` as an authorized redirect URI on the OAuth client.
3. Set `GOOGLE_CLIENT_SECRET` and `ENCRYPTION_KEY`.

Flow:
- An owner or admin calls `GET /businesses/:bizId/gmail/connect` and opens the returned URL. Connecting is a paid feature.
- Google redirects to `/auth/gmail/callback`. The state is signed, expires after 10 minutes, and the person's role is checked again at that moment.
- The refresh token is encrypted (AES-256-GCM) before it's stored. The API never returns it.
- `POST /businesses/:bizId/invoices/:no/email` sends the invoice to the client's address, with the amount, due date, and a payment link.
- `DELETE /businesses/:bizId/gmail` disconnects and revokes the token.

Notes:
- `gmail.send` is a sensitive scope. Google requires app verification before strangers can connect accounts. While the app is in testing, only test users can connect.
- Access tokens are refreshed on every send. Caching them would save requests at higher volume.

## Google sign-in

1. Create an OAuth client of type Web application in Google Cloud Console and set `GOOGLE_CLIENT_ID`.
2. The client app uses Google's sign-in button to get an ID token and sends it to `POST /auth/google` as `{"idToken": "..."}`. The server verifies it with Google's library, so it can't be faked.
3. Signed-in users can link the other method: `POST /me/link/google` with `{idToken}`, or `POST /me/link/phone` with `{phone, code}`.

Without `GOOGLE_CLIENT_ID`, `/auth/google` returns 501.

## Plans and billing

| Plan | Monthly | Yearly | Team members | Invoices per month | Gmail sending |
|---|---|---|---|---|---|
| Starter | ₦5,000 | ₦50,000 | 2 | 30 | no |
| Growth | ₦15,000 | ₦150,000 | 6 | 300 | yes |
| Scale | ₦40,000 | ₦400,000 | 25 | unlimited | yes |

These are placeholders. Change them in `src/billing/plans.js`. Amounts are in kobo.

- **Trial:** every new business gets 14 days on Growth, with no card required.
- **Checkout:** `POST /businesses/:bizId/subscription/checkout` with `{plan, interval, email}` returns a Paystack link. The webhook activates the plan after Paystack confirms the amount. A repeated webhook can't extend the period twice.
- **Renewals:** Paystack saves a reusable card token at checkout (encrypted). `scripts/renew.js` charges it once a day when the period ends. Overlapping runs never charge the same period twice.
- **Failed renewal:** the account moves to `past_due` with a 3-day grace period, and writes stay open during it. The owner gets one notice per failure period. After grace, the account is suspended.
- **Expired:** new invoices, invitations, Gmail connections, voids, and refunds return 402. Reads and customer payments on existing invoices keep working.
- **Limits:** team members (including pending invitations) and monthly invoices are checked inside the same transaction as the write, so concurrent requests can't exceed a limit.
- **Cancel:** `POST /businesses/:bizId/subscription/cancel`. Access continues until the period ends, and the saved card is deleted.

Setup:
1. Use live Paystack keys. Ask Paystack to approve your account for recurring charges (charge authorization) before launch.
2. Point the Paystack webhook at `https://<api>/webhooks/paystack`.
3. Schedule the renewal job daily: `node scripts/renew.js`. It prints a JSON summary with charged, failed, and skipped counts.
4. Build the frontend return page at `APP_URL/billing/return`.

Decisions and known gaps:
- Changing plans starts a new period today and charges the full new price. There's no proration.
- Monthly periods use UTC month boundaries. Renewals on the 31st move to the 1st of the next month.
- VAT on subscriptions is a question for a Nigerian tax adviser. So is the invoice-count reset.

## Payments on invoices

- `POST /webhooks/paystack` handles both invoice payments and subscription payments. Each payment is confirmed with Paystack's verify API before it changes anything, and a payment is recorded only once.
- Invoice payments are recorded even when the business's subscription has ended.
- Customers pay on the hosted page at `/pay/<reference>` (GET shows the invoice, POST starts a Paystack payment). Each payment attempt gets its own Paystack reference, which maps back to the invoice. The page is public, and the reference in the link is the only access control.
- The pay page works even when the business's subscription has ended, so customers can always pay.

## Before going live

- **Invitations and codes:** check that the WhatsApp templates are approved and that a live send works on both channels.
- **Database roles:** the application user should have INSERT and SELECT on `audit_log`, not UPDATE or DELETE. The trigger is a second layer.
- **Backups:** `scripts/backup.sh` writes a nightly `pg_dump` and keeps 30 days. It was written but not tested in the build environment, because `pg_dump` isn't available there. Run it once against a staging database, then restore the file into an empty database and check the numbers match. Store copies off the server.
- **Keys:** keep `TOKEN_SECRET` and `ENCRYPTION_KEY` in a secrets manager. Losing `ENCRYPTION_KEY` breaks Gmail connections and renewals.
- **Rate limiting:** sign-in requests are limited to 100 per 15 minutes per client, and payment-page posts to 30 per minute. Webhooks are not limited. Limits are kept in memory per instance, so run a shared store (such as Redis) if you run several instances. Set `TRUST_PROXY` behind a load balancer.
- **Google verification:** request Google's review of the `gmail.send` scope before opening Gmail connections to people outside your test list.
- **Legal:** business registration, terms of service, a privacy policy, and the Nigeria Data Protection Act obligations, reviewed by a lawyer.
- **Ownership transfer:** not built yet. Add it as its own confirmed flow.
- **Step-up checks:** require a fresh OTP before refunds, payout changes, and role changes.
