import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createApp } from '../src/server.js';
import { db, resetDb } from './helpers.js';

const SECRET = 'sk_test_unit';

async function setup() {
  await resetDb();
  await db.query("INSERT INTO users (id, phone) VALUES ('usr_test', '2340000000001')");
  await db.query("INSERT INTO businesses (id, name, owner_user_id) VALUES ('biz_test', 'Test Shop', 'usr_test')");
  const transactions = new Map(); // reference -> { amount, currency } that the fake provider confirms
  const app = createApp({
    db,
    tokenSecret: 'unused-in-webhook-tests',
    paystackSecretKey: SECRET,
    verifyTransaction: async (reference) => transactions.get(reference) ?? null
  });
  const server = app.listen(0);
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    invoices: app.services.invoices,
    transactions,
    close() { server.close(); server.closeAllConnections?.(); }
  };
}

function makeInvoice(ctx, naira = 10000, vat = false) {
  return ctx.invoices.createInvoice('biz_test', {
    client: 'Tunde Bello',
    phone: '08012345678',
    vat,
    lines: [{ desc: 'Logo design', qty: 1, price: naira }]
  }, 'usr_test');
}

async function pay(ctx, { id, reference, amount, confirmedAmount = amount, currency = 'NGN', sign = true }) {
  ctx.transactions.set(reference, { amount: confirmedAmount, currency });
  const body = JSON.stringify({ event: 'charge.success', data: { id, reference, amount, currency } });
  const sig = sign ? crypto.createHmac('sha512', SECRET).update(body).digest('hex') : 'forged';
  const res = await fetch(`${ctx.base}/webhooks/paystack`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-paystack-signature': sig },
    body
  });
  return { status: res.status, body: await res.json().catch(() => null) };
}

test('rejects a webhook with a bad signature', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx);
    const r = await pay(ctx, { id: 1, reference: inv.paymentReference, amount: 1000000, sign: false });
    assert.equal(r.status, 401);
  } finally { ctx.close(); }
});

test('full payment marks the invoice paid and writes a ledger entry', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    const r = await pay(ctx, { id: 101, reference: inv.paymentReference, amount: 1000000 });
    assert.equal(r.body.status, 'applied');
    assert.equal((await ctx.invoices.getInvoice('biz_test', 1)).status, 'Paid');
    const ledger = await ctx.invoices.ledger('biz_test');
    assert.equal(ledger.length, 1);
    assert.equal(ledger[0].gross, 1000000);
    assert.equal(ledger[0].fee, 15000); // 1.5% of ₦10,000
  } finally { ctx.close(); }
});

test('the same webhook delivered twice is applied once', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    const args = { id: 202, reference: inv.paymentReference, amount: 500000 };
    assert.equal((await pay(ctx, args)).body.status, 'applied');
    assert.equal((await pay(ctx, args)).body.status, 'duplicate');
    const after = await ctx.invoices.getInvoice('biz_test', 1);
    assert.equal(after.paid, 500000);
    assert.equal(after.status, 'Partly paid');
    assert.equal((await ctx.invoices.ledger('biz_test')).length, 1);
  } finally { ctx.close(); }
});

test('partial payments add up to paid', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    await pay(ctx, { id: 301, reference: inv.paymentReference, amount: 400000 });
    await pay(ctx, { id: 302, reference: inv.paymentReference, amount: 600000 });
    assert.equal((await ctx.invoices.getInvoice('biz_test', 1)).status, 'Paid');
  } finally { ctx.close(); }
});

test('payment is not applied if the provider does not confirm it', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    const body = JSON.stringify({ event: 'charge.success', data: { id: 401, reference: inv.paymentReference, amount: 1000000, currency: 'NGN' } });
    const sig = crypto.createHmac('sha512', SECRET).update(body).digest('hex');
    const res = await fetch(`${ctx.base}/webhooks/paystack`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-paystack-signature': sig },
      body
    });
    assert.equal((await res.json()).status, 'not_confirmed');
    assert.equal((await ctx.invoices.getInvoice('biz_test', 1)).paid, 0);
  } finally { ctx.close(); }
});

test('amount mismatch with the provider is rejected', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    const r = await pay(ctx, { id: 501, reference: inv.paymentReference, amount: 1000000, confirmedAmount: 999999 });
    assert.equal(r.body.status, 'mismatch');
    assert.equal((await ctx.invoices.getInvoice('biz_test', 1)).paid, 0);
  } finally { ctx.close(); }
});

test('unknown payment reference is not applied', async () => {
  const ctx = await setup();
  try {
    const r = await pay(ctx, { id: 601, reference: 'inv_doesnotexist', amount: 100 });
    assert.equal(r.body.status, 'unknown_reference');
  } finally { ctx.close(); }
});

test('a payment to a voided invoice is not applied', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    await ctx.invoices.voidInvoice('biz_test', 1, 'usr_test');
    const r = await pay(ctx, { id: 701, reference: inv.paymentReference, amount: 1000000 });
    assert.equal(r.body.status, 'invoice_void');
  } finally { ctx.close(); }
});

test('invoice totals include 7.5% VAT in kobo', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000, true);
    assert.equal(inv.subtotal, 1000000);
    assert.equal(inv.tax, 75000);
    assert.equal(inv.total, 1075000);
  } finally { ctx.close(); }
});

test('refunds reduce the paid amount and cannot exceed it', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    await pay(ctx, { id: 801, reference: inv.paymentReference, amount: 1000000 });
    await ctx.invoices.refund('biz_test', 1, 400000, 'usr_test');
    const after = await ctx.invoices.getInvoice('biz_test', 1);
    assert.equal(after.paid, 600000);
    assert.equal(after.status, 'Partly paid');
    await assert.rejects(ctx.invoices.refund('biz_test', 1, 999999999, 'usr_test'), /more than the amount paid/);
  } finally { ctx.close(); }
});

test('concurrent duplicate webhooks are counted once (database lock and key)', async () => {
  const ctx = await setup();
  try {
    const inv = await makeInvoice(ctx, 10000);
    const args = { id: 901, reference: inv.paymentReference, amount: 300000 };
    const results = await Promise.all([pay(ctx, args), pay(ctx, args), pay(ctx, args), pay(ctx, args)]);
    const statuses = results.map((r) => r.body.status).sort();
    assert.equal(statuses.filter((s) => s === 'applied').length, 1);
    assert.equal((await ctx.invoices.getInvoice('biz_test', 1)).paid, 300000);
  } finally { ctx.close(); }
});

test('concurrent invoice creation gives unique, gap-free numbers', async () => {
  const ctx = await setup();
  try {
    const made = await Promise.all(Array.from({ length: 10 }, () => makeInvoice(ctx, 1000)));
    const nos = made.map((i) => i.no).sort((a, b) => a - b);
    assert.deepEqual(nos, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
  } finally { ctx.close(); }
});

test('the audit log cannot be edited or deleted in the database', async () => {
  const ctx = await setup();
  try {
    await makeInvoice(ctx, 1000);
    await assert.rejects(db.query("UPDATE audit_log SET action = 'tampered'"), /append-only/);
    await assert.rejects(db.query('DELETE FROM audit_log'), /append-only/);
  } finally { ctx.close(); }
});
