import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createApp } from '../src/server.js';
import { db, resetDb } from './helpers.js';

const TOKEN_SECRET = 'test-token-secret';
const PAYSTACK_KEY = 'sk_test';
const ENC_KEY = crypto.randomBytes(32).toString('base64');
const DAY = 24 * 3600 * 1000;

// Small limits so the tests can reach them quickly.
const TEST_PLANS = {
  starter: { name: 'Starter', prices: { monthly: 100000, yearly: 1000000 }, limits: { members: 2, invoicesPerMonth: 3, gmail: false } },
  growth: { name: 'Growth', prices: { monthly: 150000, yearly: 1500000 }, limits: { members: 2, invoicesPerMonth: 3, gmail: false } },
  scale: { name: 'Scale', prices: { monthly: 400000, yearly: 4000000 }, limits: { members: 5, invoicesPerMonth: null, gmail: true } }
};

// Fake Paystack. Tests decide what verify returns and whether charges succeed.
function fakePaystack() {
  const s = { verifyResult: new Map(), charges: [], chargeResult: { status: 'success' } };
  s.client = {
    verify: async (reference) => s.verifyResult.get(reference) ?? null,
    initialize: async ({ reference }) => ({ authorizationUrl: `https://paystack.test/pay/${reference}` }),
    charge: async (args) => {
      s.charges.push(args);
      return typeof s.chargeResult === 'function' ? s.chargeResult(args) : s.chargeResult;
    }
  };
  return s;
}

async function setup({ plans = TEST_PLANS, trialDays, graceDays } = {}) {
  await resetDb();
  const clock = { t: Date.now() };
  const codes = new Map();
  const links = new Map();
  const notices = [];
  const ps = fakePaystack();
  const channel = {
    name: 'test',
    sendOtp: async (to, code) => { codes.set(to, code); return 'm'; },
    sendInvitation: async (to, { link }) => { links.set(to, link); return 'm'; },
    sendNotice: async (to, notice) => { notices.push({ to, ...notice }); return 'm'; }
  };
  const app = createApp({
    db,
    tokenSecret: TOKEN_SECRET,
    paystackSecretKey: PAYSTACK_KEY,
    paystack: ps.client,
    encryptionKey: ENC_KEY,
    billingPlans: plans,
    trialDays,
    graceDays,
    now: () => clock.t,
    appUrl: 'https://app.test',
    phoneChannels: [channel],
    emailChannels: [channel]
  });
  const server = app.listen(0);
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    billing: app.services.billing,
    codes, links, clock, ps, notices,
    close() { server.close(); server.closeAllConnections?.(); }
  };
}

const phoneFor = (n) => '0801' + String(n).padStart(7, '0');
const normalized = (n) => '234' + phoneFor(n).slice(1);

async function api(ctx, method, path, { token, body } = {}) {
  const res = await fetch(ctx.base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let out = null;
  try { out = await res.json(); } catch { /* empty */ }
  return { status: res.status, body: out };
}

async function signIn(ctx, n) {
  await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(n) } });
  const r = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(n), code: ctx.codes.get(normalized(n)) } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return { n, token: r.body.token, userId: r.body.user.id };
}

async function addMember(ctx, inviter, bizId, member, role) {
  const inv = await api(ctx, 'POST', `/businesses/${bizId}/invitations`, { token: inviter.token, body: { phone: phoneFor(member.n), role } });
  assert.equal(inv.status, 201, JSON.stringify(inv.body));
  const token = new URL(ctx.links.get(normalized(member.n))).searchParams.get('token');
  const joined = await api(ctx, 'POST', '/invitations/accept', { token: member.token, body: { token } });
  assert.equal(joined.status, 200, JSON.stringify(joined.body));
  return { ...member, role };
}

// Signed Paystack webhook, the same way Paystack sends it.
async function webhook(ctx, { id, reference, amount, currency = 'NGN' }) {
  const body = JSON.stringify({ event: 'charge.success', data: { id, reference, amount, currency } });
  const sig = crypto.createHmac('sha512', PAYSTACK_KEY).update(body).digest('hex');
  const res = await fetch(`${ctx.base}/webhooks/paystack`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-paystack-signature': sig },
    body
  });
  return { status: res.status, body: await res.json() };
}

async function newBusiness(ctx, owner, name = 'Ada Designs') {
  const r = await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return r.body.id;
}

// Owner buys a plan: checkout, then Paystack confirms the payment through the webhook.
async function subscribe(ctx, owner, bizId, plan = 'growth', interval = 'monthly', { authorizationCode = 'AUTH_1' } = {}) {
  const c = await api(ctx, 'POST', `/businesses/${bizId}/subscription/checkout`, {
    token: owner.token, body: { plan, interval, email: 'owner@example.com' }
  });
  assert.equal(c.status, 201, JSON.stringify(c.body));
  ctx.ps.verifyResult.set(c.body.reference, { amount: c.body.amount, currency: 'NGN', authorizationCode });
  const w = await webhook(ctx, { id: Math.floor(Math.random() * 1e9), reference: c.body.reference, amount: c.body.amount });
  assert.equal(w.body.status, 'applied', JSON.stringify(w.body));
  return c.body;
}

const invoiceBody = (extra = {}) => ({
  client: 'Tunde Bello', phone: '08012345678', lines: [{ desc: 'Logo', qty: 1, price: 1000 }], ...extra
});

test('a new business starts on a 14-day trial with the trial plan', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    const s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.status, 200);
    assert.equal(s.body.state, 'trial');
    assert.equal(s.body.plan, 'growth');
    const days = (new Date(s.body.periodEnd).getTime() - ctx.clock.t) / DAY;
    assert.ok(days > 13.9 && days < 14.1, `trial length was ${days} days`);
  } finally { ctx.close(); }
});

test('checkout is priced from the plan and rejects bad input', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    const url = `/businesses/${biz}/subscription/checkout`;
    const monthly = await api(ctx, 'POST', url, { token: owner.token, body: { plan: 'growth', interval: 'monthly', email: 'o@example.com' } });
    assert.equal(monthly.body.amount, 150000);
    const yearly = await api(ctx, 'POST', url, { token: owner.token, body: { plan: 'growth', interval: 'yearly', email: 'o@example.com' } });
    assert.equal(yearly.body.amount, 1500000);
    assert.match(yearly.body.authorizationUrl, /^https:\/\/paystack\.test\/pay\//);

    assert.equal((await api(ctx, 'POST', url, { token: owner.token, body: { plan: 'platinum', interval: 'monthly', email: 'o@example.com' } })).status, 400);
    assert.equal((await api(ctx, 'POST', url, { token: owner.token, body: { plan: 'growth', interval: 'weekly', email: 'o@example.com' } })).status, 400);
    assert.equal((await api(ctx, 'POST', url, { token: owner.token, body: { plan: 'growth', interval: 'monthly', email: 'nope' } })).status, 400);
  } finally { ctx.close(); }
});

test('a confirmed checkout activates the plan for one billing period, and a repeat webhook changes nothing', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    await subscribe(ctx, owner, biz, 'growth', 'monthly');

    const s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.state, 'active');
    assert.equal(s.body.interval, 'monthly');
    const days = (new Date(s.body.periodEnd).getTime() - ctx.clock.t) / DAY;
    assert.ok(days > 29 && days < 32, `period was ${days} days`);

    const stored = (await db.query('SELECT authorization_code_enc FROM subscriptions WHERE business_id = $1', [biz])).rows[0];
    assert.ok(stored.authorization_code_enc, 'card token is stored');
    assert.equal(stored.authorization_code_enc.includes('AUTH_1'), false, 'card token is encrypted');

    // Replay the same payment: the period must not be extended twice.
    const before = s.body.periodEnd;
    const payRef = (await db.query("SELECT reference FROM subscription_payments WHERE business_id = $1 AND status = 'paid'", [biz])).rows[0].reference;
    const replay = await webhook(ctx, { id: 999001, reference: payRef, amount: 150000 });
    assert.equal(replay.body.status, 'duplicate');
    const after = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(after.body.periodEnd, before);
  } finally { ctx.close(); }
});

test('a payment whose amount Paystack does not confirm is never applied', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    const c = await api(ctx, 'POST', `/businesses/${biz}/subscription/checkout`, { token: owner.token, body: { plan: 'scale', interval: 'monthly', email: 'o@example.com' } });
    ctx.ps.verifyResult.set(c.body.reference, { amount: 1, currency: 'NGN', authorizationCode: 'X' });
    const r = await webhook(ctx, { id: 555, reference: c.body.reference, amount: c.body.amount });
    assert.equal(r.body.status, 'mismatch');
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token })).body.plan, 'growth');
  } finally { ctx.close(); }
});

test('the plan member limit counts pending invitations and refuses the next one with 402', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    // Growth on trial allows 2 members. The owner is one of them.
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: owner.token, body: { phone: phoneFor(2), role: 'staff' } })).status, 201);
    const over = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: owner.token, body: { phone: phoneFor(3), role: 'staff' } });
    assert.equal(over.status, 402);
    assert.match(over.body.error, /2 team members/);
  } finally { ctx.close(); }
});

test('the monthly invoice limit is enforced under concurrent requests', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    // Growth on trial allows 3 invoices a month. Fire 6 at once.
    const results = await Promise.all(Array.from({ length: 6 }, () =>
      api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: owner.token, body: invoiceBody() })));
    assert.equal(results.filter((r) => r.status === 201).length, 3);
    assert.equal(results.filter((r) => r.status === 402).length, 3);
    const s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.usage.invoicesThisMonth, 3);
  } finally { ctx.close(); }
});

test('an expired subscription blocks new work but keeps reads, and customers can still pay', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    const inv = await api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: owner.token, body: invoiceBody() });
    assert.equal(inv.status, 201);

    // The trial ends.
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 day' WHERE business_id = $1", [biz]);

    const s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.state, 'expired');
    assert.equal(s.body.writable, false);

    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: owner.token, body: invoiceBody() })).status, 402);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/invoices/1`, { token: owner.token })).status, 200);

    // A customer paying an invoice that already exists still goes through.
    ctx.ps.verifyResult.set(inv.body.paymentReference, { amount: inv.body.total, currency: 'NGN' });
    const pay = await webhook(ctx, { id: 777, reference: inv.body.paymentReference, amount: inv.body.total });
    assert.equal(pay.body.status, 'applied');
  } finally { ctx.close(); }
});

test('a due renewal charges the saved card and extends the period', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    await subscribe(ctx, owner, biz, 'growth', 'monthly', { authorizationCode: 'AUTH_1' });

    // The period has just ended.
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);

    const summary = await ctx.billing.runRenewals();
    assert.deepEqual(summary, { charged: 1, failed: 0, skipped: 0 });
    assert.equal(ctx.ps.charges[0].authorizationCode, 'AUTH_1');
    assert.equal(ctx.ps.charges[0].amount, 150000);

    const s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.state, 'active');
    const paid = (await db.query("SELECT count(*) AS n FROM subscription_payments WHERE business_id = $1 AND reference LIKE 'sub_ren_%' AND status = 'paid'", [biz])).rows[0].n;
    assert.equal(paid, 1);
  } finally { ctx.close(); }
});

test('a failed renewal goes into a grace period, and suspends the account once that ends', async () => {
  const ctx = await setup({ graceDays: 3 });
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    await subscribe(ctx, owner, biz, 'growth', 'monthly');
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);

    ctx.ps.chargeResult = { status: 'failed', message: 'Insufficient funds' };
    assert.deepEqual(await ctx.billing.runRenewals(), { charged: 0, failed: 1, skipped: 0 });

    let s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.state, 'past_due');
    assert.equal(s.body.writable, true, 'writes stay open during the grace period');
    const grace = (new Date(s.body.graceUntil).getTime() - ctx.clock.t) / DAY;
    assert.ok(grace > 2.9 && grace < 3.1);

    // A later failed retry doesn't restart the grace period.
    const graceBefore = s.body.graceUntil;
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);
    await ctx.billing.runRenewals();
    s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.graceUntil, graceBefore);

    // Grace runs out: suspended, and no more charges are attempted.
    await db.query("UPDATE subscriptions SET grace_until = now() - interval '1 hour' WHERE business_id = $1", [biz]);
    const chargesBefore = ctx.ps.charges.length;
    await ctx.billing.runRenewals();
    assert.equal(ctx.ps.charges.length, chargesBefore);
    s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.state, 'expired');
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: owner.token, body: invoiceBody() })).status, 402);
  } finally { ctx.close(); }
});

test('overlapping renewal runs never charge the same period twice', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    await subscribe(ctx, owner, biz, 'growth', 'monthly');
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);

    // Slow the charge down so the two runs really overlap.
    ctx.ps.chargeResult = async () => { await new Promise((r) => setTimeout(r, 100)); return { status: 'success' }; };
    const [a, b] = await Promise.all([ctx.billing.runRenewals(), ctx.billing.runRenewals()]);
    assert.equal(ctx.ps.charges.length, 1, 'the card must be charged exactly once');
    assert.equal(a.charged + b.charged, 1);
  } finally { ctx.close(); }
});

test('cancelling keeps access until the period ends, removes the saved card, and stops renewals', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    await subscribe(ctx, owner, biz, 'growth', 'monthly');

    const c = await api(ctx, 'POST', `/businesses/${biz}/subscription/cancel`, { token: owner.token });
    assert.equal(c.status, 200);

    const s = await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: owner.token });
    assert.equal(s.body.state, 'cancelled');
    assert.equal(s.body.writable, true);

    const card = (await db.query('SELECT authorization_code_enc FROM subscriptions WHERE business_id = $1', [biz])).rows[0];
    assert.equal(card.authorization_code_enc, null);

    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);
    assert.equal((await ctx.billing.runRenewals()).charged, 0);
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/subscription/cancel`, { token: owner.token })).status, 409);
  } finally { ctx.close(); }
});

test('only the owner can buy or cancel a plan; admins can view it', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    const admin = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'admin');
    const staffless = await signIn(ctx, 3); // not a member at all

    const body = { plan: 'growth', interval: 'monthly', email: 'o@example.com' };
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/subscription/checkout`, { token: admin.token, body })).status, 403);
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/subscription/cancel`, { token: admin.token })).status, 403);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: admin.token })).status, 200);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/subscription`, { token: staffless.token })).status, 404);
  } finally { ctx.close(); }
});

test('a renewal retry is recorded as a new attempt, and every attempt is logged without card details', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    await subscribe(ctx, owner, biz, 'growth', 'monthly');
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);
    ctx.ps.chargeResult = { status: 'failed' };
    await ctx.billing.runRenewals();
    const refs = (await db.query("SELECT reference, status FROM subscription_payments WHERE reference LIKE 'sub_ren_%'")).rows;
    assert.equal(refs.length, 1);
    assert.equal(refs[0].status, 'failed');
    const rows = JSON.stringify((await db.query('SELECT * FROM subscription_payments')).rows);
    assert.equal(rows.includes('AUTH_1'), false);
  } finally { ctx.close(); }
});

test('the owner is told once when a renewal fails, not on every retry', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await newBusiness(ctx, owner);
    await subscribe(ctx, owner, biz, 'growth', 'monthly');
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);

    ctx.ps.chargeResult = { status: 'failed' };
    await ctx.billing.runRenewals();
    assert.equal(ctx.notices.length, 1);
    assert.equal(ctx.notices[0].to, normalized(1));
    assert.match(ctx.notices[0].text, /Renew by \d{4}-\d{2}-\d{2}/);
    assert.equal(ctx.notices[0].businessName, 'Ada Designs');

    // A retry inside the same grace period sends nothing new.
    await db.query("UPDATE subscriptions SET current_period_end = now() - interval '1 minute' WHERE business_id = $1", [biz]);
    await ctx.billing.runRenewals();
    assert.equal(ctx.notices.length, 1);
  } finally { ctx.close(); }
});
