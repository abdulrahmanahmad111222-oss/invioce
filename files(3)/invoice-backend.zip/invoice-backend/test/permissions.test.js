import { test } from 'node:test';
import assert from 'node:assert/strict';
import { can, PERMISSIONS } from '../src/permissions.js';

test('owner has every permission', () => {
  const all = [...new Set(Object.values(PERMISSIONS).flat())];
  for (const p of all) assert.ok(can('owner', p), `owner should have ${p}`);
});

test('only the owner manages billing', () => {
  assert.equal(can('owner', 'billing.manage'), true);
  assert.equal(can('admin', 'billing.manage'), false);
  assert.equal(can('manager', 'billing.manage'), false);
});

test('staff can create and record, but cannot void, refund, invite or read reports', () => {
  assert.equal(can('staff', 'invoices.create'), true);
  assert.equal(can('staff', 'payments.record'), true);
  assert.equal(can('staff', 'invoices.void'), false);
  assert.equal(can('staff', 'payments.refund'), false);
  assert.equal(can('staff', 'members.invite'), false);
  assert.equal(can('staff', 'reports.view'), false);
});

test('managers can void and refund, but cannot manage members', () => {
  assert.equal(can('manager', 'invoices.void'), true);
  assert.equal(can('manager', 'payments.refund'), true);
  assert.equal(can('manager', 'members.invite'), false);
  assert.equal(can('manager', 'members.manage'), false);
});

test('accountants are read-only', () => {
  for (const p of PERMISSIONS.accountant) {
    assert.ok(p.endsWith('.view'), `accountant has write permission ${p}`);
  }
  assert.equal(can('accountant', 'invoices.create'), false);
  assert.equal(can('accountant', 'payments.record'), false);
});

test('unknown or malicious role names have no permissions', () => {
  assert.equal(can('hacker', 'invoices.view'), false);
  assert.equal(can('__proto__', 'invoices.view'), false);
  assert.equal(can('constructor', 'invoices.view'), false);
  assert.equal(can(undefined, 'invoices.view'), false);
});
