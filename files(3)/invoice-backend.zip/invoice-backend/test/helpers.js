import { createDb } from '../src/db.js';
import { migrate } from '../src/migrate.js';

const url = process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/invoice_test';
// Safety: the helper wipes tables, so it refuses any database that doesn't look like a test database.
if (!new URL(url).pathname.endsWith('_test')) {
  throw new Error('TEST_DATABASE_URL must point at a database whose name ends in _test');
}

export const db = createDb(url);
await migrate(db);

export async function resetDb() {
  await db.query(`TRUNCATE audit_log, ledger_entries, payment_events, invoices, invoice_counters,
                  invitations, memberships, businesses, sessions, otp_codes, users, notifications, business_gmail, subscriptions, subscription_payments, payment_attempts
                  RESTART IDENTITY CASCADE`);
}
