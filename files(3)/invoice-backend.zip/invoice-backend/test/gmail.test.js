import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createApp } from '../src/server.js';
import { createGoogleOAuth, buildRawEmail } from '../src/gmail.js';
import { createBox } from '../src/crypto-box.js';
import { signToken } from '../src/tokens.js';
import { createInvoiceStore } from '../src/invoices.js';
import { createAudit } from '../src/audit.js';
import { db, resetDb } from './helpers.js';

const TOKEN_SECRET = 'test-token-secret';
const ENC_KEY = crypto.randomBytes(32).toString('base64');
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });

// Fake Google. Records token grants, sends, and revocations.
function fakeGoogle() {
  const calls = { grants: [], sends: [], revokes: [] };
  let failSend = false;
  const fn = async (url, opts = {}) => {
    const u = String(url);
    if (u.startsWith('https://oauth2.googleapis.com/token')) {
      const params = Object.fromEntries(new URLSearchParams(opts.body));
      calls.grants.push(params.grant_type);
      if (params.grant_type === 'authorization_code') return json({ access_token: 'at-1', refresh_token: 'rt-secret-1' });
      if (params.grant_type === 'refresh_token') return json({ access_token: 'at-2' });
      return json({ error: 'unsupported_grant_type' }, 400);
    }
    if (u.startsWith('https://www.googleapis.com/oauth2/v3/userinfo')) return json({ email: 'shop@gmail.com', email_verified: true });
    if (u.startsWith('https://oauth2.googleapis.com/revoke')) {
      calls.revokes.push(new URL(u).searchParams.get('token'));
      return new Response('', { status: 200 });
    }
    if (u === 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send') {
      if (failSend) return json({ error: { message: 'Gmail API has not been used in this project' } }, 403);
      const body = JSON.parse(opts.body);
      calls.sends.push({ auth: opts.headers.Authorization, raw: body.raw });
      return json({ id: 'gm-' + calls.sends.length });
    }
    return json({ error: 'unexpected ' + u }, 500);
  };
  fn.calls = calls;
  fn.failSend = (v) => { failSend = v; };
  return fn;
}

async function setup() {
  await resetDb();
  const clock = { t: Date.now() };
  const codes = new Map();
  const links = new Map();
  const google = fakeGoogle();
  const phoneChannel = {
    name: 'test',
    sendOtp: async (to, code) => { codes.set(to, code); return 'm'; },
    sendInvitation: async (to, { link }) => { links.set(to, link); return 'm'; }
  };
  const oauth = createGoogleOAuth({
    clientId: 'cid', clientSecret: 'sec',
    redirectUri: 'https://api.test/auth/gmail/callback',
    fetchImpl: google
  });
  const app = createApp({
    db,
    tokenSecret: TOKEN_SECRET,
    paystackSecretKey: 'sk_test',
    now: () => clock.t,
    appUrl: 'https://app.test',
    phoneChannels: [phoneChannel],
    verifyTransaction: async () => null,
    fetchImpl: google,
    gmailOAuth: oauth,
    encryptionKey: ENC_KEY
  });
  const server = app.listen(0);
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    codes, links, clock, google,
    close() { server.close(); server.closeAllConnections?.(); }
  };
}

const phoneFor = (n) => '0801' + String(n).padStart(7, '0');
const normalized = (n) => '234' + phoneFor(n).slice(1);

async function api(ctx, method, path, { token, body } = {}) {
  const res = await fetch(ctx.base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let out = null;
  try { out = await res.json(); } catch { /* empty */ }
  return { status: res.status, body: out };
}

async function signIn(ctx, n) {
  await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(n) } });
  const r = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(n), code: ctx.codes.get(normalized(n)) } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return { n, token: r.body.token, userId: r.body.user.id };
}

async function addMember(ctx, inviter, bizId, member, role) {
  const inv = await api(ctx, 'POST', `/businesses/${bizId}/invitations`, { token: inviter.token, body: { phone: phoneFor(member.n), role } });
  assert.equal(inv.status, 201, JSON.stringify(inv.body));
  const token = new URL(ctx.links.get(normalized(member.n))).searchParams.get('token');
  const joined = await api(ctx, 'POST', '/invitations/accept', { token: member.token, body: { token } });
  assert.equal(joined.status, 200, JSON.stringify(joined.body));
  return { ...member, role };
}

// Runs the real connect flow: ask for the URL, then let Google's redirect hit the callback.
async function connectGmail(ctx, user, bizId) {
  const c = await api(ctx, 'GET', `/businesses/${bizId}/gmail/connect`, { token: user.token });
  assert.equal(c.status, 200, JSON.stringify(c.body));
  const state = new URL(c.body.url).searchParams.get('state');
  const res = await fetch(`${ctx.base}/auth/gmail/callback?code=auth-code&state=${encodeURIComponent(state)}`, { redirect: 'manual' });
  return { status: res.status, location: res.headers.get('location'), state };
}

const decodeRaw = (raw) => Buffer.from(raw, 'base64url').toString('utf8');
const decodeSubject = (msg) => {
  const m = msg.match(/^Subject: =\?UTF-8\?B\?(.+?)\?=/m);
  return Buffer.from(m[1], 'base64').toString('utf8');
};
const decodeBody = (msg) => {
  const body = msg.split('\r\n\r\n')[1].replace(/\r\n/g, '');
  return Buffer.from(body, 'base64').toString('utf8');
};

test('only owners and admins can connect Gmail', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada Designs' } })).body.id;
    const manager = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'manager');
    const admin = await addMember(ctx, owner, biz, await signIn(ctx, 3), 'admin');

    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/gmail/connect`, { token: manager.token })).status, 403);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/gmail/connect`, { token: admin.token })).status, 200);
  } finally { ctx.close(); }
});

test('the consent URL asks for offline access and the gmail.send scope', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    const { body } = await api(ctx, 'GET', `/businesses/${biz}/gmail/connect`, { token: owner.token });
    const url = new URL(body.url);
    assert.equal(url.origin + url.pathname, 'https://accounts.google.com/o/oauth2/v2/auth');
    assert.equal(url.searchParams.get('access_type'), 'offline');
    assert.equal(url.searchParams.get('prompt'), 'consent');
    assert.match(url.searchParams.get('scope'), /gmail\.send/);
    assert.ok(url.searchParams.get('state'));
  } finally { ctx.close(); }
});

test('connecting stores the refresh token encrypted and reports the connected address', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    const r = await connectGmail(ctx, owner, biz);
    assert.equal(r.status, 302);
    assert.match(r.location, /^https:\/\/app\.test\/b\/biz_[0-9a-f]+\/settings\?gmail=connected$/);

    const row = (await db.query('SELECT email, refresh_token_enc FROM business_gmail WHERE business_id = $1', [biz])).rows[0];
    assert.equal(row.email, 'shop@gmail.com');
    assert.equal(row.refresh_token_enc.includes('rt-secret-1'), false, 'refresh token must not be stored in plain text');

    const status = await api(ctx, 'GET', `/businesses/${biz}/gmail`, { token: owner.token });
    assert.equal(status.body.connected, true);
    assert.equal(status.body.email, 'shop@gmail.com');
    assert.equal(JSON.stringify(status.body).includes('rt-secret'), false);
  } finally { ctx.close(); }
});

test('a forged, expired, or wrong-purpose state is rejected and nothing is stored', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    const cb = (state) => fetch(`${ctx.base}/auth/gmail/callback?code=x&state=${encodeURIComponent(state)}`, { redirect: 'manual' });

    assert.equal((await cb('garbage')).status, 400);
    const otherSecret = signToken({ purpose: 'gmail-connect', biz, uid: owner.userId }, 'attacker-secret', 600);
    assert.equal((await cb(otherSecret)).status, 400);
    const wrongPurpose = signToken({ purpose: 'login', biz, uid: owner.userId }, TOKEN_SECRET, 600);
    assert.equal((await cb(wrongPurpose)).status, 400);
    const expired = signToken({ purpose: 'gmail-connect', biz, uid: owner.userId }, TOKEN_SECRET, -10);
    assert.equal((await cb(expired)).status, 400);

    assert.equal((await db.query('SELECT 1 FROM business_gmail')).rows.length, 0);
  } finally { ctx.close(); }
});

test('the connection belongs to the person who started it: a demoted admin cannot finish it', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    const admin = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'admin');

    const c = await api(ctx, 'GET', `/businesses/${biz}/gmail/connect`, { token: admin.token });
    const state = new URL(c.body.url).searchParams.get('state');

    // The owner demotes the admin before the admin finishes consenting.
    await api(ctx, 'PATCH', `/businesses/${biz}/members/${admin.userId}`, { token: owner.token, body: { role: 'staff' } });

    const res = await fetch(`${ctx.base}/auth/gmail/callback?code=x&state=${encodeURIComponent(state)}`, { redirect: 'manual' });
    assert.equal(res.status, 403);
    assert.equal((await db.query('SELECT 1 FROM business_gmail')).rows.length, 0);
  } finally { ctx.close(); }
});

test('an invoice is emailed from the business Gmail, with the amount and payment link', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada Designs' } })).body.id;
    await connectGmail(ctx, owner, biz);

    const inv = await api(ctx, 'POST', `/businesses/${biz}/invoices`, {
      token: owner.token,
      body: { client: 'Tunde Bello', clientEmail: 'Tunde@Example.com', phone: '08012345678', due: '2026-12-31',
        lines: [{ desc: 'Logo design', qty: 1, price: 150000 }] }
    });
    assert.equal(inv.status, 201);
    assert.equal(inv.body.clientEmail, 'tunde@example.com');

    const r = await api(ctx, 'POST', `/businesses/${biz}/invoices/1/email`, { token: owner.token });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(r.body.channel, 'gmail');

    const sends = ctx.google.calls.sends;
    assert.equal(sends.length, 1);
    assert.equal(sends[0].auth, 'Bearer at-2', 'a fresh access token is used for sending');
    const msg = decodeRaw(sends[0].raw);
    assert.match(msg, /^From: shop@gmail\.com/m);
    assert.match(msg, /^To: tunde@example\.com/m);
    assert.match(decodeSubject(msg), /INV-0001 from Ada Designs/);
    const body = decodeBody(msg);
    assert.match(body, /₦150,000\.00/);
    assert.match(body, new RegExp(`https://app\\.test/pay/${inv.body.paymentReference}`));

    const log = (await db.query("SELECT channel, status, purpose FROM notifications WHERE purpose = 'invoice'")).rows;
    assert.deepEqual(log, [{ channel: 'gmail', status: 'sent', purpose: 'invoice' }]);
    const audit = (await db.query("SELECT 1 FROM audit_log WHERE action = 'invoice.emailed'")).rows;
    assert.equal(audit.length, 1);
  } finally { ctx.close(); }
});

test('an invoice with no client email cannot be sent', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    await connectGmail(ctx, owner, biz);
    await api(ctx, 'POST', `/businesses/${biz}/invoices`, {
      token: owner.token, body: { client: 'No Email', phone: '08012345678', lines: [{ desc: 'x', qty: 1, price: 100 }] }
    });
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices/1/email`, { token: owner.token })).status, 400);
  } finally { ctx.close(); }
});

test('invoice emails fail cleanly when no Gmail account is connected', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    await api(ctx, 'POST', `/businesses/${biz}/invoices`, {
      token: owner.token, body: { client: 'T', clientEmail: 't@example.com', phone: '08012345678', lines: [{ desc: 'x', qty: 1, price: 100 }] }
    });
    const r = await api(ctx, 'POST', `/businesses/${biz}/invoices/1/email`, { token: owner.token });
    assert.equal(r.status, 502);
    assert.match(r.body.error, /Gmail account is connected/);
  } finally { ctx.close(); }
});

test('a Gmail API error returns 502 and is logged as a failed attempt', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    await connectGmail(ctx, owner, biz);
    await api(ctx, 'POST', `/businesses/${biz}/invoices`, {
      token: owner.token, body: { client: 'T', clientEmail: 't@example.com', phone: '08012345678', lines: [{ desc: 'x', qty: 1, price: 100 }] }
    });
    ctx.google.failSend(true);
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices/1/email`, { token: owner.token })).status, 502);
    const row = (await db.query("SELECT status, error FROM notifications WHERE purpose = 'invoice'")).rows[0];
    assert.equal(row.status, 'failed');
    assert.match(row.error, /has not been used/);
  } finally { ctx.close(); }
});

test('email invitations go out from the connected Gmail account', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada Designs' } })).body.id;
    await connectGmail(ctx, owner, biz);

    const inv = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: owner.token, body: { email: 'ada@example.com', role: 'staff' } });
    assert.equal(inv.status, 201, JSON.stringify(inv.body));
    assert.equal(inv.body.delivery.channel, 'gmail');

    const msg = decodeRaw(ctx.google.calls.sends.at(-1).raw);
    assert.match(msg, /^To: ada@example\.com/m);
    assert.match(decodeBody(msg), /https:\/\/app\.test\/join\?token=/);
  } finally { ctx.close(); }
});

test('disconnecting removes the connection, revokes the token, and stops sending', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    await connectGmail(ctx, owner, biz);

    const del = await api(ctx, 'DELETE', `/businesses/${biz}/gmail`, { token: owner.token });
    assert.equal(del.status, 200);
    assert.deepEqual(ctx.google.calls.revokes, ['rt-secret-1']);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/gmail`, { token: owner.token })).body.connected, false);

    await api(ctx, 'POST', `/businesses/${biz}/invoices`, {
      token: owner.token, body: { client: 'T', clientEmail: 't@example.com', phone: '08012345678', lines: [{ desc: 'x', qty: 1, price: 100 }] }
    });
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices/1/email`, { token: owner.token })).status, 502);
  } finally { ctx.close(); }
});

test('staff cannot read or change the Gmail connection', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = (await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada' } })).body.id;
    const staff = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'staff');
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/gmail`, { token: staff.token })).status, 403);
    assert.equal((await api(ctx, 'DELETE', `/businesses/${biz}/gmail`, { token: staff.token })).status, 403);
  } finally { ctx.close(); }
});

test('the encryption box rejects tampered data and wrong key sizes', () => {
  const box = createBox(ENC_KEY);
  const sealed = box.encrypt('rt-secret-1');
  assert.equal(box.decrypt(sealed), 'rt-secret-1');
  const bytes = Buffer.from(sealed, 'base64');
  bytes[bytes.length - 1] ^= 0x01;
  assert.throws(() => box.decrypt(bytes.toString('base64')));
  assert.throws(() => createBox(crypto.randomBytes(16).toString('base64')), /32 random bytes/);
});

test('client email addresses with line breaks are rejected, which blocks header injection', async () => {
  await resetDb();
  await db.query("INSERT INTO users (id, phone) VALUES ('usr_x', '2340000000009')");
  await db.query("INSERT INTO businesses (id, name, owner_user_id) VALUES ('biz_x', 'Shop', 'usr_x')");
  const invoices = createInvoiceStore({ db, audit: createAudit({ db }) });
  await assert.rejects(
    invoices.createInvoice('biz_x', {
      client: 'T', clientEmail: 'a@b.com\r\nBcc: victim@example.com', phone: '08012345678',
      lines: [{ desc: 'x', qty: 1, price: 100 }]
    }, 'usr_x'),
    /email is not valid/
  );
});

test('the raw MIME builder encodes non-ASCII subjects and strips line breaks from headers', () => {
  const raw = buildRawEmail({ from: 'a@x.com', to: 'b@y.com', subject: 'Invoice ₦\r\nBcc: z@z.com', text: 'hi' });
  const msg = decodeRaw(raw);
  assert.equal(/^Bcc:/m.test(msg), false);
  assert.match(msg, /^Subject: =\?UTF-8\?B\?/m);
});
