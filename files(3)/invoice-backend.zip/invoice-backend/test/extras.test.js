import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { db, resetDb } from './helpers.js';

async function setup() {
  await resetDb();
  const app = createApp({ db, tokenSecret: 'x', paystackSecretKey: 'sk', appUrl: 'https://web.test', apiUrl: 'https://api.test' });
  const server = app.listen(0);
  return { base: `http://127.0.0.1:${server.address().port}`, invoices: app.services.invoices,
    close() { server.close(); server.closeAllConnections?.(); } };
}

test('the API answers CORS preflight for the web app only', async () => {
  const ctx = await setup();
  try {
    const ok = await fetch(`${ctx.base}/me/businesses`, { method: 'OPTIONS', headers: { origin: 'https://web.test', 'access-control-request-method': 'GET' } });
    assert.equal(ok.status, 204);
    assert.equal(ok.headers.get('access-control-allow-origin'), 'https://web.test');
    assert.match(ok.headers.get('access-control-allow-headers'), /authorization/);

    const other = await fetch(`${ctx.base}/me/businesses`, { method: 'OPTIONS', headers: { origin: 'https://evil.test' } });
    assert.equal(other.headers.get('access-control-allow-origin'), null);
  } finally { ctx.close(); }
});

test('/me returns the signed-in user and rejects anonymous callers', async () => {
  const ctx = await setup();
  try {
    assert.equal((await fetch(`${ctx.base}/me`)).status, 401);
    await db.query("INSERT INTO users (id, phone) VALUES ('usr_me', '2340000000004')");
    const { signToken } = await import('../src/tokens.js');
    const sessionId = 'ses_me';
    await db.query("INSERT INTO sessions (id, user_id, expires_at) VALUES ($1, 'usr_me', now() + interval '1 hour')", [sessionId]);
    const token = signToken({ sid: sessionId }, 'x', 600);
    const r = await fetch(`${ctx.base}/me`, { headers: { authorization: `Bearer ${token}` } });
    assert.equal(r.status, 200);
    assert.deepEqual(await r.json(), { id: 'usr_me', phone: '2340000000004', email: null });
  } finally { ctx.close(); }
});

test('invoices are listed newest first and only for the business asked for', async () => {
  const ctx = await setup();
  try {
    await db.query("INSERT INTO users (id, phone) VALUES ('usr_l', '2340000000003')");
    await db.query("INSERT INTO businesses (id, name, owner_user_id) VALUES ('biz_l', 'L', 'usr_l')");
    await db.query("INSERT INTO businesses (id, name, owner_user_id) VALUES ('biz_m', 'M', 'usr_l')");
    const line = [{ desc: 'x', qty: 1, price: 100 }];
    await ctx.invoices.createInvoice('biz_l', { client: 'A', phone: '08012345678', lines: line }, 'usr_l');
    await ctx.invoices.createInvoice('biz_l', { client: 'B', phone: '08012345678', lines: line }, 'usr_l');
    await ctx.invoices.createInvoice('biz_m', { client: 'C', phone: '08012345678', lines: line }, 'usr_l');
    const list = await ctx.invoices.list('biz_l');
    assert.deepEqual(list.map((i) => i.client), ['B', 'A']);
  } finally { ctx.close(); }
});

test('sign-in requests are rate limited per client', async () => {
  await resetDb();
  const app = createApp({ db, tokenSecret: 'x', paystackSecretKey: 'sk', authLimit: 3, otpSender: undefined, phoneChannels: [{
    name: 'test', sendOtp: async () => 'm', sendInvitation: async () => 'm'
  }] });
  const server = app.listen(0);
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const statuses = [];
    for (let n = 1; n <= 4; n++) {
      const r = await fetch(`${base}/auth/otp/request`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ phone: '080' + String(n).padStart(8, '0') })
      });
      statuses.push(r.status);
      if (r.status === 429) assert.match((await r.json()).error, /too many attempts/);
    }
    assert.deepEqual(statuses, [200, 200, 200, 429]);
  } finally { server.close(); server.closeAllConnections?.(); }
});
