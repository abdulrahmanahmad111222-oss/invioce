import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createApp } from '../src/server.js';
import { db, resetDb } from './helpers.js';

const KEY = 'sk_test';

function fakePaystack() {
  const s = { verify: new Map(), inits: [] };
  s.client = {
    verify: async (reference) => s.verify.get(reference) ?? null,
    initialize: async (args) => {
      s.inits.push(args);
      return { authorizationUrl: `https://paystack.test/checkout/${args.reference}` };
    },
    charge: async () => ({ status: 'success' })
  };
  return s;
}

async function setup() {
  await resetDb();
  const ps = fakePaystack();
  const app = createApp({
    db, tokenSecret: 'x', paystackSecretKey: KEY, paystack: ps.client, appUrl: 'https://app.test'
  });
  const server = app.listen(0);
  await db.query("INSERT INTO users (id, phone) VALUES ('usr_pay', '2340000000002')");
  await db.query("INSERT INTO businesses (id, name, owner_user_id) VALUES ('biz_pay', 'Ada & Sons <Designs>', 'usr_pay')");
  const inv = app.services.invoices;
  // No subscription row: a lapsed or never-subscribed business must still get paid by its customers.
  const withEmail = await inv.createInvoice('biz_pay', {
    client: 'Tunde <b>Bello</b>', clientEmail: 'tunde@example.com', phone: '08012345678',
    lines: [{ desc: 'Logo', qty: 2, price: 1000 }]
  }, 'usr_pay');
  const noEmail = await inv.createInvoice('biz_pay', {
    client: 'Ngozi', phone: '08012345678', lines: [{ desc: 'Flyer', qty: 1, price: 5000 }]
  }, 'usr_pay');
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    ps, withEmail, noEmail, invoices: inv,
    close() { server.close(); server.closeAllConnections?.(); }
  };
}

async function webhook(ctx, { id, reference, amount }) {
  const body = JSON.stringify({ event: 'charge.success', data: { id, reference, amount, currency: 'NGN' } });
  const sig = crypto.createHmac('sha512', KEY).update(body).digest('hex');
  const res = await fetch(`${ctx.base}/webhooks/paystack`, {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-paystack-signature': sig }, body
  });
  return (await res.json()).status;
}

const noRedirect = { redirect: 'manual' };

test('the payment page shows the invoice and escapes everything the business typed', async () => {
  const ctx = await setup();
  try {
    const res = await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`);
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /text\/html/);
    const html = await res.text();
    assert.match(html, /Ada &amp; Sons &lt;Designs&gt;/);
    assert.match(html, /Tunde &lt;b&gt;Bello&lt;\/b&gt;/);
    assert.equal(html.includes('<b>Bello</b>'), false, 'client name must be escaped');
    assert.match(html, /₦2,000\.00/);
    assert.match(html, /Pay ₦2,000\.00/);
  } finally { ctx.close(); }
});

test('an unknown payment link returns 404', async () => {
  const ctx = await setup();
  try {
    assert.equal((await fetch(`${ctx.base}/pay/nope`)).status, 404);
  } finally { ctx.close(); }
});

test('paying redirects to Paystack for the full balance, with a fresh reference each time', async () => {
  const ctx = await setup();
  try {
    const r1 = await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`, { method: 'POST', ...noRedirect });
    assert.equal(r1.status, 303);
    assert.match(r1.headers.get('location'), /^https:\/\/paystack\.test\/checkout\/pay_/);
    const r2 = await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`, { method: 'POST', ...noRedirect });
    assert.equal(r2.status, 303);

    assert.equal(ctx.ps.inits.length, 2);
    assert.equal(ctx.ps.inits[0].amount, 200000);
    assert.equal(ctx.ps.inits[0].email, 'tunde@example.com');
    assert.notEqual(ctx.ps.inits[0].reference, ctx.ps.inits[1].reference);
    assert.equal(ctx.ps.inits[0].callbackUrl, `https://app.test/pay/${ctx.withEmail.paymentReference}`);
  } finally { ctx.close(); }
});

test('when the invoice has no client email, the payer must give one', async () => {
  const ctx = await setup();
  try {
    const bad = await fetch(`${ctx.base}/pay/${ctx.noEmail.paymentReference}`, { method: 'POST', ...noRedirect,
      headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'email=not-an-email' });
    assert.equal(bad.status, 400);

    const ok = await fetch(`${ctx.base}/pay/${ctx.noEmail.paymentReference}`, { method: 'POST', ...noRedirect,
      headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'email=ngozi%40example.com' });
    assert.equal(ok.status, 303);
    assert.equal(ctx.ps.inits.at(-1).email, 'ngozi@example.com');
    assert.equal(ctx.ps.inits.at(-1).amount, 500000);
  } finally { ctx.close(); }
});

test('a confirmed payment marks the invoice paid, and the page then stops asking for money', async () => {
  const ctx = await setup();
  try {
    await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`, { method: 'POST', ...noRedirect });
    const ref = ctx.ps.inits[0].reference;
    ctx.ps.verify.set(ref, { amount: 200000, currency: 'NGN' });

    assert.equal(await webhook(ctx, { id: 1001, reference: ref, amount: 200000 }), 'applied');
    assert.equal(await webhook(ctx, { id: 1001, reference: ref, amount: 200000 }), 'duplicate');

    const inv = await ctx.invoices.getInvoice('biz_pay', ctx.withEmail.no);
    assert.equal(inv.status, 'Paid');
    const html = await (await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`)).text();
    assert.match(html, /Paid\. Thank you\./);
    assert.equal(html.includes('Pay ₦'), false);

    const again = await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`, { method: 'POST', ...noRedirect });
    assert.equal(again.status, 409);
  } finally { ctx.close(); }
});

test('a payment Paystack does not confirm at the right amount is not applied', async () => {
  const ctx = await setup();
  try {
    await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`, { method: 'POST', ...noRedirect });
    const ref = ctx.ps.inits[0].reference;
    ctx.ps.verify.set(ref, { amount: 100, currency: 'NGN' });
    assert.equal(await webhook(ctx, { id: 2001, reference: ref, amount: 200000 }), 'mismatch');
    assert.equal((await ctx.invoices.getInvoice('biz_pay', ctx.withEmail.no)).paid, 0);
  } finally { ctx.close(); }
});

test('a cancelled invoice cannot be paid, and the page says so', async () => {
  const ctx = await setup();
  try {
    await ctx.invoices.voidInvoice('biz_pay', ctx.withEmail.no, 'usr_pay');
    const html = await (await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`)).text();
    assert.match(html, /This invoice has been cancelled\./);
    assert.equal((await fetch(`${ctx.base}/pay/${ctx.withEmail.paymentReference}`, { method: 'POST', ...noRedirect })).status, 409);
  } finally { ctx.close(); }
});
