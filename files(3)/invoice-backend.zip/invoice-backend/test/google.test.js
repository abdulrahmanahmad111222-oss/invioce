import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { db, resetDb } from './helpers.js';

const TOKEN_SECRET = 'test-token-secret';

// Fake Google: maps an ID token string to the verified profile Google would return.
async function setup() {
  await resetDb();
  const clock = { t: Date.now() };
  const codes = new Map();
  const links = new Map();
  const profiles = new Map();
  const channel = {
    name: 'test',
    sendOtp: async (to, code) => { codes.set(to, code); return 'msg'; },
    sendInvitation: async (to, { link }) => { links.set(to, link); return 'msg'; }
  };
  const app = createApp({
    db,
    tokenSecret: TOKEN_SECRET,
    paystackSecretKey: 'sk_test',
    now: () => clock.t,
    appUrl: 'https://app.test',
    phoneChannels: [channel],
    emailChannels: [channel],
    verifyTransaction: async () => null,
    googleVerifier: async (idToken) => {
      if (!profiles.has(idToken)) throw new Error('bad token');
      return profiles.get(idToken);
    }
  });
  const server = app.listen(0);
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    codes, links, clock, profiles,
    close() { server.close(); server.closeAllConnections?.(); }
  };
}

const linkToken = (ctx, to) => new URL(ctx.links.get(to)).searchParams.get('token');

const phoneFor = (n) => '0801' + String(n).padStart(7, '0');
const normalized = (n) => '234' + phoneFor(n).slice(1);

async function api(ctx, method, path, { token, body } = {}) {
  const res = await fetch(ctx.base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let json = null;
  try { json = await res.json(); } catch { /* empty */ }
  return { status: res.status, body: json };
}

function googleProfile(ctx, idToken, { sub, email, verified = true, name = 'Ada' }) {
  ctx.profiles.set(idToken, { sub, email, emailVerified: verified, name });
  return idToken;
}

async function googleSignIn(ctx, idToken) {
  const r = await api(ctx, 'POST', '/auth/google', { body: { idToken } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return { token: r.body.token, userId: r.body.user.id };
}

async function phoneSignIn(ctx, n) {
  const phone = phoneFor(n);
  assert.equal((await api(ctx, 'POST', '/auth/otp/request', { body: { phone } })).status, 200);
  const r = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone, code: ctx.codes.get(normalized(n)) } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return { token: r.body.token, userId: r.body.user.id, n };
}

async function ownerWithBusiness(ctx) {
  const owner = await phoneSignIn(ctx, 1);
  const r = await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name: 'Ada Designs' } });
  return { owner, bizId: r.body.id };
}

test('Google sign-in creates an account, and the same Google account returns the same user', async () => {
  const ctx = await setup();
  try {
    const t = googleProfile(ctx, 'tok-1', { sub: 'g-111', email: 'ada@example.com' });
    const first = await googleSignIn(ctx, t);
    const again = await googleSignIn(ctx, t);
    assert.equal(first.userId, again.userId);
    const mine = await api(ctx, 'GET', '/me/businesses', { token: first.token });
    assert.equal(mine.status, 200);
  } finally { ctx.close(); }
});

test('an invalid or forged Google token is rejected', async () => {
  const ctx = await setup();
  try {
    const r = await api(ctx, 'POST', '/auth/google', { body: { idToken: 'forged' } });
    assert.equal(r.status, 401);
    assert.equal((await api(ctx, 'POST', '/auth/google', { body: {} })).status, 400);
  } finally { ctx.close(); }
});

test('a Google user accepts an invitation sent to their verified email (case-insensitive)', async () => {
  const ctx = await setup();
  try {
    const { owner, bizId } = await ownerWithBusiness(ctx);
    const inv = await api(ctx, 'POST', `/businesses/${bizId}/invitations`, { token: owner.token, body: { email: 'Ada@Example.com', role: 'staff' } });
    assert.equal(inv.status, 201, JSON.stringify(inv.body));

    const ada = await googleSignIn(ctx, googleProfile(ctx, 'tok-ada', { sub: 'g-ada', email: 'ada@example.com' }));
    const r = await api(ctx, 'POST', '/invitations/accept', { token: ada.token, body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) } });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    const mine = await api(ctx, 'GET', '/me/businesses', { token: ada.token });
    assert.ok(mine.body.some((m) => m.business.id === bizId && m.role === 'staff'));
  } finally { ctx.close(); }
});

test('an unverified Google email does not match an email invitation', async () => {
  const ctx = await setup();
  try {
    const { owner, bizId } = await ownerWithBusiness(ctx);
    const inv = await api(ctx, 'POST', `/businesses/${bizId}/invitations`, { token: owner.token, body: { email: 'ada@example.com', role: 'staff' } });
    const impostor = await googleSignIn(ctx, googleProfile(ctx, 'tok-x', { sub: 'g-x', email: 'ada@example.com', verified: false }));
    const r = await api(ctx, 'POST', '/invitations/accept', { token: impostor.token, body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) } });
    assert.equal(r.status, 403);
  } finally { ctx.close(); }
});

test('a Google-only user cannot accept a phone invitation until they link that phone', async () => {
  const ctx = await setup();
  try {
    const { owner, bizId } = await ownerWithBusiness(ctx);
    const inv = await api(ctx, 'POST', `/businesses/${bizId}/invitations`, { token: owner.token, body: { phone: phoneFor(5), role: 'manager' } });
    const person = await googleSignIn(ctx, googleProfile(ctx, 'tok-p', { sub: 'g-p', email: 'p@example.com' }));

    assert.equal((await api(ctx, 'POST', '/invitations/accept', { token: person.token, body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) } })).status, 403);

    // Link the phone with an OTP, then accept.
    await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(5) } });
    const linked = await api(ctx, 'POST', '/me/link/phone', { token: person.token, body: { phone: phoneFor(5), code: ctx.codes.get(normalized(5)) } });
    assert.equal(linked.status, 200, JSON.stringify(linked.body));

    const ok = await api(ctx, 'POST', '/invitations/accept', { token: person.token, body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) } });
    assert.equal(ok.status, 200, JSON.stringify(ok.body));
  } finally { ctx.close(); }
});

test('a Google account can be attached to only one user, and an account gets only one Google account', async () => {
  const ctx = await setup();
  try {
    const a = await phoneSignIn(ctx, 1);
    const b = await phoneSignIn(ctx, 2);
    const gA = googleProfile(ctx, 'tok-a', { sub: 'g-a', email: 'a@example.com' });
    const gB = googleProfile(ctx, 'tok-b', { sub: 'g-b', email: 'b@example.com' });

    assert.equal((await api(ctx, 'POST', '/me/link/google', { token: a.token, body: { idToken: gA } })).status, 200);
    // Same Google account cannot be attached to a second user.
    assert.equal((await api(ctx, 'POST', '/me/link/google', { token: b.token, body: { idToken: gA } })).status, 409);
    // An account that already has Google cannot take a second one.
    assert.equal((await api(ctx, 'POST', '/me/link/google', { token: a.token, body: { idToken: gB } })).status, 409);
  } finally { ctx.close(); }
});

test('a phone number can be linked to only one account', async () => {
  const ctx = await setup();
  try {
    const owner = await phoneSignIn(ctx, 1); // holds phone 1
    const person = await googleSignIn(ctx, googleProfile(ctx, 'tok-q', { sub: 'g-q', email: 'q@example.com' }));
    // Try to link phone 1, which already belongs to the phone user.
    await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(1) } });
    const r = await api(ctx, 'POST', '/me/link/phone', { token: person.token, body: { phone: phoneFor(1), code: ctx.codes.get(normalized(1)) } });
    assert.equal(r.status, 409);
    assert.ok(owner.token);
  } finally { ctx.close(); }
});

test('an account with a phone number cannot link a second phone number', async () => {
  const ctx = await setup();
  try {
    const a = await phoneSignIn(ctx, 3);
    ctx.clock.t += 61_000;
    await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(4) } });
    const r = await api(ctx, 'POST', '/me/link/phone', { token: a.token, body: { phone: phoneFor(4), code: ctx.codes.get(normalized(4)) } });
    assert.equal(r.status, 409);
  } finally { ctx.close(); }
});

test('a linked user signs in with either method and gets the same account', async () => {
  const ctx = await setup();
  try {
    const p = await phoneSignIn(ctx, 6);
    const gt = googleProfile(ctx, 'tok-6', { sub: 'g-6', email: 'six@example.com' });
    assert.equal((await api(ctx, 'POST', '/me/link/google', { token: p.token, body: { idToken: gt } })).status, 200);
    const viaGoogle = await googleSignIn(ctx, gt);
    assert.equal(viaGoogle.userId, p.userId);
  } finally { ctx.close(); }
});

test('Google sign-in returns 501 when no verifier is configured', async () => {
  await resetDb();
  const app = createApp({ db, tokenSecret: TOKEN_SECRET, paystackSecretKey: 'sk', verifyTransaction: async () => null });
  const server = app.listen(0);
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/auth/google`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ idToken: 'x' })
    });
    assert.equal(res.status, 501);
  } finally { server.close(); server.closeAllConnections?.(); }
});
