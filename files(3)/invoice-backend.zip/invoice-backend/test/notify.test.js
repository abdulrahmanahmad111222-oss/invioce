import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { createWhatsAppChannel } from '../src/providers/whatsapp.js';
import { createSmsChannel } from '../src/providers/termii.js';
import { db, resetDb } from './helpers.js';

const ok = (json) => new Response(JSON.stringify(json), { status: 200, headers: { 'content-type': 'application/json' } });
const fail = (status, json) => new Response(JSON.stringify(json), { status, headers: { 'content-type': 'application/json' } });

// Fake HTTP layer: records each request and answers with the handler's response.
function fakeFetch(handler) {
  const calls = [];
  const fn = async (url, opts = {}) => {
    const body = opts.body ? JSON.parse(opts.body) : undefined;
    calls.push({ url, headers: opts.headers, body });
    return handler(url, body);
  };
  fn.calls = calls;
  return fn;
}

const phoneFor = (n) => '0801' + String(n).padStart(7, '0');
const normalized = (n) => '234' + phoneFor(n).slice(1);

// ---- Provider request shapes ----

test('WhatsApp OTP sends an approved template with the code, using the bearer token', async () => {
  const f = fakeFetch(() => ok({ messages: [{ id: 'wamid.1' }] }));
  const wa = createWhatsAppChannel({ phoneNumberId: 'PNID', accessToken: 'TOK', fetchImpl: f });
  const id = await wa.sendOtp('2348011112222', '483920');
  assert.equal(id, 'wamid.1');
  const { url, headers, body } = f.calls[0];
  assert.equal(url, 'https://graph.facebook.com/v21.0/PNID/messages');
  assert.equal(headers.Authorization, 'Bearer TOK');
  assert.equal(body.messaging_product, 'whatsapp');
  assert.equal(body.to, '2348011112222');
  assert.equal(body.type, 'template');
  assert.equal(body.template.name, 'otp_code');
  assert.equal(body.template.components[0].parameters[0].text, '483920');
});

test('WhatsApp invitation sends business name, role and link as template parameters', async () => {
  const f = fakeFetch(() => ok({ messages: [{ id: 'wamid.2' }] }));
  const wa = createWhatsAppChannel({ phoneNumberId: 'PNID', accessToken: 'TOK', fetchImpl: f });
  await wa.sendInvitation('2348011112222', { link: 'https://app.test/join?token=abc', businessName: 'Ada Designs', role: 'staff' });
  const params = f.calls[0].body.template.components[0].parameters.map((p) => p.text);
  assert.deepEqual(params, ['Ada Designs', 'staff', 'https://app.test/join?token=abc']);
});

test('WhatsApp API errors become failures with the provider message', async () => {
  const f = fakeFetch(() => fail(400, { error: { message: 'Template name does not exist' } }));
  const wa = createWhatsAppChannel({ phoneNumberId: 'PNID', accessToken: 'TOK', fetchImpl: f });
  await assert.rejects(wa.sendOtp('2348011112222', '111111'), /Template name does not exist/);
});

test('SMS OTP posts to Termii with the API key and the code in the text', async () => {
  const f = fakeFetch(() => ok({ message_id: 'sms-1', code: 'ok' }));
  const sms = createSmsChannel({ apiKey: 'KEY', senderId: 'InvoiceNG', fetchImpl: f });
  const id = await sms.sendOtp('2348011112222', '902113');
  assert.equal(id, 'sms-1');
  const { url, body } = f.calls[0];
  assert.equal(url, 'https://api.ng.termii.com/api/sms/send');
  assert.equal(body.api_key, 'KEY');
  assert.equal(body.from, 'InvoiceNG');
  assert.equal(body.to, '2348011112222');
  assert.match(body.sms, /902113/);
});

test('SMS without a message id is treated as a failure', async () => {
  const f = fakeFetch(() => ok({ code: 'ok' }));
  const sms = createSmsChannel({ apiKey: 'KEY', senderId: 'InvoiceNG', fetchImpl: f });
  await assert.rejects(sms.sendOtp('2348011112222', '111111'), /did not return a message id/);
});

// ---- Delivery through the app ----

async function setupApp(phoneChannels, extra = {}) {
  await resetDb();
  const app = createApp({
    db,
    tokenSecret: 'test-token-secret',
    paystackSecretKey: 'sk_test',
    appUrl: 'https://app.test',
    phoneChannels,
    emailChannels: [],
    verifyTransaction: async () => null,
    ...extra
  });
  const server = app.listen(0);
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    close() { server.close(); server.closeAllConnections?.(); }
  };
}

async function api(ctx, method, path, { token, body } = {}) {
  const res = await fetch(ctx.base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let json = null;
  try { json = await res.json(); } catch { /* empty */ }
  return { status: res.status, body: json };
}

test('WhatsApp failure falls back to SMS, and both attempts are logged without the code', async () => {
  const wa = fakeFetch(() => fail(500, { error: { message: 'Service unavailable' } }));
  const sms = fakeFetch(() => ok({ message_id: 'sms-9' }));
  const ctx = await setupApp([
    createWhatsAppChannel({ phoneNumberId: 'PNID', accessToken: 'TOK', fetchImpl: wa }),
    createSmsChannel({ apiKey: 'KEY', senderId: 'InvoiceNG', fetchImpl: sms })
  ]);
  try {
    assert.equal((await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(1) } })).status, 200);
    assert.equal(wa.calls.length, 1);
    assert.equal(sms.calls.length, 1);
    const code = sms.calls[0].body.sms.match(/\d{6}/)[0];

    const rows = (await db.query('SELECT purpose, channel, status, recipient_hint, error FROM notifications ORDER BY id')).rows;
    assert.deepEqual(rows.map((r) => [r.channel, r.status]), [['whatsapp', 'failed'], ['sms', 'sent']]);
    assert.equal(rows[0].recipient_hint, normalized(1).slice(-4));
    // The code itself is never stored.
    const everything = JSON.stringify((await db.query('SELECT * FROM notifications')).rows);
    assert.equal(everything.includes(code), false);

    // The code from SMS signs in the user.
    const ver = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(1), code } });
    assert.equal(ver.status, 200);
  } finally { ctx.close(); }
});

test('when every channel fails, the user gets 503, and can retry at once without waiting', async () => {
  let healthy = false;
  const wa = fakeFetch(() => (healthy ? ok({ messages: [{ id: 'w' }] }) : fail(500, { error: { message: 'down' } })));
  const sms = fakeFetch(() => (healthy ? ok({ message_id: 's' }) : fail(503, { message: 'down' })));
  const ctx = await setupApp([
    createWhatsAppChannel({ phoneNumberId: 'PNID', accessToken: 'TOK', fetchImpl: wa }),
    createSmsChannel({ apiKey: 'KEY', senderId: 'InvoiceNG', fetchImpl: sms })
  ]);
  try {
    const first = await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(2) } });
    assert.equal(first.status, 503);
    healthy = true;
    const retry = await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(2) } });
    assert.equal(retry.status, 200, JSON.stringify(retry.body));
  } finally { ctx.close(); }
});

test('an invitation that cannot be delivered returns 502 and is not usable', async () => {
  const wa = fakeFetch((url, body) => {
    if (body.template.name === 'business_invite') return fail(500, { error: { message: 'down' } });
    return ok({ messages: [{ id: 'otp' }] });
  });
  const sms = fakeFetch(() => fail(500, { message: 'down' }));
  const ctx = await setupApp([
    createWhatsAppChannel({ phoneNumberId: 'PNID', accessToken: 'TOK', fetchImpl: wa }),
    createSmsChannel({ apiKey: 'KEY', senderId: 'InvoiceNG', fetchImpl: sms })
  ]);
  try {
    // Owner signs in with a code delivered over WhatsApp.
    await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(3) } });
    const code = wa.calls[0].body.template.components[0].parameters[0].text;
    const owner = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(3), code } });
    const biz = await api(ctx, 'POST', '/businesses', { token: owner.body.token, body: { name: 'Ada Designs' } });

    const inv = await api(ctx, 'POST', `/businesses/${biz.body.id}/invitations`, {
      token: owner.body.token, body: { phone: phoneFor(4), role: 'staff' }
    });
    assert.equal(inv.status, 502);

    const saved = await db.query('SELECT revoked FROM invitations WHERE business_id = $1', [biz.body.id]);
    assert.equal(saved.rows.length, 1);
    assert.equal(saved.rows[0].revoked, true);
  } finally { ctx.close(); }
});

test('a successful invitation returns no token to the inviter, and the link reaches the invitee', async () => {
  const wa = fakeFetch((url, body) => (body.template.name === 'business_invite' ? ok({ messages: [{ id: 'inv-1' }] }) : ok({ messages: [{ id: 'otp' }] })));
  const ctx = await setupApp([createWhatsAppChannel({ phoneNumberId: 'PNID', accessToken: 'TOK', fetchImpl: wa })]);
  try {
    await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(5) } });
    const code = wa.calls[0].body.template.components[0].parameters[0].text;
    const owner = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(5), code } });
    const biz = await api(ctx, 'POST', '/businesses', { token: owner.body.token, body: { name: 'Ada Designs' } });

    const inv = await api(ctx, 'POST', `/businesses/${biz.body.id}/invitations`, {
      token: owner.body.token, body: { phone: phoneFor(6), role: 'staff' }
    });
    assert.equal(inv.status, 201);
    assert.equal(JSON.stringify(inv.body).includes('"token"'), false, 'the invitation response must not contain the token');
    assert.equal(inv.body.delivery.channel, 'whatsapp');

    const sentLink = wa.calls.at(-1).body.template.components[0].parameters[2].text;
    assert.match(sentLink, /^https:\/\/app\.test\/join\?token=/);
  } finally { ctx.close(); }
});
