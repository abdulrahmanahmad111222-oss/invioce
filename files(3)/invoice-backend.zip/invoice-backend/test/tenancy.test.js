import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { db, resetDb } from './helpers.js';

const TOKEN_SECRET = 'test-token-secret';
const HOUR = 3600 * 1000;

// Fake delivery channel: records codes and invitation links instead of sending them.
function captureChannel(store) {
  return {
    name: 'test',
    sendOtp: async (to, code) => { store.codes.set(to, code); return 'msg'; },
    sendInvitation: async (to, { link }) => { store.links.set(to, link); return 'msg'; }
  };
}

async function setup() {
  await resetDb();
  const clock = { t: Date.now() };
  const store = { codes: new Map(), links: new Map() };
  const channel = captureChannel(store);
  const app = createApp({
    db,
    tokenSecret: TOKEN_SECRET,
    paystackSecretKey: 'sk_test',
    now: () => clock.t,
    appUrl: 'https://app.test',
    phoneChannels: [channel],
    emailChannels: [channel],
    verifyTransaction: async () => null
  });
  const server = app.listen(0);
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    codes: store.codes,
    links: store.links,
    clock,
    close() {
      server.close();
      server.closeAllConnections?.();
    }
  };
}

// The invitation token travels only inside the link sent to the invitee.
const linkToken = (ctx, to) => new URL(ctx.links.get(to)).searchParams.get('token');

const phoneFor = (n) => '0801' + String(n).padStart(7, '0');
const normalized = (n) => '234' + phoneFor(n).slice(1);

async function api(ctx, method, path, { token, body } = {}) {
  const res = await fetch(ctx.base + path, {
    method,
    headers: {
      'content-type': 'application/json',
      ...(token ? { authorization: `Bearer ${token}` } : {})
    },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let json = null;
  try { json = await res.json(); } catch { /* empty body */ }
  return { status: res.status, body: json };
}

// Signs in a phone number and returns { n, token, userId }.
async function signIn(ctx, n) {
  const phone = phoneFor(n);
  const req = await api(ctx, 'POST', '/auth/otp/request', { body: { phone } });
  assert.equal(req.status, 200, JSON.stringify(req.body));
  const code = ctx.codes.get(normalized(n));
  const ver = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone, code } });
  assert.equal(ver.status, 200, JSON.stringify(ver.body));
  return { n, token: ver.body.token, userId: ver.body.user.id };
}

async function createBusiness(ctx, owner, name = 'Ada Designs') {
  const r = await api(ctx, 'POST', '/businesses', { token: owner.token, body: { name } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return r.body.id;
}

// Invites an already-signed-in member, who then accepts. Returns the member.
async function addMember(ctx, inviter, bizId, member, role) {
  const inv = await api(ctx, 'POST', `/businesses/${bizId}/invitations`, {
    token: inviter.token,
    body: { phone: phoneFor(member.n), role }
  });
  assert.equal(inv.status, 201, JSON.stringify(inv.body));
  const joined = await api(ctx, 'POST', '/invitations/accept', {
    token: member.token,
    body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) }
  });
  assert.equal(joined.status, 200, JSON.stringify(joined.body));
  return { ...member, role };
}

const invoiceBody = { client: 'Tunde Bello', phone: '08012345678', lines: [{ desc: 'Logo', qty: 1, price: 10000 }] };

test('wrong codes are rejected and a correct code works only once', async () => {
  const ctx = await setup();
  try {
    await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(1) } });
    const real = ctx.codes.get(normalized(1));
    const wrong = real === '000000' ? '111111' : '000000';
    const bad = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(1), code: wrong } });
    assert.equal(bad.status, 401);
    const ok = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(1), code: real } });
    assert.equal(ok.status, 200);
    const reuse = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(1), code: real } });
    assert.equal(reuse.status, 401);
  } finally { ctx.close(); }
});

test('a code locks out after too many wrong attempts', async () => {
  const ctx = await setup();
  try {
    await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(2) } });
    const real = ctx.codes.get(normalized(2));
    for (let i = 0; i < 5; i++) {
      const r = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(2), code: 'nope' } });
      assert.equal(r.status, 401);
    }
    const locked = await api(ctx, 'POST', '/auth/otp/verify', { body: { phone: phoneFor(2), code: real } });
    assert.equal(locked.status, 429);
  } finally { ctx.close(); }
});

test('new codes are limited to one per minute', async () => {
  const ctx = await setup();
  try {
    assert.equal((await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(3) } })).status, 200);
    assert.equal((await api(ctx, 'POST', '/auth/otp/request', { body: { phone: phoneFor(3) } })).status, 429);
  } finally { ctx.close(); }
});

test('a non-member gets 404 for a business, not 403, so existence is not revealed', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const stranger = await signIn(ctx, 2);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/members`, { token: stranger.token })).status, 404);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/invoices/1`, { token: stranger.token })).status, 404);
  } finally { ctx.close(); }
});

test('one business cannot read another business invoices, and numbering is per business', async () => {
  const ctx = await setup();
  try {
    const ownerA = await signIn(ctx, 1);
    const bizA = await createBusiness(ctx, ownerA, 'Shop A');
    const ownerB = await signIn(ctx, 2);
    const bizB = await createBusiness(ctx, ownerB, 'Shop B');

    const invA = await api(ctx, 'POST', `/businesses/${bizA}/invoices`, { token: ownerA.token, body: invoiceBody });
    assert.equal(invA.status, 201);
    assert.equal(invA.body.no, 1);

    // Shop B's owner tries to read Shop A's invoice by changing the URL.
    assert.equal((await api(ctx, 'GET', `/businesses/${bizA}/invoices/1`, { token: ownerB.token })).status, 404);

    // Shop B's first invoice is also number 1.
    const invB = await api(ctx, 'POST', `/businesses/${bizB}/invoices`, { token: ownerB.token, body: invoiceBody });
    assert.equal(invB.body.no, 1);
  } finally { ctx.close(); }
});

test('one person can own one shop and be staff in another, with different permissions in each', async () => {
  const ctx = await setup();
  try {
    const ownerA = await signIn(ctx, 1);
    const bizA = await createBusiness(ctx, ownerA, 'Shop A');
    const ownerB = await signIn(ctx, 2);
    const bizB = await createBusiness(ctx, ownerB, 'Shop B');

    const person = await signIn(ctx, 3);
    const staffInB = await addMember(ctx, ownerB, bizB, person, 'staff');
    const ownerOfA = await createBusiness(ctx, person, 'Person Own Shop');

    const mine = await api(ctx, 'GET', '/me/businesses', { token: person.token });
    assert.equal(mine.body.length, 2);
    const roles = Object.fromEntries(mine.body.map((m) => [m.business.id, m.role]));
    assert.equal(roles[ownerOfA], 'owner');
    assert.equal(roles[bizB], 'staff');

    assert.equal((await api(ctx, 'POST', `/businesses/${bizB}/invoices`, { token: person.token, body: invoiceBody })).status, 201);
    assert.equal((await api(ctx, 'GET', `/businesses/${bizB}/members`, { token: person.token })).status, 403);
    assert.equal((await api(ctx, 'GET', `/businesses/${bizA}/invoices/1`, { token: person.token })).status, 404);
  } finally { ctx.close(); }
});

test('staff can create invoices but cannot void or refund', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const staff = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'staff');

    const inv = await api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: staff.token, body: invoiceBody });
    assert.equal(inv.status, 201);
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices/1/void`, { token: staff.token })).status, 403);
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices/1/refund`, { token: staff.token, body: { amount: 100 } })).status, 403);
  } finally { ctx.close(); }
});

test('managers can void unpaid invoices', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const manager = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'manager');
    await api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: owner.token, body: invoiceBody });
    const r = await api(ctx, 'POST', `/businesses/${biz}/invoices/1/void`, { token: manager.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.status, 'Void');
  } finally { ctx.close(); }
});

test('staff cannot invite members, and admins cannot grant the admin role', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const admin = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'admin');
    const staff = await addMember(ctx, admin, biz, await signIn(ctx, 3), 'staff');

    // Admin cannot grant admin.
    const promote = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: admin.token, body: { phone: phoneFor(9), role: 'admin' } });
    assert.equal(promote.status, 403);

    // Admin can invite staff.
    const ok = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: admin.token, body: { phone: phoneFor(9), role: 'staff' } });
    assert.equal(ok.status, 201);

    // Staff cannot invite anyone.
    const staffInvite = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: staff.token, body: { phone: phoneFor(8), role: 'staff' } });
    assert.equal(staffInvite.status, 403);
  } finally { ctx.close(); }
});

test('the owner role cannot be granted by invitation or by role change', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const staff = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'staff');

    const inv = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: owner.token, body: { phone: phoneFor(9), role: 'owner' } });
    assert.equal(inv.status, 400);

    const change = await api(ctx, 'PATCH', `/businesses/${biz}/members/${staff.userId}`, { token: owner.token, body: { role: 'owner' } });
    assert.equal(change.status, 400);
  } finally { ctx.close(); }
});

test('nobody can change their own role', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const r = await api(ctx, 'PATCH', `/businesses/${biz}/members/${owner.userId}`, { token: owner.token, body: { role: 'staff' } });
    assert.equal(r.status, 403);
  } finally { ctx.close(); }
});

test('admins cannot touch the owner', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const admin = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'admin');

    const demote = await api(ctx, 'PATCH', `/businesses/${biz}/members/${owner.userId}`, { token: admin.token, body: { role: 'staff' } });
    assert.equal(demote.status, 403);
    const remove = await api(ctx, 'DELETE', `/businesses/${biz}/members/${owner.userId}`, { token: admin.token });
    assert.equal(remove.status, 403);

    // The owner is still the owner.
    const members = await api(ctx, 'GET', `/businesses/${biz}/members`, { token: owner.token });
    assert.equal(members.body.find((m) => m.userId === owner.userId).role, 'owner');
  } finally { ctx.close(); }
});

test('admins manage staff but cannot change other admins or promote anyone to admin', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const admin1 = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'admin');
    const admin2 = await addMember(ctx, owner, biz, await signIn(ctx, 3), 'admin');
    const staff = await addMember(ctx, admin1, biz, await signIn(ctx, 4), 'staff');

    // Admin cannot change another admin.
    const peer = await api(ctx, 'PATCH', `/businesses/${biz}/members/${admin2.userId}`, { token: admin1.token, body: { role: 'staff' } });
    assert.equal(peer.status, 403);

    // Admin can promote staff to manager.
    const ok = await api(ctx, 'PATCH', `/businesses/${biz}/members/${staff.userId}`, { token: admin1.token, body: { role: 'manager' } });
    assert.equal(ok.status, 200);

    // Admin cannot promote the staff member to admin.
    const up = await api(ctx, 'PATCH', `/businesses/${biz}/members/${staff.userId}`, { token: admin1.token, body: { role: 'admin' } });
    assert.equal(up.status, 403);

    // Owner can promote a manager to admin.
    const ownerPromote = await api(ctx, 'PATCH', `/businesses/${biz}/members/${staff.userId}`, { token: owner.token, body: { role: 'admin' } });
    assert.equal(ownerPromote.status, 200);
  } finally { ctx.close(); }
});

test('a removed member loses access at once, even with a valid sign-in', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const inv = await api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: owner.token, body: invoiceBody });
    const staff = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'staff');

    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/invoices/${inv.body.no}`, { token: staff.token })).status, 200);

    const removed = await api(ctx, 'DELETE', `/businesses/${biz}/members/${staff.userId}`, { token: owner.token });
    assert.equal(removed.status, 200);

    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/invoices/${inv.body.no}`, { token: staff.token })).status, 404);
    const mine = await api(ctx, 'GET', '/me/businesses', { token: staff.token });
    assert.equal(mine.body.some((m) => m.business.id === biz), false);
  } finally { ctx.close(); }
});

test('invitations are bound to one phone, single-use, and expire after 48 hours', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);

    // Single-use and phone-bound.
    const inv = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: owner.token, body: { phone: phoneFor(5), role: 'staff' } });
    const stranger = await signIn(ctx, 6);
    const wrongPerson = await api(ctx, 'POST', '/invitations/accept', { token: stranger.token, body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) } });
    assert.equal(wrongPerson.status, 403);

    const invitee = await signIn(ctx, 5);
    assert.equal((await api(ctx, 'POST', '/invitations/accept', { token: invitee.token, body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) } })).status, 200);
    assert.equal((await api(ctx, 'POST', '/invitations/accept', { token: invitee.token, body: { token: linkToken(ctx, inv.body.invitation.phone ?? inv.body.invitation.email) } })).status, 400);

    // Expiry.
    const old = await api(ctx, 'POST', `/businesses/${biz}/invitations`, { token: owner.token, body: { phone: phoneFor(7), role: 'staff' } });
    ctx.clock.t += 49 * HOUR;
    const late = await signIn(ctx, 7);
    const expired = await api(ctx, 'POST', '/invitations/accept', { token: late.token, body: { token: linkToken(ctx, old.body.invitation.phone ?? old.body.invitation.email) } });
    assert.equal(expired.status, 400);
  } finally { ctx.close(); }
});

test('the audit log records team changes and only auditors can read it', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const staff = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'staff');
    const accountant = await addMember(ctx, owner, biz, await signIn(ctx, 3), 'accountant');

    // Staff cannot read the audit log.
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/audit`, { token: staff.token })).status, 403);

    await api(ctx, 'PATCH', `/businesses/${biz}/members/${staff.userId}`, { token: owner.token, body: { role: 'manager' } });
    await api(ctx, 'DELETE', `/businesses/${biz}/members/${staff.userId}`, { token: owner.token });

    // The accountant can read it.
    const log = await api(ctx, 'GET', `/businesses/${biz}/audit`, { token: accountant.token });
    assert.equal(log.status, 200);
    const actions = log.body.map((e) => e.action);
    for (const a of ['business.created', 'member.invited', 'invite.accepted', 'member.role_changed', 'member.removed']) {
      assert.ok(actions.includes(a), `missing audit action ${a}`);
    }
  } finally { ctx.close(); }
});

test('an accountant can read but cannot create invoices', async () => {
  const ctx = await setup();
  try {
    const owner = await signIn(ctx, 1);
    const biz = await createBusiness(ctx, owner);
    const acct = await addMember(ctx, owner, biz, await signIn(ctx, 2), 'accountant');
    assert.equal((await api(ctx, 'POST', `/businesses/${biz}/invoices`, { token: acct.token, body: invoiceBody })).status, 403);
    assert.equal((await api(ctx, 'GET', `/businesses/${biz}/ledger`, { token: acct.token })).status, 200);
  } finally { ctx.close(); }
});

test('logout ends the session', async () => {
  const ctx = await setup();
  try {
    const user = await signIn(ctx, 1);
    assert.equal((await api(ctx, 'GET', '/me/businesses', { token: user.token })).status, 200);
    await api(ctx, 'POST', '/auth/logout', { token: user.token });
    assert.equal((await api(ctx, 'GET', '/me/businesses', { token: user.token })).status, 401);
  } finally { ctx.close(); }
});
