import pg from 'pg';

// bigint columns (kobo amounts) come back as JS numbers.
// Safe here because amounts stay far below 2^53 kobo.
pg.types.setTypeParser(20, (v) => Number(v));

export function createDb(connectionString) {
  if (!connectionString) throw new Error('DATABASE_URL is required');
  const pool = new pg.Pool({ connectionString, max: 10, allowExitOnIdle: true });
  return {
    query: (text, params) => pool.query(text, params),
    // Runs fn inside a transaction. Throwing rolls everything back.
    async tx(fn) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const result = await fn(client);
        await client.query('COMMIT');
        return result;
      } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        throw err;
      } finally {
        client.release();
      }
    },
    close: () => pool.end()
  };
}
