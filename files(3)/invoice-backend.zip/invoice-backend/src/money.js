// All money is stored as integer kobo (1 naira = 100 kobo) to avoid float errors.
export const VAT_RATE = 0.075;
export const FEE_RATE = 0.015;      // illustrative only; use your provider's real rate
export const FEE_CAP_KOBO = 200000; // illustrative cap, ₦2,000

export function naToKobo(naira) {
  return Math.round(Number(naira) * 100);
}

export function lineTotal(qty, unitNaira) {
  return Math.round(Number(qty) * naToKobo(unitNaira));
}

export function invoiceTotals(lines, vat) {
  const subtotal = lines.reduce((sum, l) => sum + lineTotal(l.qty, l.price), 0);
  const tax = vat ? Math.round(subtotal * VAT_RATE) : 0;
  return { subtotal, tax, total: subtotal + tax };
}

export function feeFor(amountKobo) {
  return Math.min(Math.round(amountKobo * FEE_RATE), FEE_CAP_KOBO);
}
