// Sends async handler errors to the error middleware instead of crashing.
export const wrap = (fn) => (req, res, next) =>
  Promise.resolve().then(() => fn(req, res, next)).catch(next);
