import { createApp } from './server.js';
import { createDb } from './db.js';
import { migrate } from './migrate.js';
import { createGoogleVerifier } from './providers/google.js';
import { createWhatsAppChannel } from './providers/whatsapp.js';
import { createSmsChannel } from './providers/termii.js';
import { createGoogleOAuth } from './gmail.js';

const tokenSecret = process.env.TOKEN_SECRET;
const paystackSecretKey = process.env.PAYSTACK_SECRET_KEY;
if (!tokenSecret || !paystackSecretKey || !process.env.DATABASE_URL) {
  console.error('Set DATABASE_URL, TOKEN_SECRET and PAYSTACK_SECRET_KEY (see .env.example).');
  process.exit(1);
}

const db = createDb(process.env.DATABASE_URL);
await migrate(db);

// Phone channels are tried in order: WhatsApp first, SMS as the fallback.
const phoneChannels = [];
if (process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_ACCESS_TOKEN) {
  phoneChannels.push(createWhatsAppChannel({
    phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID,
    accessToken: process.env.WHATSAPP_ACCESS_TOKEN
  }));
}
if (process.env.TERMII_API_KEY && process.env.TERMII_SENDER_ID) {
  phoneChannels.push(createSmsChannel({
    apiKey: process.env.TERMII_API_KEY,
    senderId: process.env.TERMII_SENDER_ID
  }));
}

if (phoneChannels.length === 0) {
  if (process.env.NODE_ENV === 'production') {
    console.error('Configure WhatsApp or SMS credentials before running in production.');
    process.exit(1);
  }
  // DEV ONLY: prints codes and links to the console instead of sending them.
  const consoleChannel = (name) => ({
    name,
    sendOtp: async (to, code) => console.log(`[dev] code for ${to}: ${code}`),
    sendInvitation: async (to, { link }) => console.log(`[dev] invitation for ${to}: ${link}`),
    sendNotice: async (to, { text }) => console.log(`[dev] notice for ${to}: ${text}`)
  });
  phoneChannels.push(consoleChannel('console'));
}

const port = Number(process.env.PORT ?? 3000);
const googleVerifier = process.env.GOOGLE_CLIENT_ID ? createGoogleVerifier({ clientId: process.env.GOOGLE_CLIENT_ID }) : undefined;

// Gmail: each business connects its own account. Needs a Google OAuth client, a secret,
// the callback URL registered with Google, and a 32-byte key for encrypting refresh tokens.
const gmailConfigured = process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
  && process.env.GMAIL_REDIRECT_URI && process.env.ENCRYPTION_KEY;
const gmailOAuth = gmailConfigured
  ? createGoogleOAuth({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      redirectUri: process.env.GMAIL_REDIRECT_URI
    })
  : undefined;

createApp({
  db,
  tokenSecret,
  paystackSecretKey,
  googleVerifier,
  phoneChannels,
  gmailOAuth,
  encryptionKey: process.env.ENCRYPTION_KEY,
  appUrl: process.env.APP_URL ?? `http://localhost:${process.env.PORT ?? 3000}`,
  apiUrl: process.env.API_URL ?? `http://localhost:${process.env.PORT ?? 3000}`,
  // Set TRUST_PROXY when the API sits behind a load balancer, so limits see the real client address.
  trustProxy: process.env.TRUST_PROXY ? Number(process.env.TRUST_PROXY) : undefined
}).listen(port, () => {
  console.log(`Invoice backend listening on http://localhost:${port}`);
});
