import crypto from 'node:crypto';

// Paystack signs the raw request body with HMAC SHA-512 using your secret key,
// sent in the x-paystack-signature header.
export function verifySignature(rawBody, signature, secretKey) {
  if (!signature || !secretKey) return false;
  const expected = crypto.createHmac('sha512', secretKey).update(rawBody).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function createPaystackHandler({ store, secretKey, verifyTransaction }) {
  return async function paystackWebhook(req, res) {
    const raw = req.body; // Buffer, because the route uses express.raw()

    if (!verifySignature(raw, req.get('x-paystack-signature'), secretKey)) {
      return res.status(401).json({ error: 'invalid signature' });
    }

    let event;
    try {
      event = JSON.parse(raw.toString('utf8'));
    } catch {
      return res.status(400).json({ error: 'invalid JSON' });
    }

    // Acknowledge other event types so the provider stops retrying them.
    if (event.event !== 'charge.success') {
      return res.status(200).json({ status: 'ignored' });
    }

    const data = event.data ?? {};
    const result = await store.applyPayment({
      providerEventId: String(data.id),
      reference: data.reference,
      amount: data.amount,
      currency: data.currency,
      provider: 'Paystack',
      verify: () => verifyTransaction(data.reference)
    });

    // Return 200 for business outcomes so Paystack does not retry them forever.
    // Only signature and parsing failures return error codes.
    return res.status(200).json({ status: result.status });
  };
}
