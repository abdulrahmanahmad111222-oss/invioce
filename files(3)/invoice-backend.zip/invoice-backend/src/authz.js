import { verifyToken } from './tokens.js';
import { can } from './permissions.js';
import { wrap } from './http.js';

// Builds the middleware that protected routes use.
export function createAuthz({ identity, tokenSecret }) {
  const authenticate = wrap(async (req, res, next) => {
    const header = req.get('authorization') ?? '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    const payload = verifyToken(token, tokenSecret);
    const user = payload ? await identity.authenticate(payload.sid) : null;
    if (!user) return res.status(401).json({ error: 'sign in required' });
    req.user = user;
    req.sessionId = payload.sid;
    next();
  });

  // Loads the caller's membership in the business named in the URL, on every request,
  // so removing someone takes effect immediately.
  const requireMembership = wrap(async (req, res, next) => {
    const membership = await identity.getMembership(req.user.id, req.params.bizId);
    if (!membership) return res.status(404).json({ error: 'not found' });
    req.membership = membership;
    next();
  });

  function guard(permission) {
    return [
      authenticate,
      requireMembership,
      (req, res, next) =>
        can(req.membership.role, permission)
          ? next()
          : res.status(403).json({ error: 'your role does not allow this action' })
    ];
  }

  return { authenticate, guard };
}
