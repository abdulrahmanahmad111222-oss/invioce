// Single source of truth for what each role may do.
// Enforced on the server only. The UI may hide buttons, but it can't be trusted.

export const ROLE_RANK = { owner: 5, admin: 4, manager: 3, staff: 2, accountant: 2 };

// Roles that can be granted through invitations or role changes.
// "owner" is deliberately excluded. Ownership transfer needs its own flow.
export const ASSIGNABLE_ROLES = ['admin', 'manager', 'staff', 'accountant'];

const ALL = [
  'billing.manage',
  'members.invite',
  'members.manage',
  'settings.payouts',
  'integrations.manage',
  'billing.view',
  'invoices.view',
  'invoices.create',
  'invoices.edit',
  'invoices.void',
  'payments.record',
  'payments.refund',
  'reports.view',
  'audit.view'
];

export const PERMISSIONS = {
  owner: ALL,
  admin: ALL.filter((p) => p !== 'billing.manage'),
  manager: [
    'invoices.view', 'invoices.create', 'invoices.edit', 'invoices.void',
    'payments.record', 'payments.refund', 'reports.view', 'audit.view'
  ],
  staff: ['invoices.view', 'invoices.create', 'invoices.edit', 'payments.record'],
  accountant: ['invoices.view', 'reports.view', 'audit.view', 'billing.view']
};

export function can(role, permission) {
  return Object.hasOwn(PERMISSIONS, role) && PERMISSIONS[role].includes(permission);
}
