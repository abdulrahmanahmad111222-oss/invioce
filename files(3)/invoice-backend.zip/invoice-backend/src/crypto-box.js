import crypto from 'node:crypto';

// AES-256-GCM. Each value gets a fresh random IV, and the auth tag detects any change to the ciphertext.
export function createBox(keyBase64) {
  const key = Buffer.from(String(keyBase64 ?? ''), 'base64');
  if (key.length !== 32) throw new Error('GMAIL_ENCRYPTION_KEY must be 32 random bytes, base64 encoded');

  return {
    encrypt(plain) {
      const iv = crypto.randomBytes(12);
      const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
      const data = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
      return Buffer.concat([iv, cipher.getAuthTag(), data]).toString('base64');
    },
    decrypt(encoded) {
      const buf = Buffer.from(encoded, 'base64');
      const decipher = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12));
      decipher.setAuthTag(buf.subarray(12, 28));
      return Buffer.concat([decipher.update(buf.subarray(28)), decipher.final()]).toString('utf8');
    }
  };
}
