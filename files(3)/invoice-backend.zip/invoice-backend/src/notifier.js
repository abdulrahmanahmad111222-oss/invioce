import { AuthzError } from './errors.js';

// Sends codes, invitations and invoices through the first channel that works.
// Phone channels (WhatsApp, then SMS) carry codes and invitations to phone numbers.
// Email goes out through the business's connected Gmail account.
export function createNotifier({ db, phoneChannels = [], emailChannelFor = async () => [] }) {
  const hint = (to) => String(to).slice(-4);

  async function log(purpose, to, channel, status, providerId, error) {
    await db.query(
      `INSERT INTO notifications (purpose, channel, recipient_hint, status, provider_message_id, error)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [purpose, channel, hint(to), status, providerId, error ? String(error).slice(0, 300) : null]
    );
  }

  async function deliver(purpose, to, channels, send) {
    const errors = [];
    for (const channel of channels) {
      try {
        const providerId = await send(channel);
        await log(purpose, to, channel.name, 'sent', providerId, null);
        return { delivered: true, channel: channel.name };
      } catch (err) {
        errors.push(`${channel.name}: ${err.message}`);
        await log(purpose, to, channel.name, 'failed', null, err.message);
      }
    }
    return { delivered: false, channel: null, errors };
  }

  return {
    async sendOtp(phone, code) {
      const result = await deliver('otp', phone, phoneChannels, (ch) => ch.sendOtp(phone, code));
      if (!result.delivered) throw new AuthzError(503, 'we could not send your code, please try again');
      return result;
    },

    async sendInvitation({ businessId, phone, email, link, businessName, role }) {
      if (phone) {
        return deliver('invitation', phone, phoneChannels, (ch) => ch.sendInvitation(phone, { link, businessName, role }));
      }
      if (!email) return { delivered: false, channel: null, errors: ['no recipient'] };
      const channels = await emailChannelFor(businessId);
      if (!channels.length) return { delivered: false, channel: null, errors: ['no email account connected'] };
      return deliver('invitation', email, channels, (ch) => ch.sendInvitation(email, { link, businessName, role }));
    },

    async sendNotice({ businessId, phone, email, subject, text, businessName, graceDate }) {
      if (phone) {
        return deliver('notice', phone, phoneChannels, (ch) => ch.sendNotice(phone, { text, businessName, graceDate }));
      }
      if (!email) return { delivered: false, channel: null, errors: ['no contact for the owner'] };
      const channels = await emailChannelFor(businessId);
      if (!channels.length) return { delivered: false, channel: null, errors: ['no email account connected'] };
      return deliver('notice', email, channels, (ch) => ch.sendNotice(email, { subject, text }));
    },

    async sendInvoice({ businessId, email, subject, text }) {
      const channels = await emailChannelFor(businessId);
      if (!channels.length) return { delivered: false, channel: null, errors: ['no email account connected'] };
      return deliver('invoice', email, channels, (ch) => ch.sendInvoice(email, { subject, text }));
    }
  };
}
