import { OAuth2Client } from 'google-auth-library';

// Verifies a Google ID token (signature, issuer, audience, expiry) and returns the profile.
// The client-side sign-in button gives the app an ID token; the server must verify it here.
export function createGoogleVerifier({ clientId }) {
  if (!clientId) throw new Error('GOOGLE_CLIENT_ID is required');
  const client = new OAuth2Client(clientId);
  return async (idToken) => {
    const ticket = await client.verifyIdToken({ idToken, audience: clientId });
    const p = ticket.getPayload();
    return {
      sub: p.sub,
      email: p.email ?? null,
      emailVerified: Boolean(p.email_verified),
      name: p.name ?? null
    };
  };
}
