// Termii SMS API (Nigeria). Sender IDs must be registered with Termii before use.
// Check Termii's current docs for the endpoint and any changes to the request format.
export function createSmsChannel({
  apiKey,
  senderId,
  baseUrl = 'https://api.ng.termii.com',
  fetchImpl = fetch
}) {
  if (!apiKey || !senderId) throw new Error('Termii apiKey and senderId are required');

  async function send(to, text) {
    const res = await fetchImpl(`${baseUrl}/api/sms/send`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ to, from: senderId, sms: text, type: 'plain', channel: 'generic', api_key: apiKey })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`SMS ${res.status}: ${json?.message ?? 'request failed'}`);
    if (!json.message_id) throw new Error('SMS provider did not return a message id');
    return json.message_id;
  }

  return {
    name: 'sms',
    sendOtp(to, code) {
      return send(to, `Your verification code is ${code}. It expires in 5 minutes. Do not share it with anyone.`);
    },
    sendNotice(to, { text }) {
      return send(to, text);
    },
    sendInvitation(to, { link, businessName, role }) {
      return send(to, `${businessName} invited you to join as ${role}. Accept within 48 hours: ${link}`);
    }
  };
}
