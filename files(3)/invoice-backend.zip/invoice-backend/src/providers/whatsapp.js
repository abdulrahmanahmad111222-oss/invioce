// WhatsApp Cloud API (Meta Graph API).
// Codes and invitations are sent as approved message templates. Meta requires
// templates for messages to people who haven't messaged you in the last 24 hours.
// Template names and parameter layout must match the templates you create in Meta's dashboard.
export function createWhatsAppChannel({
  phoneNumberId,
  accessToken,
  otpTemplate = 'otp_code',
  inviteTemplate = 'business_invite',
  noticeTemplate = 'subscription_payment_failed',
  language = 'en',
  apiVersion = 'v21.0',
  fetchImpl = fetch
}) {
  if (!phoneNumberId || !accessToken) throw new Error('WhatsApp phoneNumberId and accessToken are required');

  async function post(payload) {
    const res = await fetchImpl(`https://graph.facebook.com/${apiVersion}/${phoneNumberId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', ...payload })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`WhatsApp ${res.status}: ${json?.error?.message ?? 'request failed'}`);
    return json.messages?.[0]?.id ?? null;
  }

  return {
    name: 'whatsapp',

    sendOtp(to, code) {
      return post({
        to,
        type: 'template',
        template: {
          name: otpTemplate,
          language: { code: language },
          components: [
            { type: 'body', parameters: [{ type: 'text', text: code }] },
            { type: 'button', sub_type: 'url', index: '0', parameters: [{ type: 'text', text: code }] }
          ]
        }
      });
    },

    sendNotice(to, { businessName, graceDate }) {
      return post({
        to,
        type: 'template',
        template: {
          name: noticeTemplate,
          language: { code: language },
          components: [
            { type: 'body', parameters: [
              { type: 'text', text: businessName },
              { type: 'text', text: graceDate }
            ] }
          ]
        }
      });
    },

    sendInvitation(to, { link, businessName, role }) {
      return post({
        to,
        type: 'template',
        template: {
          name: inviteTemplate,
          language: { code: language },
          components: [
            { type: 'body', parameters: [
              { type: 'text', text: businessName },
              { type: 'text', text: role },
              { type: 'text', text: link }
            ] }
          ]
        }
      });
    }
  };
}
