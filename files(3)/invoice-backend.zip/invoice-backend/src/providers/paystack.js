// Paystack API client: verify a payment, start a checkout, and charge a saved card.
export function createPaystackClient({ secretKey, fetchImpl = fetch }) {
  const base = 'https://api.paystack.co';

  async function call(path, body) {
    const res = await fetchImpl(base + path, {
      method: body ? 'POST' : 'GET',
      headers: { Authorization: `Bearer ${secretKey}`, 'content-type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    });
    const json = await res.json().catch(() => ({}));
    return { ok: res.ok, json };
  }

  return {
    // Returns what Paystack confirms, or null if the payment didn't succeed.
    async verify(reference) {
      const { ok, json } = await call(`/transaction/verify/${encodeURIComponent(reference)}`);
      if (!ok || json?.data?.status !== 'success') return null;
      const auth = json.data.authorization;
      return {
        amount: json.data.amount,
        currency: json.data.currency,
        authorizationCode: auth?.reusable ? auth.authorization_code : null
      };
    },

    async initialize({ email, amount, reference, callbackUrl }) {
      const { ok, json } = await call('/transaction/initialize', { email, amount, reference, callback_url: callbackUrl });
      if (!ok || !json.status) throw new Error(`Paystack initialize failed: ${json?.message ?? 'unknown error'}`);
      return { authorizationUrl: json.data.authorization_url };
    },

    async charge({ email, amount, authorizationCode, reference }) {
      const { ok, json } = await call('/transaction/charge_authorization', {
        email, amount, authorization_code: authorizationCode, reference
      });
      if (!ok) return { status: 'failed', message: json?.message ?? 'request failed' };
      return { status: json.data?.status === 'success' ? 'success' : 'failed', message: json.data?.gateway_response };
    }
  };
}
