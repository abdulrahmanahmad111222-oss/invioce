// Errors that carry an HTTP status. The server turns them into JSON responses.
export class AuthzError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
