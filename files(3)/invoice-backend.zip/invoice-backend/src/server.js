import crypto from 'node:crypto';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { createAudit } from './audit.js';
import { createIdentity } from './identity.js';
import { createInvoiceStore } from './invoices.js';
import { createAuthz } from './authz.js';
import { signToken, verifyToken } from './tokens.js';
import { AuthzError } from './errors.js';
import { wrap } from './http.js';
import { can } from './permissions.js';
import { createNotifier } from './notifier.js';
import { createBox } from './crypto-box.js';
import { createGmailConnections } from './gmail.js';
import { createBilling } from './billing/billing.js';
import { createPaystackHandler } from './webhooks/paystack.js';
import { createPaystackClient } from './providers/paystack.js';
import { createPaymentPages } from './payment-pages.js';

const TOKEN_TTL_SECONDS = 12 * 3600;
const STATE_TTL_SECONDS = 600;
const pad = (n) => String(n).padStart(4, '0');
const naira = (kobo) => '₦' + (kobo / 100).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function createApp(opts = {}) {
  if (!opts.db) throw new Error('db is required');
  if (!opts.tokenSecret) throw new Error('tokenSecret is required');
  if (opts.gmailOAuth && !opts.encryptionKey) throw new Error('encryptionKey is required when Gmail is configured');

  const { db } = opts;
  const fetchImpl = opts.fetchImpl ?? fetch;
  const appUrl = (opts.appUrl ?? 'http://localhost:3000').replace(/\/$/, '');
  // The pay page and the Gmail callback are served by the API, which may be on a different host.
  const apiUrl = (opts.apiUrl ?? appUrl).replace(/\/$/, '');
  const box = opts.encryptionKey ? createBox(opts.encryptionKey) : null;
  const audit = createAudit({ db });

  // Email goes through the business's connected Gmail. Tests can pass fixed channels instead.
  const gmail = opts.gmailOAuth
    ? createGmailConnections({ db, oauth: opts.gmailOAuth, box, fetchImpl })
    : null;
  const emailChannelFor = gmail
    ? (businessId) => gmail.channelsFor(businessId)
    : (opts.emailChannelFor ?? (async () => opts.emailChannels ?? []));

  const notifier = createNotifier({ db, phoneChannels: opts.phoneChannels ?? [], emailChannelFor });
  const identity = createIdentity({ db, audit, otpSender: (phone, code) => notifier.sendOtp(phone, code), now: opts.now });
  const invoices = createInvoiceStore({ db, audit });
  const paystack = opts.paystack ?? createPaystackClient({ secretKey: opts.paystackSecretKey, fetchImpl });
  const verify = opts.verifyTransaction ?? ((reference) => paystack.verify(reference));
  const payPages = createPaymentPages({ db, paystack, apiUrl });
  const billing = createBilling({
    db, audit, box, paystack, appUrl,
    plans: opts.billingPlans, trialDays: opts.trialDays, graceDays: opts.graceDays, now: opts.now,
    onPaymentFailed: async ({ businessId, graceUntil }) => {
      const owner = (await db.query(
        'SELECT u.phone, u.email FROM businesses b JOIN users u ON u.id = b.owner_user_id WHERE b.id = $1',
        [businessId]
      )).rows[0];
      const biz = await identity.getBusiness(businessId);
      const graceDate = new Date(graceUntil).toISOString().slice(0, 10);
      await notifier.sendNotice({
        businessId,
        phone: owner.phone,
        email: owner.email,
        businessName: biz.name,
        graceDate,
        subject: `Action needed: ${biz.name} subscription payment failed`,
        text: `Your ${biz.name} subscription payment failed. Renew by ${graceDate} to keep your account open.`
      });
    }
  });
  const authz = createAuthz({ identity, tokenSecret: opts.tokenSecret });

  // Blocks new work when the subscription has ended. Reads and payments from customers still work.
  const writable = wrap(async (req, res, next) => {
    req.access = await billing.requireWritable(req.params.bizId);
    next();
  });

  async function verifyGoogle(idToken) {
    if (!opts.googleVerifier) throw new AuthzError(501, 'Google sign-in is not configured');
    if (typeof idToken !== 'string' || !idToken) throw new AuthzError(400, 'idToken is required');
    try {
      return await opts.googleVerifier(idToken);
    } catch {
      throw new AuthzError(401, 'invalid Google sign-in');
    }
  }

  const requireGmail = () => {
    if (!gmail) throw new AuthzError(501, 'Gmail is not configured');
  };

  // Paystack webhook: checkout payments go to billing, everything else to invoices.
  const payments = {
    applyPayment(args) {
      if (args.reference.startsWith('sub_')) return billing.applyFromWebhook(args);
      return invoices.applyPayment(args);
    }
  };

  const app = express();
  app.services = { identity, invoices, audit, notifier, billing };
  if (opts.trustProxy !== undefined) app.set('trust proxy', opts.trustProxy);

  // Rate limits. Counts are per instance; use a shared store (for example Redis) when you run several.
  // Webhooks are not limited, because Paystack retries them and must not be refused.
  const limited = (windowMs, limit) => rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'too many attempts, please wait a little and try again' }
  });
  app.use('/auth', limited(15 * 60 * 1000, opts.authLimit ?? 100));
  const payLimiter = limited(60 * 1000, opts.payLimit ?? 30);

  // The web app runs on another origin, so allow it to call the API. Only APP_URL is allowed.
  app.use((req, res, next) => {
    const origin = req.get('origin');
    if (origin && origin === appUrl) {
      res.set('Access-Control-Allow-Origin', origin);
      res.set('Access-Control-Allow-Headers', 'authorization, content-type');
      res.set('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
      res.set('Vary', 'Origin');
    }
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });

  // Webhook first: it needs the raw body. It is not business-scoped.
  app.post(
    '/webhooks/paystack',
    express.raw({ type: '*/*' }),
    createPaystackHandler({ store: payments, secretKey: opts.paystackSecretKey, verifyTransaction: verify })
  );

  app.use(express.json());

  // Authentication
  app.post('/auth/otp/request', wrap(async (req, res) => {
    res.json(await identity.requestOtp(req.body?.phone));
  }));

  app.post('/auth/otp/verify', wrap(async (req, res) => {
    const { user, sessionId } = await identity.verifyOtp(req.body?.phone, req.body?.code);
    res.json({ token: signToken({ sid: sessionId }, opts.tokenSecret, TOKEN_TTL_SECONDS), user });
  }));

  app.post('/auth/google', wrap(async (req, res) => {
    const profile = await verifyGoogle(req.body?.idToken);
    const { user, sessionId } = await identity.signInWithGoogle(profile);
    res.json({ token: signToken({ sid: sessionId }, opts.tokenSecret, TOKEN_TTL_SECONDS), user });
  }));

  app.post('/auth/logout', authz.authenticate, wrap(async (req, res) => {
    await identity.logout(req.sessionId);
    res.json({ ok: true });
  }));

  app.post('/me/link/google', authz.authenticate, wrap(async (req, res) => {
    const profile = await verifyGoogle(req.body?.idToken);
    res.json(await identity.linkGoogle(req.user.id, profile));
  }));

  app.post('/me/link/phone', authz.authenticate, wrap(async (req, res) => {
    res.json(await identity.linkPhone(req.user.id, req.body?.phone, req.body?.code));
  }));

  // Account and businesses
  app.get('/me', authz.authenticate, (req, res) => {
    res.json({ id: req.user.id, phone: req.user.phone, email: req.user.email });
  });

  app.get('/me/businesses', authz.authenticate, wrap(async (req, res) => {
    res.json(await identity.listMemberships(req.user.id));
  }));

  app.post('/businesses', authz.authenticate, wrap(async (req, res) => {
    const biz = await identity.createBusiness(req.user.id, req.body?.name);
    await billing.startTrial(biz.id);
    res.status(201).json(biz);
  }));

  app.post('/invitations/accept', authz.authenticate, wrap(async (req, res) => {
    res.json(await identity.acceptInvitation(req.user.id, req.body?.token));
  }));

  // Subscription
  app.get('/businesses/:bizId/subscription', ...authz.guard('billing.view'), wrap(async (req, res) => {
    res.json(await billing.summary(req.params.bizId));
  }));

  app.post('/businesses/:bizId/subscription/checkout', ...authz.guard('billing.manage'), wrap(async (req, res) => {
    res.status(201).json(await billing.startCheckout(req.params.bizId, req.body ?? {}));
  }));

  app.post('/businesses/:bizId/subscription/cancel', ...authz.guard('billing.manage'), wrap(async (req, res) => {
    res.json(await billing.cancel(req.params.bizId, req.user.id));
  }));

  // Team
  app.get('/businesses/:bizId/members', ...authz.guard('members.manage'), wrap(async (req, res) => {
    res.json(await identity.listMembers(req.user.id, req.params.bizId));
  }));

  app.post('/businesses/:bizId/invitations', ...authz.guard('members.invite'), writable, wrap(async (req, res) => {
    const bizId = req.params.bizId;
    const { invitation, token } = await identity.createInvitation(req.user.id, bizId, req.body ?? {}, {
      memberLimit: req.access.limits.members
    });
    const biz = await identity.getBusiness(bizId);
    // The token is sent to the invitee only. It is never returned to the inviter.
    const delivery = await notifier.sendInvitation({
      businessId: bizId,
      phone: invitation.phone,
      email: invitation.email,
      link: `${appUrl}/join?token=${token}`,
      businessName: biz.name,
      role: invitation.role
    });
    if (!delivery.delivered) {
      await identity.discardInvitation(bizId, token);
      throw new AuthzError(502, 'could not send the invitation, nothing was saved, please try again');
    }
    res.status(201).json({ invitation, delivery: { channel: delivery.channel } });
  }));

  app.patch('/businesses/:bizId/members/:userId', ...authz.guard('members.manage'), wrap(async (req, res) => {
    res.json(await identity.changeRole(req.user.id, req.params.bizId, req.params.userId, req.body?.role));
  }));

  app.delete('/businesses/:bizId/members/:userId', ...authz.guard('members.manage'), wrap(async (req, res) => {
    res.json(await identity.removeMember(req.user.id, req.params.bizId, req.params.userId));
  }));

  // Gmail connection (per business). Connecting is a paid feature.
  app.get('/businesses/:bizId/gmail', ...authz.guard('integrations.manage'), wrap(async (req, res) => {
    requireGmail();
    res.json(await gmail.status(req.params.bizId));
  }));

  app.get('/businesses/:bizId/gmail/connect', ...authz.guard('integrations.manage'), writable, wrap(async (req, res) => {
    requireGmail();
    if (!req.access.limits.gmail) throw new AuthzError(402, 'Gmail sending is not included in your plan. Upgrade to connect it.');
    // The state links the callback to this user and business. It expires in 10 minutes.
    const state = signToken(
      { purpose: 'gmail-connect', biz: req.params.bizId, uid: req.user.id, nonce: crypto.randomBytes(8).toString('hex') },
      opts.tokenSecret,
      STATE_TTL_SECONDS
    );
    res.json({ url: opts.gmailOAuth.authorizationUrl(state) });
  }));

  // Google redirects the browser here. The state is verified, and the membership is checked again
  // at this moment, so a person who lost the permission while consenting can't finish the connection.
  app.get('/auth/gmail/callback', wrap(async (req, res) => {
    requireGmail();
    const state = verifyToken(String(req.query.state ?? ''), opts.tokenSecret);
    if (!state || state.purpose !== 'gmail-connect') {
      throw new AuthzError(400, 'this connection link is invalid or has expired');
    }
    if (req.query.error) return res.redirect(`${appUrl}/b/${state.biz}/settings?gmail=denied`);
    const membership = await identity.getMembership(state.uid, state.biz);
    if (!membership || !can(membership.role, 'integrations.manage')) {
      throw new AuthzError(403, 'you no longer have permission to connect Gmail for this business');
    }
    const code = String(req.query.code ?? '');
    if (!code) throw new AuthzError(400, 'missing authorization code');

    let refreshToken;
    let accessToken;
    let email;
    try {
      ({ refreshToken, accessToken } = await opts.gmailOAuth.exchangeCode(code));
      email = await opts.gmailOAuth.fetchEmail(accessToken);
    } catch {
      throw new AuthzError(502, 'Google rejected the connection, please try again');
    }
    await gmail.save({ businessId: state.biz, email, refreshToken, connectedBy: state.uid });
    await audit.record({ businessId: state.biz, actor: state.uid, action: 'gmail.connected', target: email });
    res.redirect(`${appUrl}/b/${state.biz}/settings?gmail=connected`);
  }));

  app.delete('/businesses/:bizId/gmail', ...authz.guard('integrations.manage'), wrap(async (req, res) => {
    requireGmail();
    const result = await gmail.disconnect(req.params.bizId);
    if (result.existed) {
      await audit.record({ businessId: req.params.bizId, actor: req.user.id, action: 'gmail.disconnected', target: result.email });
    }
    res.json({ connected: false });
  }));

  // Invoices and payments
  app.post('/businesses/:bizId/invoices', ...authz.guard('invoices.create'), writable, wrap(async (req, res) => {
    res.status(201).json(await invoices.createInvoice(req.params.bizId, req.body ?? {}, req.user.id, {
      limit: req.access.limits.invoicesPerMonth,
      monthStart: billing.monthStart()
    }));
  }));

  app.get('/businesses/:bizId/invoices', ...authz.guard('invoices.view'), wrap(async (req, res) => {
    res.json(await invoices.list(req.params.bizId));
  }));

  app.get('/businesses/:bizId/invoices/:no', ...authz.guard('invoices.view'), wrap(async (req, res) => {
    const inv = await invoices.getInvoice(req.params.bizId, req.params.no);
    if (!inv) throw new AuthzError(404, 'not found');
    res.json(inv);
  }));

  app.post('/businesses/:bizId/invoices/:no/email', ...authz.guard('invoices.create'), writable, wrap(async (req, res) => {
    const bizId = req.params.bizId;
    const inv = await invoices.getInvoice(bizId, req.params.no);
    if (!inv) throw new AuthzError(404, 'not found');
    if (!inv.clientEmail) throw new AuthzError(400, 'this invoice has no client email address');
    if (inv.status === 'Void') throw new AuthzError(409, 'void invoices cannot be sent');

    const biz = await identity.getBusiness(bizId);
    const payLink = `${apiUrl}/pay/${inv.paymentReference}`;
    const text = [
      `Hello ${inv.client},`,
      '',
      `Invoice INV-${pad(inv.no)} from ${biz.name} is ready.`,
      `Total: ${naira(inv.total)}`,
      `Due: ${inv.due ?? 'on receipt'}`,
      '',
      `Pay securely here: ${payLink}`,
      '',
      'Thank you,',
      biz.name
    ].join('\n');

    const delivery = await notifier.sendInvoice({
      businessId: bizId,
      email: inv.clientEmail,
      subject: `Invoice INV-${pad(inv.no)} from ${biz.name}`,
      text
    });
    if (!delivery.delivered) {
      throw new AuthzError(502, 'could not send the invoice. Check that a Gmail account is connected.');
    }
    await audit.record({ businessId: bizId, actor: req.user.id, action: 'invoice.emailed', target: `INV-${pad(inv.no)}` });
    res.json({ delivered: true, channel: delivery.channel });
  }));

  app.post('/businesses/:bizId/invoices/:no/void', ...authz.guard('invoices.void'), writable, wrap(async (req, res) => {
    res.json(await invoices.voidInvoice(req.params.bizId, req.params.no, req.user.id));
  }));

  app.post('/businesses/:bizId/invoices/:no/refund', ...authz.guard('payments.refund'), writable, wrap(async (req, res) => {
    res.json(await invoices.refund(req.params.bizId, req.params.no, req.body?.amount, req.user.id));
  }));

  // Hosted payment page for customers. Public, and gated only by the unguessable reference in the link.
  app.get('/pay/:ref', wrap(async (req, res) => {
    res.type('html').send(await payPages.render(req.params.ref));
  }));

  app.post('/pay/:ref', payLimiter, express.urlencoded({ extended: false }), wrap(async (req, res) => {
    const { authorizationUrl } = await payPages.startPayment(req.params.ref, req.body ?? {});
    res.redirect(303, authorizationUrl);
  }));

  app.get('/businesses/:bizId/ledger', ...authz.guard('reports.view'), wrap(async (req, res) => {
    res.json(await invoices.ledger(req.params.bizId));
  }));

  app.get('/businesses/:bizId/audit', ...authz.guard('audit.view'), wrap(async (req, res) => {
    res.json(await audit.list(req.params.bizId));
  }));

  app.use((err, req, res, _next) => {
    if (err instanceof AuthzError) return res.status(err.status).json({ error: err.message });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'invalid JSON' });
    if (err.code === '23505') return res.status(409).json({ error: 'that phone, email, or Google account is already in use' });
    console.error(err);
    res.status(500).json({ error: 'server error' });
  });

  return app;
}
