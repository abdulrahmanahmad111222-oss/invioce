import crypto from 'node:crypto';
import { ROLE_RANK, ASSIGNABLE_ROLES, can } from './permissions.js';
import { AuthzError } from './errors.js';
import { normalizePhone } from './phone.js';

const OTP_TTL = 5 * 60 * 1000;
const OTP_COOLDOWN = 60 * 1000;
const OTP_MAX_ATTEMPTS = 5;
const INVITE_TTL = 48 * 3600 * 1000;
const SESSION_TTL = 12 * 3600 * 1000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const randomId = () => crypto.randomBytes(8).toString('hex');
const otpHash = (phone, code) => sha256(`${phone}:${code}`);
const normEmail = (e) => (e ? String(e).trim().toLowerCase() : null);

export function createIdentity({ db, audit, otpSender, now = () => Date.now() }) {
  if (typeof otpSender !== 'function') throw new Error('otpSender is required');
  const date = (ms) => new Date(ms);

  async function getMembership(userId, businessId, c = db) {
    const r = await c.query(
      'SELECT business_id, user_id, role FROM memberships WHERE business_id = $1 AND user_id = $2',
      [businessId, userId]
    );
    const row = r.rows[0];
    return row ? { businessId: row.business_id, userId: row.user_id, role: row.role } : null;
  }

  async function actorWith(c, userId, businessId, permission) {
    const m = await getMembership(userId, businessId, c);
    if (!m) throw new AuthzError(404, 'not found');
    if (!can(m.role, permission)) throw new AuthzError(403, 'your role does not allow this action');
    return m;
  }

  async function targetFor(c, actor, businessId, targetUserId) {
    if (actor.userId === targetUserId) throw new AuthzError(403, 'you cannot change your own membership');
    const r = await c.query(
      `SELECT m.role, u.phone FROM memberships m JOIN users u ON u.id = m.user_id
        WHERE m.business_id = $1 AND m.user_id = $2 FOR UPDATE OF m`,
      [businessId, targetUserId]
    );
    if (!r.rows[0]) throw new AuthzError(404, 'member not found');
    const target = { role: r.rows[0].role, phone: r.rows[0].phone };
    if (target.role === 'owner') throw new AuthzError(403, 'the owner cannot be changed or removed');
    if (ROLE_RANK[actor.role] <= ROLE_RANK[target.role]) {
      throw new AuthzError(403, 'you can only manage members with a lower role than yours');
    }
    return target;
  }

  async function createSession(c, userId) {
    const sessionId = 'ses_' + randomId();
    await c.query('INSERT INTO sessions (id, user_id, expires_at) VALUES ($1, $2, $3)', [sessionId, userId, date(now() + SESSION_TTL)]);
    return sessionId;
  }

  // Checks a one-time code and burns it. Throws if the code is wrong, expired, or locked.
  async function consumeOtp(phone, code) {
    const r = await db.query(
      'UPDATE otp_codes SET attempts = attempts + 1 WHERE phone = $1 RETURNING code_hash, expires_at, attempts',
      [phone]
    );
    const entry = r.rows[0];
    if (!entry || now() > entry.expires_at.getTime()) throw new AuthzError(401, 'code expired or not requested');
    if (entry.attempts > OTP_MAX_ATTEMPTS) {
      await db.query('DELETE FROM otp_codes WHERE phone = $1', [phone]);
      throw new AuthzError(429, 'too many attempts, request a new code');
    }
    const given = Buffer.from(otpHash(phone, String(code ?? '')));
    const expected = Buffer.from(entry.code_hash);
    if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) {
      throw new AuthzError(401, 'incorrect code');
    }
    // A code works once. If two requests race, only one DELETE returns a row.
    const del = await db.query('DELETE FROM otp_codes WHERE phone = $1 RETURNING phone', [phone]);
    if (!del.rows[0]) throw new AuthzError(401, 'code expired or not requested');
  }

  return {
    async requestOtp(phoneInput) {
      const phone = normalizePhone(phoneInput);
      const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
      const t = now();
      // Atomic cooldown: the row is only overwritten if the last code is older than the cooldown.
      const r = await db.query(
        `INSERT INTO otp_codes (phone, code_hash, expires_at, attempts, sent_at)
         VALUES ($1, $2, $3, 0, $4)
         ON CONFLICT (phone) DO UPDATE
           SET code_hash = EXCLUDED.code_hash, expires_at = EXCLUDED.expires_at,
               attempts = 0, sent_at = EXCLUDED.sent_at
           WHERE otp_codes.sent_at <= $5
         RETURNING phone`,
        [phone, otpHash(phone, code), date(t + OTP_TTL), date(t), date(t - OTP_COOLDOWN)]
      );
      if (!r.rows[0]) throw new AuthzError(429, 'wait a minute before requesting another code');
      try {
        await otpSender(phone, code);
      } catch (err) {
        // Nothing reached the user, so don't make them wait out the cooldown.
        await db.query('DELETE FROM otp_codes WHERE phone = $1', [phone]);
        throw err;
      }
      return { sent: true };
    },

    async verifyOtp(phoneInput, code) {
      const phone = normalizePhone(phoneInput);
      await consumeOtp(phone, code);
      return db.tx(async (c) => {
        const u = await c.query(
          `INSERT INTO users (id, phone) VALUES ($1, $2)
           ON CONFLICT (phone) DO UPDATE SET phone = EXCLUDED.phone
           RETURNING id, phone, email`,
          ['usr_' + randomId(), phone]
        );
        const sessionId = await createSession(c, u.rows[0].id);
        return { user: { id: u.rows[0].id, phone: u.rows[0].phone, email: u.rows[0].email }, sessionId };
      });
    },

    // profile comes from the verified Google ID token: { sub, email, emailVerified, name }.
    async signInWithGoogle(profile) {
      if (!profile?.sub) throw new AuthzError(401, 'invalid Google sign-in');
      const email = profile.emailVerified ? normEmail(profile.email) : null;
      return db.tx(async (c) => {
        let user = (await c.query('SELECT id, phone, email FROM users WHERE google_sub = $1', [profile.sub])).rows[0];
        if (!user) {
          user = (await c.query(
            `INSERT INTO users (id, google_sub, email, name) VALUES ($1, $2, $3, $4)
             RETURNING id, phone, email`,
            ['usr_' + randomId(), profile.sub, email, profile.name ?? null]
          )).rows[0];
        }
        const sessionId = await createSession(c, user.id);
        return { user: { id: user.id, phone: user.phone, email: user.email }, sessionId };
      });
    },

    async linkGoogle(userId, profile) {
      if (!profile?.sub) throw new AuthzError(401, 'invalid Google sign-in');
      const email = profile.emailVerified ? normEmail(profile.email) : null;
      return db.tx(async (c) => {
        const me = (await c.query('SELECT google_sub FROM users WHERE id = $1 FOR UPDATE', [userId])).rows[0];
        if (me.google_sub) throw new AuthzError(409, 'this account already has a Google sign-in');
        // If the Google account belongs to another user, the unique constraint rejects it (mapped to 409).
        await c.query(
          'UPDATE users SET google_sub = $2, email = COALESCE($3, email), name = COALESCE(name, $4) WHERE id = $1',
          [userId, profile.sub, email, profile.name ?? null]
        );
        return { linked: 'google' };
      });
    },

    async linkPhone(userId, phoneInput, code) {
      const phone = normalizePhone(phoneInput);
      const me = (await db.query('SELECT phone FROM users WHERE id = $1', [userId])).rows[0];
      if (me.phone) throw new AuthzError(409, 'this account already has a phone number');
      await consumeOtp(phone, code);
      // If the number belongs to another account, the unique constraint rejects it (mapped to 409).
      await db.query('UPDATE users SET phone = $2 WHERE id = $1', [userId, phone]);
      return { linked: 'phone' };
    },

    async authenticate(sessionId) {
      const r = await db.query(
        `SELECT u.id, u.phone, u.email FROM sessions s JOIN users u ON u.id = s.user_id
          WHERE s.id = $1 AND NOT s.revoked AND s.expires_at > $2`,
        [sessionId ?? null, date(now())]
      );
      return r.rows[0] ? { id: r.rows[0].id, phone: r.rows[0].phone, email: r.rows[0].email } : null;
    },

    async logout(sessionId) {
      await db.query('UPDATE sessions SET revoked = true WHERE id = $1', [sessionId]);
    },

    async createBusiness(userId, name) {
      const clean = String(name ?? '').trim();
      if (clean.length < 2 || clean.length > 80) {
        throw new AuthzError(400, 'business name must be 2 to 80 characters');
      }
      const biz = { id: 'biz_' + randomId(), name: clean, ownerUserId: userId };
      await db.tx(async (c) => {
        await c.query('INSERT INTO businesses (id, name, owner_user_id) VALUES ($1, $2, $3)', [biz.id, biz.name, userId]);
        await c.query(`INSERT INTO memberships (business_id, user_id, role) VALUES ($1, $2, 'owner')`, [biz.id, userId]);
        await audit.record({ businessId: biz.id, actor: userId, action: 'business.created', target: biz.name }, c);
      });
      return biz;
    },

    async listMemberships(userId) {
      const r = await db.query(
        `SELECT b.id, b.name, b.owner_user_id, m.role
           FROM memberships m JOIN businesses b ON b.id = m.business_id
          WHERE m.user_id = $1 ORDER BY b.created_at`,
        [userId]
      );
      return r.rows.map((row) => ({
        business: { id: row.id, name: row.name, ownerUserId: row.owner_user_id },
        role: row.role
      }));
    },

    getMembership: (userId, businessId) => getMembership(userId, businessId),

    async listMembers(actorUserId, businessId) {
      await actorWith(db, actorUserId, businessId, 'members.manage');
      const r = await db.query(
        `SELECT m.user_id, u.phone, u.email, m.role FROM memberships m JOIN users u ON u.id = m.user_id
          WHERE m.business_id = $1 ORDER BY m.created_at`,
        [businessId]
      );
      return r.rows.map((row) => ({ userId: row.user_id, phone: row.phone, email: row.email, role: row.role }));
    },

    async createInvitation(actorUserId, businessId, input, { memberLimit = null } = {}) {
      const actor = await actorWith(db, actorUserId, businessId, 'members.invite');
      const { role } = input;
      if (!ASSIGNABLE_ROLES.includes(role)) {
        throw new AuthzError(400, 'role must be admin, manager, staff or accountant');
      }
      if (ROLE_RANK[role] >= ROLE_RANK[actor.role]) {
        throw new AuthzError(403, 'you can only invite roles below your own');
      }

      let phone = null;
      let email = null;
      if (input.email) {
        email = normEmail(input.email);
        if (!EMAIL_RE.test(email)) throw new AuthzError(400, 'email is not valid');
      } else if (input.phone) {
        phone = normalizePhone(input.phone);
      } else {
        throw new AuthzError(400, 'provide a phone number or an email address');
      }

      const existing = await db.query(
        `SELECT 1 FROM memberships m JOIN users u ON u.id = m.user_id
          WHERE m.business_id = $1 AND (($2::text IS NOT NULL AND u.phone = $2) OR ($3::text IS NOT NULL AND u.email = $3))`,
        [businessId, phone, email]
      );
      if (existing.rows[0]) throw new AuthzError(409, 'this person is already a member');

      const token = crypto.randomBytes(24).toString('base64url');
      const expiresAt = date(now() + INVITE_TTL);
      const target = phone ?? email;
      await db.tx(async (c) => {
        // Lock the business so concurrent invitations are counted one at a time against the limit.
        await c.query('SELECT 1 FROM businesses WHERE id = $1 FOR UPDATE', [businessId]);
        if (memberLimit !== null) {
          const used = (await c.query(
            `SELECT (SELECT count(*) FROM memberships WHERE business_id = $1)
                  + (SELECT count(*) FROM invitations WHERE business_id = $1 AND accepted_at IS NULL
                       AND NOT revoked AND expires_at > $2) AS n`,
            [businessId, date(now())]
          )).rows[0].n;
          if (used >= memberLimit) {
            throw new AuthzError(402, `your plan allows ${memberLimit} team members. Upgrade to add more.`);
          }
        }
        await c.query(
          `INSERT INTO invitations (token_hash, business_id, phone, email, role, invited_by, expires_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [sha256(token), businessId, phone, email, role, actorUserId, expiresAt]
        );
        await audit.record({ businessId, actor: actorUserId, action: 'member.invited', target, after: { role } }, c);
      });

      // Production: send the link by WhatsApp, SMS, or email instead of returning the token.
      return { invitation: { businessId, phone, email, role, expiresAt: expiresAt.toISOString() }, token };
    },

    async discardInvitation(businessId, rawToken) {
      await db.query('UPDATE invitations SET revoked = true WHERE token_hash = $1 AND business_id = $2', [sha256(String(rawToken)), businessId]);
    },

    async getBusiness(businessId) {
      const r = await db.query('SELECT id, name FROM businesses WHERE id = $1', [businessId]);
      return r.rows[0] ? { id: r.rows[0].id, name: r.rows[0].name } : null;
    },

    async acceptInvitation(userId, rawToken) {
      return db.tx(async (c) => {
        const inv = (await c.query('SELECT * FROM invitations WHERE token_hash = $1 FOR UPDATE', [sha256(String(rawToken ?? ''))])).rows[0];
        if (!inv || inv.revoked) throw new AuthzError(400, 'invitation is not valid');
        if (inv.accepted_at) throw new AuthzError(400, 'invitation has already been used');
        if (now() > inv.expires_at.getTime()) throw new AuthzError(400, 'invitation has expired');

        // Match on the verified phone or verified email the invitation was sent to.
        const user = (await c.query('SELECT phone, email FROM users WHERE id = $1', [userId])).rows[0];
        const matches = (inv.phone && user.phone === inv.phone) || (inv.email && user.email === inv.email);
        if (!matches) throw new AuthzError(403, 'this invitation was sent to a different account');

        const ins = await c.query(
          `INSERT INTO memberships (business_id, user_id, role, invited_by)
           VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING RETURNING role`,
          [inv.business_id, userId, inv.role, inv.invited_by]
        );
        if (!ins.rows[0]) throw new AuthzError(409, 'you are already a member');

        await c.query('UPDATE invitations SET accepted_at = $2 WHERE token_hash = $1', [inv.token_hash, date(now())]);
        await audit.record({
          businessId: inv.business_id, actor: userId, action: 'invite.accepted',
          target: user.phone ?? user.email, after: { role: inv.role }
        }, c);
        return { businessId: inv.business_id, role: inv.role };
      });
    },

    async changeRole(actorUserId, businessId, targetUserId, newRole) {
      return db.tx(async (c) => {
        const actor = await actorWith(c, actorUserId, businessId, 'members.manage');
        if (!ASSIGNABLE_ROLES.includes(newRole)) {
          throw new AuthzError(400, 'role must be admin, manager, staff or accountant');
        }
        const target = await targetFor(c, actor, businessId, targetUserId);
        if (ROLE_RANK[actor.role] <= ROLE_RANK[newRole]) {
          throw new AuthzError(403, 'you cannot grant a role equal to or above your own');
        }
        await c.query('UPDATE memberships SET role = $3 WHERE business_id = $1 AND user_id = $2', [businessId, targetUserId, newRole]);
        await audit.record({
          businessId, actor: actorUserId, action: 'member.role_changed', target: target.phone,
          before: { role: target.role }, after: { role: newRole }
        }, c);
        return { userId: targetUserId, role: newRole };
      });
    },

    async removeMember(actorUserId, businessId, targetUserId) {
      return db.tx(async (c) => {
        const actor = await actorWith(c, actorUserId, businessId, 'members.manage');
        const target = await targetFor(c, actor, businessId, targetUserId);
        // Access is checked against this row on every request, so removal takes effect immediately.
        await c.query('DELETE FROM memberships WHERE business_id = $1 AND user_id = $2', [businessId, targetUserId]);
        await audit.record({ businessId, actor: actorUserId, action: 'member.removed', target: target.phone, before: { role: target.role } }, c);
        return { removed: true };
      });
    }
  };
}
