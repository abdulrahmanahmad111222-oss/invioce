// Gmail sending for each business, through its own Google account (OAuth, gmail.send scope).
const GOOGLE_AUTH = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN = 'https://oauth2.googleapis.com/token';
const GOOGLE_REVOKE = 'https://oauth2.googleapis.com/revoke';
const GOOGLE_USERINFO = 'https://www.googleapis.com/oauth2/v3/userinfo';
const GMAIL_SEND = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send';
const SCOPES = ['https://www.googleapis.com/auth/gmail.send', 'email'];

export function createGoogleOAuth({ clientId, clientSecret, redirectUri, fetchImpl = fetch }) {
  if (!clientId || !clientSecret || !redirectUri) throw new Error('clientId, clientSecret and redirectUri are required');

  async function tokenRequest(params) {
    const res = await fetchImpl(GOOGLE_TOKEN, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, ...params }).toString()
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`Google token ${res.status}: ${json.error_description ?? json.error ?? 'request failed'}`);
    return json;
  }

  return {
    authorizationUrl(state) {
      const url = new URL(GOOGLE_AUTH);
      url.search = new URLSearchParams({
        client_id: clientId,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: SCOPES.join(' '),
        access_type: 'offline',   // needed for a refresh token
        prompt: 'consent',        // makes Google return a refresh token every time
        state
      }).toString();
      return url.toString();
    },

    async exchangeCode(code) {
      const json = await tokenRequest({ code, redirect_uri: redirectUri, grant_type: 'authorization_code' });
      if (!json.refresh_token) throw new Error('Google did not return a refresh token');
      return { refreshToken: json.refresh_token, accessToken: json.access_token };
    },

    async refreshAccessToken(refreshToken) {
      const json = await tokenRequest({ refresh_token: refreshToken, grant_type: 'refresh_token' });
      return json.access_token;
    },

    async revoke(token) {
      await fetchImpl(`${GOOGLE_REVOKE}?token=${encodeURIComponent(token)}`, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' }
      });
    },

    async fetchEmail(accessToken) {
      const res = await fetchImpl(GOOGLE_USERINFO, { headers: { Authorization: `Bearer ${accessToken}` } });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.email) throw new Error('could not read the Google account address');
      return json.email;
    }
  };
}

const encodeHeader = (s) => `=?UTF-8?B?${Buffer.from(s, 'utf8').toString('base64')}?=`;
const oneLine = (s) => String(s).replace(/[\r\n]+/g, ' ').trim();

// Builds the base64url RFC 2822 message that the Gmail API expects.
export function buildRawEmail({ from, to, subject, text }) {
  const headers = [
    `From: ${oneLine(from)}`,
    `To: ${oneLine(to)}`,
    `Subject: ${encodeHeader(oneLine(subject))}`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    ''
  ];
  const body = Buffer.from(text, 'utf8').toString('base64').replace(/.{1,76}/g, '$&\r\n');
  return Buffer.from([...headers, body].join('\r\n'), 'utf8').toString('base64url');
}

export function createGmailChannel({ fromEmail, getAccessToken, fetchImpl = fetch }) {
  async function send(to, subject, text) {
    const accessToken = await getAccessToken();
    const res = await fetchImpl(GMAIL_SEND, {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
      body: JSON.stringify({ raw: buildRawEmail({ from: fromEmail, to, subject, text }) })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`Gmail ${res.status}: ${json?.error?.message ?? 'request failed'}`);
    if (!json.id) throw new Error('Gmail did not return a message id');
    return json.id;
  }

  return {
    name: 'gmail',
    sendOtp() {
      throw new Error('Gmail is not used for sign-in codes');
    },
    sendInvitation(to, { link, businessName, role }) {
      return send(
        to,
        `Invitation to join ${businessName}`,
        `${businessName} invited you to join as ${role}.\n\nAccept within 48 hours: ${link}\n`
      );
    },
    sendInvoice(to, { subject, text }) {
      return send(to, subject, text);
    },
    sendNotice(to, { subject, text }) {
      return send(to, subject, text);
    }
  };
}

// Stores and loads each business's Gmail connection. Refresh tokens are encrypted with the box.
export function createGmailConnections({ db, oauth, box, fetchImpl = fetch }) {
  return {
    async channelsFor(businessId) {
      const r = await db.query('SELECT email, refresh_token_enc FROM business_gmail WHERE business_id = $1', [businessId]);
      const row = r.rows[0];
      if (!row) return [];
      const refreshToken = box.decrypt(row.refresh_token_enc);
      return [createGmailChannel({
        fromEmail: row.email,
        getAccessToken: () => oauth.refreshAccessToken(refreshToken),
        fetchImpl
      })];
    },

    async save({ businessId, email, refreshToken, connectedBy }) {
      await db.query(
        `INSERT INTO business_gmail (business_id, email, refresh_token_enc, connected_by)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (business_id) DO UPDATE
           SET email = EXCLUDED.email, refresh_token_enc = EXCLUDED.refresh_token_enc,
               connected_by = EXCLUDED.connected_by, connected_at = now()`,
        [businessId, email, box.encrypt(refreshToken), connectedBy]
      );
    },

    async status(businessId) {
      const r = await db.query('SELECT email, connected_at FROM business_gmail WHERE business_id = $1', [businessId]);
      const row = r.rows[0];
      return row ? { connected: true, email: row.email, connectedAt: row.connected_at } : { connected: false };
    },

    async disconnect(businessId) {
      const r = await db.query('DELETE FROM business_gmail WHERE business_id = $1 RETURNING email, refresh_token_enc', [businessId]);
      const row = r.rows[0];
      if (!row) return { existed: false };
      // Best effort: the local connection is already gone even if Google's revoke call fails.
      try { await oauth.revoke(box.decrypt(row.refresh_token_enc)); } catch { /* ignored */ }
      return { existed: true, email: row.email };
    }
  };
}
