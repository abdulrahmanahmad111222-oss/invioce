// Plans and prices. Amounts are in kobo. These figures are placeholders: set your own before launch.
// A null limit means unlimited.
export const PLANS = {
  starter: {
    name: 'Starter',
    prices: { monthly: 500000, yearly: 5000000 },           // ₦5,000 / ₦50,000
    limits: { members: 2, invoicesPerMonth: 30, gmail: false }
  },
  growth: {
    name: 'Growth',
    prices: { monthly: 1500000, yearly: 15000000 },         // ₦15,000 / ₦150,000
    limits: { members: 6, invoicesPerMonth: 300, gmail: true }
  },
  scale: {
    name: 'Scale',
    prices: { monthly: 4000000, yearly: 40000000 },         // ₦40,000 / ₦400,000
    limits: { members: 25, invoicesPerMonth: null, gmail: true }
  }
};

export const TRIAL_PLAN = 'growth';
