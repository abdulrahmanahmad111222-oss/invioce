import crypto from 'node:crypto';
import { AuthzError } from '../errors.js';
import { normalizeEmail } from '../email.js';
import { PLANS, TRIAL_PLAN } from './plans.js';

const DAY = 24 * 3600 * 1000;
const CLAIM_MS = 10 * 60 * 1000;      // a renewal attempt holds its claim this long
const ACTIVE = ['trialing', 'active', 'cancelled'];

export function createBilling({
  db, audit, box = null, paystack, appUrl = '', plans = PLANS,
  trialDays = 14, graceDays = 3, now = () => Date.now(), onPaymentFailed = null
}) {
  const at = (ms) => new Date(ms);
  const rand = () => crypto.randomBytes(8).toString('hex');
  const priceOf = (planKey, interval) => plans[planKey].prices[interval];
  const addInterval = (ms, interval) => {
    const d = new Date(ms);
    if (interval === 'yearly') d.setUTCFullYear(d.getUTCFullYear() + 1);
    else d.setUTCMonth(d.getUTCMonth() + 1);
    return d;
  };
  const monthStart = () => {
    const d = new Date(now());
    return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
  };

  // What the business may do right now.
  async function accessFor(bizId) {
    const r = await db.query('SELECT * FROM subscriptions WHERE business_id = $1', [bizId]);
    const s = r.rows[0];
    if (!s) {
      return { state: 'none', writable: false, plan: null, interval: null, periodEnd: null, graceUntil: null,
        limits: { members: 0, invoicesPerMonth: 0, gmail: false } };
    }
    const t = now();
    let state;
    if (ACTIVE.includes(s.status) && t <= s.current_period_end.getTime()) {
      state = s.status === 'trialing' ? 'trial' : s.status === 'cancelled' ? 'cancelled' : 'active';
    } else if (s.status === 'past_due' && s.grace_until && t <= s.grace_until.getTime()) {
      state = 'past_due';
    } else {
      state = 'expired';
    }
    return {
      state,
      writable: state !== 'expired',
      plan: s.plan,
      interval: s.interval,
      periodEnd: s.current_period_end,
      graceUntil: s.grace_until,
      limits: plans[s.plan].limits
    };
  }

  return {
    monthStart,

    accessFor,

    async requireWritable(bizId) {
      const access = await accessFor(bizId);
      if (!access.writable) {
        throw new AuthzError(402, 'your subscription has ended. Renew to keep making changes.');
      }
      return access;
    },

    async summary(bizId) {
      const access = await accessFor(bizId);
      const members = Number((await db.query(
        `SELECT (SELECT count(*) FROM memberships WHERE business_id = $1)
              + (SELECT count(*) FROM invitations WHERE business_id = $1 AND accepted_at IS NULL
                   AND NOT revoked AND expires_at > $2) AS n`,
        [bizId, at(now())]
      )).rows[0].n);
      const invoicesThisMonth = Number((await db.query(
        'SELECT count(*) AS n FROM invoices WHERE business_id = $1 AND created_at >= $2',
        [bizId, monthStart()]
      )).rows[0].n);
      return {
        ...access,
        usage: { members, invoicesThisMonth },
        plans: Object.entries(plans).map(([key, p]) => ({ key, name: p.name, prices: p.prices, limits: p.limits }))
      };
    },

    // Called when a business is created. The trial has the same features as the trial plan.
    async startTrial(bizId) {
      await db.query(
        `INSERT INTO subscriptions (business_id, plan, interval, status, current_period_end)
         VALUES ($1, $2, 'monthly', 'trialing', $3)
         ON CONFLICT (business_id) DO NOTHING`,
        [bizId, TRIAL_PLAN, at(now() + trialDays * DAY)]
      );
    },

    async startCheckout(bizId, input) {
      const { plan, interval } = input;
      if (!plans[plan]) throw new AuthzError(400, 'unknown plan');
      if (!['monthly', 'yearly'].includes(interval)) throw new AuthzError(400, 'interval must be monthly or yearly');
      const email = normalizeEmail(input.email);
      const biz = await db.query('SELECT 1 FROM businesses WHERE id = $1', [bizId]);
      if (!biz.rows[0]) throw new AuthzError(404, 'not found');

      const amount = priceOf(plan, interval);
      const reference = `sub_${rand()}${rand()}`;
      await db.query(
        `INSERT INTO subscription_payments (reference, business_id, plan, interval, amount, customer_email, status)
         VALUES ($1, $2, $3, $4, $5, $6, 'pending')`,
        [reference, bizId, plan, interval, amount, email]
      );
      const { authorizationUrl } = await paystack.initialize({
        email, amount, reference, callbackUrl: `${appUrl}/b/${bizId}/billing`
      });
      return { reference, amount, authorizationUrl };
    },

    // Marks a pending charge as paid and moves the subscription forward. Safe to call twice.
    async applyCharge({ reference, amount, currency, authorizationCode = null }) {
      if (currency !== 'NGN') return { status: 'wrong_currency' };
      return db.tx(async (c) => {
        const p = (await c.query('SELECT * FROM subscription_payments WHERE reference = $1 FOR UPDATE', [reference])).rows[0];
        if (!p) return { status: 'unknown_reference' };
        if (p.status === 'paid') return { status: 'duplicate' };
        if (p.amount !== amount) return { status: 'mismatch' };

        const t = now();
        const sub = (await c.query('SELECT * FROM subscriptions WHERE business_id = $1 FOR UPDATE', [p.business_id])).rows[0];
        // Paying for the same plan early adds to the current period. Anything else starts a new period today.
        const extendsCurrent = sub && sub.plan === p.plan && sub.interval === p.interval
          && sub.status === 'active' && sub.current_period_end.getTime() > t;
        const base = extendsCurrent ? sub.current_period_end.getTime() : t;
        const periodEnd = addInterval(base, p.interval);

        await c.query("UPDATE subscription_payments SET status = 'paid', period_end = $2 WHERE reference = $1", [reference, periodEnd]);
        await c.query(
          `INSERT INTO subscriptions (business_id, plan, interval, status, current_period_end, authorization_code_enc, customer_email)
           VALUES ($1, $2, $3, 'active', $4, $5, $6)
           ON CONFLICT (business_id) DO UPDATE SET
             plan = EXCLUDED.plan, interval = EXCLUDED.interval, status = 'active',
             current_period_end = EXCLUDED.current_period_end, grace_until = NULL,
             renewal_claimed_until = NULL, renewal_attempts = 0,
             authorization_code_enc = COALESCE(EXCLUDED.authorization_code_enc, subscriptions.authorization_code_enc),
             customer_email = COALESCE(EXCLUDED.customer_email, subscriptions.customer_email),
             updated_at = now()`,
          [p.business_id, p.plan, p.interval, periodEnd,
            authorizationCode && box ? box.encrypt(authorizationCode) : null, p.customer_email]
        );
        await audit.record({
          businessId: p.business_id, actor: 'system:paystack', action: 'subscription.paid',
          target: p.plan, after: { interval: p.interval, amount, periodEnd }
        }, c);
        return { status: 'applied', periodEnd };
      });
    },

    // Called by the webhook for checkout payments. Paystack confirms the amount before anything changes.
    async applyFromWebhook({ reference, amount, currency, verify }) {
      const confirmed = await verify();
      if (!confirmed) return { status: 'not_confirmed' };
      if (confirmed.amount !== amount || confirmed.currency !== currency) return { status: 'mismatch' };
      return this.applyCharge({ reference, amount, currency, authorizationCode: confirmed.authorizationCode });
    },

    async cancel(bizId, actorUserId) {
      const r = await db.query(
        `UPDATE subscriptions SET status = 'cancelled', authorization_code_enc = NULL,
                renewal_claimed_until = NULL, updated_at = now()
          WHERE business_id = $1 AND status IN ('trialing', 'active', 'past_due')
          RETURNING current_period_end`,
        [bizId]
      );
      if (!r.rows[0]) throw new AuthzError(409, 'there is no active subscription to cancel');
      await audit.record({ businessId: bizId, actor: actorUserId, action: 'subscription.cancelled' });
      return { accessUntil: r.rows[0].current_period_end };
    },

    // Runs once a day (scripts/renew.js). Charges saved cards for subscriptions whose period has ended.
    async runRenewals() {
      if (!box) throw new Error('renewals need an encryption key to read saved cards');
      const t = now();
      await db.query(
        "UPDATE subscriptions SET status = 'suspended', updated_at = now() WHERE status = 'past_due' AND grace_until < $1",
        [at(t)]
      );
      const due = await db.query(
        `SELECT business_id FROM subscriptions
          WHERE status IN ('active', 'past_due') AND authorization_code_enc IS NOT NULL
            AND current_period_end <= $1
            AND (renewal_claimed_until IS NULL OR renewal_claimed_until < $1)`,
        [at(t)]
      );

      const summary = { charged: 0, failed: 0, skipped: 0 };
      for (const { business_id: bizId } of due.rows) {
        const claim = await claimRenewal(bizId);
        if (!claim) { summary.skipped++; continue; }

        const result = await paystack.charge({
          email: claim.email, amount: claim.amount, authorizationCode: claim.authorizationCode, reference: claim.reference
        });
        if (result.status === 'success') {
          await this.applyCharge({ reference: claim.reference, amount: claim.amount, currency: 'NGN' });
          summary.charged++;
        } else {
          const { firstFailure, graceUntil } = await markRenewalFailed(bizId, claim.reference);
          summary.failed++;
          // Notify once per failure period, not on every retry. A notice failure never blocks billing.
          if (firstFailure && onPaymentFailed) {
            await onPaymentFailed({ businessId: bizId, graceUntil }).catch(() => {});
          }
        }
      }
      return summary;
    }
  };

  // Reserves one renewal attempt under a row lock, so overlapping runs can't both charge.
  async function claimRenewal(bizId) {
    return db.tx(async (c) => {
      const s = (await c.query('SELECT * FROM subscriptions WHERE business_id = $1 FOR UPDATE', [bizId])).rows[0];
      const t = now();
      if (!s || !['active', 'past_due'].includes(s.status) || !s.authorization_code_enc) return null;
      if (s.current_period_end.getTime() > t) return null;
      if (s.renewal_claimed_until && s.renewal_claimed_until.getTime() > t) return null;

      const attempt = s.renewal_attempts + 1;
      const reference = `sub_ren_${bizId}_${s.current_period_end.getTime()}_${attempt}`;
      const amount = priceOf(s.plan, s.interval);
      await c.query(
        'UPDATE subscriptions SET renewal_attempts = $2, renewal_claimed_until = $3 WHERE business_id = $1',
        [bizId, attempt, at(t + CLAIM_MS)]
      );
      await c.query(
        `INSERT INTO subscription_payments (reference, business_id, plan, interval, amount, customer_email, status)
         VALUES ($1, $2, $3, $4, $5, $6, 'pending')`,
        [reference, bizId, s.plan, s.interval, amount, s.customer_email]
      );
      return { reference, amount, email: s.customer_email, authorizationCode: box.decrypt(s.authorization_code_enc) };
    });
  }

  async function markRenewalFailed(bizId, reference) {
    return db.tx(async (c) => {
      await c.query("UPDATE subscription_payments SET status = 'failed' WHERE reference = $1", [reference]);
      const before = (await c.query('SELECT status FROM subscriptions WHERE business_id = $1 FOR UPDATE', [bizId])).rows[0];
      const graceUntil = now() + graceDays * DAY;
      // The grace period starts at the first failure and isn't extended by later retries.
      const r = await c.query(
        `UPDATE subscriptions SET status = 'past_due', renewal_claimed_until = NULL,
                grace_until = COALESCE(grace_until, $2), updated_at = now()
          WHERE business_id = $1 RETURNING grace_until`,
        [bizId, at(graceUntil)]
      );
      return { firstFailure: before.status !== 'past_due', graceUntil: r.rows[0].grace_until };
    });
  }
}
