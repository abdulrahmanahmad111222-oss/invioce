import crypto from 'node:crypto';
import { AuthzError } from './errors.js';
import { normalizeEmail } from './email.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const naira = (kobo) => '₦' + (kobo / 100).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const pad = (n) => String(n).padStart(4, '0');

const STYLE = `
  body{margin:0;font:16px/1.5 system-ui,-apple-system,sans-serif;background:#eef3f0;color:#17302a}
  main{max-width:640px;margin:0 auto;padding:24px 16px}
  .card{background:#fff;border:1px solid #d5dfd9;border-radius:12px;padding:24px}
  h1{font-size:22px;margin:0 0 4px} .muted{color:#5d6f69}
  table{width:100%;border-collapse:collapse;margin:16px 0} th,td{padding:8px 0;border-bottom:1px solid #d5dfd9;text-align:left}
  .r{text-align:right} .total{font-weight:700;font-size:18px}
  label{display:block;margin:16px 0 8px;font-weight:500} input{width:100%;padding:12px;border:1px solid #d5dfd9;border-radius:8px;font:inherit;box-sizing:border-box}
  button{width:100%;margin-top:16px;padding:14px;border:0;border-radius:8px;background:#0f5f4a;color:#fff;font:600 16px system-ui,sans-serif;cursor:pointer}
  .notice{padding:12px;border-radius:8px;background:#fdf1d8;margin:16px 0} .ok{background:#e3f4ea}
`;

function page(title, body) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">` +
    `<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title)}</title>` +
    `<style>${STYLE}</style></head><body><main><div class="card">${body}</div></main></body></html>`;
}

// Public payment pages. Anyone with the link can see the invoice and pay it. The link is a random, unguessable reference.
export function createPaymentPages({ db, paystack, apiUrl }) {
  async function loadByReference(ref) {
    const r = await db.query(
      `SELECT i.*, b.name AS business_name FROM invoices i
         JOIN businesses b ON b.id = i.business_id
        WHERE i.payment_reference = $1`,
      [String(ref)]
    );
    if (!r.rows[0]) throw new AuthzError(404, 'payment link not found');
    return r.rows[0];
  }

  return {
    async render(ref) {
      const inv = await loadByReference(ref);
      const balance = inv.total - inv.paid;
      const rows = inv.lines.map((l) =>
        `<tr><td>${esc(l.desc)}</td><td class="r">${esc(l.qty)}</td><td class="r">${naira(Math.round(l.qty * l.price * 100))}</td></tr>`
      ).join('');

      let action;
      if (inv.status === 'Void') {
        action = '<div class="notice">This invoice has been cancelled.</div>';
      } else if (balance <= 0) {
        action = '<div class="notice ok">Paid. Thank you.</div>';
      } else {
        const emailField = inv.client_email ? '' :
          '<label for="email">Your email for the receipt</label><input id="email" type="email" name="email" required>';
        action = `<form method="post" action="/pay/${esc(ref)}">${emailField}` +
          `<button type="submit">Pay ${naira(balance)}</button></form>`;
      }

      const body = `
        <p class="muted">${esc(inv.business_name)}</p>
        <h1>Invoice INV-${pad(inv.no)}</h1>
        <p class="muted">Billed to ${esc(inv.client)}${inv.due ? ` · Due ${esc(inv.due)}` : ''}</p>
        <table>
          <thead><tr><th>Item</th><th class="r">Qty</th><th class="r">Amount</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
        <table>
          <tr><td>Subtotal</td><td class="r">${naira(inv.subtotal)}</td></tr>
          ${inv.vat ? `<tr><td>VAT 7.5%</td><td class="r">${naira(inv.tax)}</td></tr>` : ''}
          <tr class="total"><td>Total</td><td class="r">${naira(inv.total)}</td></tr>
          ${inv.paid > 0 ? `<tr><td>Paid</td><td class="r">${naira(inv.paid)}</td></tr>` : ''}
          <tr class="total"><td>Balance due</td><td class="r">${naira(Math.max(balance, 0))}</td></tr>
        </table>
        ${action}`;
      return page(`Invoice INV-${pad(inv.no)} from ${inv.business_name}`, body);
    },

    async startPayment(ref, input = {}) {
      const inv = await loadByReference(ref);
      if (inv.status === 'Void') throw new AuthzError(409, 'this invoice has been cancelled');
      const balance = inv.total - inv.paid;
      if (balance <= 0) throw new AuthzError(409, 'this invoice is already paid');

      const email = inv.client_email ?? normalizeEmail(input.email);
      // A new reference for every attempt. Paystack rejects a reference it has already seen.
      const reference = 'pay_' + crypto.randomBytes(10).toString('hex');
      await db.query(
        'INSERT INTO payment_attempts (reference, invoice_id, amount, email) VALUES ($1, $2, $3, $4)',
        [reference, inv.id, balance, email]
      );
      const { authorizationUrl } = await paystack.initialize({
        email, amount: balance, reference, callbackUrl: `${apiUrl}/pay/${ref}`
      });
      return { authorizationUrl };
    }
  };
}
