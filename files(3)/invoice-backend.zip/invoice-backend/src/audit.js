// Append-only log, backed by the audit_log table.
// The database trigger rejects UPDATE and DELETE, so entries can't be changed.
export function createAudit({ db }) {
  return {
    async record(entry, c = db) {
      await c.query(
        `INSERT INTO audit_log (business_id, actor, action, target, before, after)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          entry.businessId ?? null,
          entry.actor ?? null,
          entry.action,
          entry.target ?? null,
          entry.before ? JSON.stringify(entry.before) : null,
          entry.after ? JSON.stringify(entry.after) : null
        ]
      );
    },
    async list(businessId) {
      const r = await db.query(
        `SELECT id, business_id, actor, action, target, before, after, created_at
           FROM audit_log WHERE business_id = $1 ORDER BY id`,
        [businessId]
      );
      return r.rows.map((row) => ({
        id: row.id,
        businessId: row.business_id,
        actor: row.actor,
        action: row.action,
        target: row.target,
        before: row.before,
        after: row.after,
        at: row.created_at
      }));
    }
  };
}
