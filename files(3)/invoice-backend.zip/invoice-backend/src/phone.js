import { AuthzError } from './errors.js';

// Accepts 0XXXXXXXXXX or 234XXXXXXXXXX and returns 234XXXXXXXXXX.
export function normalizePhone(input) {
  const d = String(input ?? '').replace(/\D/g, '');
  if (/^0\d{10}$/.test(d)) return '234' + d.slice(1);
  if (/^234\d{10}$/.test(d)) return d;
  throw new AuthzError(400, 'phone must be a valid Nigerian number');
}
