import crypto from 'node:crypto';
import { invoiceTotals, feeFor } from './money.js';
import { AuthzError } from './errors.js';
import { normalizePhone } from './phone.js';
import { normalizeEmail } from './email.js';

const pad = (n) => String(n).padStart(4, '0');
const randomRef = (prefix) => prefix + crypto.randomBytes(6).toString('hex');

function toInvoice(r) {
  return {
    businessId: r.business_id,
    no: r.no,
    client: r.client,
    clientEmail: r.client_email,
    phone: r.phone,
    due: r.due,
    lines: r.lines,
    vat: r.vat,
    subtotal: r.subtotal,
    tax: r.tax,
    total: r.total,
    paid: r.paid,
    status: r.status,
    paymentReference: r.payment_reference
  };
}

export function createInvoiceStore({ db, audit }) {
  // Locks one invoice row for the rest of the transaction.
  async function lockInvoice(c, businessId, no) {
    const n = Number(no);
    const r = Number.isInteger(n)
      ? await c.query('SELECT * FROM invoices WHERE business_id = $1 AND no = $2 FOR UPDATE', [businessId, n])
      : { rows: [] };
    if (!r.rows[0]) throw new AuthzError(404, 'not found');
    return r.rows[0];
  }

  function validateLines(input) {
    const lines = (input.lines ?? []).map((l) => ({
      desc: String(l.desc ?? '').trim(),
      qty: Number(l.qty),
      price: Number(l.price)
    }));
    if (!lines.length) throw new AuthzError(400, 'at least one line is required');
    for (const l of lines) {
      if (!l.desc) throw new AuthzError(400, 'every line needs a description');
      if (!(l.qty > 0)) throw new AuthzError(400, 'quantity must be greater than 0');
      if (!(l.price > 0)) throw new AuthzError(400, 'price must be greater than 0');
    }
    return lines;
  }

  // Resolves a payment reference to an invoice: either the invoice's own reference, or a payment attempt's.
  async function resolveInvoiceId(q, reference) {
    const r = await q.query(
      `SELECT id FROM invoices WHERE payment_reference = $1
       UNION ALL
       SELECT invoice_id AS id FROM payment_attempts WHERE reference = $1
       LIMIT 1`,
      [reference]
    );
    return r.rows[0]?.id ?? null;
  }

  return {
    async createInvoice(businessId, input, actor, { limit = null, monthStart = null } = {}) {
      const client = String(input.client ?? '').trim();
      if (!client) throw new AuthzError(400, 'client is required');
      const phone = normalizePhone(input.phone);
      const clientEmail = input.clientEmail ? normalizeEmail(input.clientEmail) : null;
      const lines = validateLines(input);
      const due = input.due || null;
      if (due !== null && !/^\d{4}-\d{2}-\d{2}$/.test(due)) throw new AuthzError(400, 'due must be YYYY-MM-DD');
      const totals = invoiceTotals(lines, Boolean(input.vat));

      return db.tx(async (c) => {
        // Lock the business so concurrent creates are counted one at a time against the limit.
        await c.query('SELECT 1 FROM businesses WHERE id = $1 FOR UPDATE', [businessId]);
        if (limit !== null && monthStart) {
          const used = (await c.query(
            'SELECT count(*) AS n FROM invoices WHERE business_id = $1 AND created_at >= $2',
            [businessId, monthStart]
          )).rows[0].n;
          if (used >= limit) {
            throw new AuthzError(402, `your plan allows ${limit} invoices per month. Upgrade to create more.`);
          }
        }
        // Atomic per-business numbering. Concurrent creates queue on this row.
        const counter = await c.query(
          `INSERT INTO invoice_counters (business_id, last_no) VALUES ($1, 1)
           ON CONFLICT (business_id) DO UPDATE SET last_no = invoice_counters.last_no + 1
           RETURNING last_no`,
          [businessId]
        );
        const r = await c.query(
          `INSERT INTO invoices
             (business_id, no, client, client_email, phone, due, lines, vat, subtotal, tax, total, paid, status, payment_reference)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 0, 'Unpaid', $12)
           RETURNING *`,
          [businessId, counter.rows[0].last_no, client, clientEmail, phone, due, JSON.stringify(lines),
            Boolean(input.vat), totals.subtotal, totals.tax, totals.total, randomRef('inv_')]
        );
        const inv = toInvoice(r.rows[0]);
        await audit.record({
          businessId, actor, action: 'invoice.created', target: `INV-${pad(inv.no)}`, after: { total: inv.total }
        }, c);
        return inv;
      });
    },

    async list(businessId, { limit = 200 } = {}) {
      const r = await db.query('SELECT * FROM invoices WHERE business_id = $1 ORDER BY no DESC LIMIT $2', [businessId, limit]);
      return r.rows.map(toInvoice);
    },

    async getInvoice(businessId, no) {
      const n = Number(no);
      if (!Number.isInteger(n)) return null;
      const r = await db.query('SELECT * FROM invoices WHERE business_id = $1 AND no = $2', [businessId, n]);
      return r.rows[0] ? toInvoice(r.rows[0]) : null;
    },

    async voidInvoice(businessId, no, actor) {
      return db.tx(async (c) => {
        const row = await lockInvoice(c, businessId, no);
        if (row.status === 'Void') throw new AuthzError(409, 'invoice is already void');
        if (row.paid > 0) throw new AuthzError(409, 'invoice has payments, issue a refund instead');
        const r = await c.query("UPDATE invoices SET status = 'Void' WHERE id = $1 RETURNING *", [row.id]);
        await audit.record({ businessId, actor, action: 'invoice.voided', target: `INV-${pad(row.no)}` }, c);
        return toInvoice(r.rows[0]);
      });
    },

    // Records a manual refund. In production, call the provider's refund API first,
    // then record the refund it confirms.
    async refund(businessId, no, amount, actor) {
      if (!Number.isInteger(amount) || amount <= 0) {
        throw new AuthzError(400, 'refund amount must be a whole number of kobo greater than 0');
      }
      return db.tx(async (c) => {
        const row = await lockInvoice(c, businessId, no);
        if (amount > row.paid) throw new AuthzError(400, 'refund is more than the amount paid');
        const paid = row.paid - amount;
        const status = paid === 0 ? 'Unpaid' : paid >= row.total ? 'Paid' : 'Partly paid';
        const r = await c.query('UPDATE invoices SET paid = $2, status = $3 WHERE id = $1 RETURNING *', [row.id, paid, status]);
        await c.query(
          `INSERT INTO ledger_entries (business_id, invoice_id, ref, provider, type, gross, fee, net)
           VALUES ($1, $2, $3, 'manual', 'refund', $4, 0, $4)`,
          [businessId, row.id, randomRef('refund_'), -amount]
        );
        await audit.record({ businessId, actor, action: 'invoice.refunded', target: `INV-${pad(row.no)}`, after: { amount } }, c);
        return toInvoice(r.rows[0]);
      });
    },

    // Called by the webhook handler. Payments are matched by reference, not by business.
    async applyPayment({ providerEventId, reference, amount, currency, provider, verify }) {
      const seen = await db.query('SELECT 1 FROM payment_events WHERE provider_event_id = $1', [providerEventId]);
      if (seen.rows[0]) return { status: 'duplicate' };

      const preId = await resolveInvoiceId(db, reference);
      if (!preId) return { status: 'unknown_reference' };
      const pre = (await db.query('SELECT status FROM invoices WHERE id = $1', [preId])).rows[0];
      if (pre.status === 'Void') return { status: 'invoice_void' };
      if (currency !== 'NGN') return { status: 'wrong_currency' };
      if (!Number.isInteger(amount) || amount <= 0) return { status: 'invalid_amount' };

      // Never trust the webhook body alone: confirm with the provider before changing anything.
      const confirmed = await verify();
      if (!confirmed) return { status: 'not_confirmed' };
      if (confirmed.amount !== amount || confirmed.currency !== currency) return { status: 'mismatch' };

      return db.tx(async (c) => {
        // Lock the invoice first, then record the event. The event's primary key
        // is the final guard against double-counting.
        const id = await resolveInvoiceId(c, reference);
        const inv = (await c.query('SELECT * FROM invoices WHERE id = $1 FOR UPDATE', [id])).rows[0];
        if (inv.status === 'Void') return { status: 'invoice_void' };

        const ins = await c.query(
          `INSERT INTO payment_events (provider_event_id, provider, invoice_id, amount)
           VALUES ($1, $2, $3, $4) ON CONFLICT (provider_event_id) DO NOTHING
           RETURNING provider_event_id`,
          [providerEventId, provider, inv.id, amount]
        );
        if (!ins.rows[0]) return { status: 'duplicate' };

        const paid = inv.paid + amount;
        const status = paid >= inv.total ? 'Paid' : 'Partly paid';
        const up = await c.query('UPDATE invoices SET paid = $2, status = $3 WHERE id = $1 RETURNING *', [inv.id, paid, status]);
        const fee = feeFor(amount);
        await c.query(
          `INSERT INTO ledger_entries (business_id, invoice_id, ref, provider, type, gross, fee, net)
           VALUES ($1, $2, $3, $4, 'payment', $5, $6, $7)`,
          [inv.business_id, inv.id, providerEventId, provider, amount, fee, amount - fee]
        );
        await audit.record({
          businessId: inv.business_id, actor: `system:${provider}`, action: 'payment.applied',
          target: `INV-${pad(inv.no)}`, after: { amount }
        }, c);
        return { status: 'applied', invoice: toInvoice(up.rows[0]) };
      });
    },

    async ledger(businessId) {
      const r = await db.query(
        `SELECT l.ref, l.provider, l.type, l.gross, l.fee, l.net, i.no AS invoice_no
           FROM ledger_entries l JOIN invoices i ON i.id = l.invoice_id
          WHERE l.business_id = $1 ORDER BY l.id DESC`,
        [businessId]
      );
      return r.rows.map((row) => ({
        ref: row.ref, provider: row.provider, type: row.type, invoiceNo: row.invoice_no,
        gross: row.gross, fee: row.fee, net: row.net
      }));
    }
  };
}
