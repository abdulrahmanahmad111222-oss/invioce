import { AuthzError } from './errors.js';

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Lowercases and validates an address. Whitespace and line breaks fail the check,
// which blocks header injection when the address is later used in an email header.
export function normalizeEmail(input) {
  const email = String(input ?? '').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) throw new AuthzError(400, 'email is not valid');
  return email;
}
