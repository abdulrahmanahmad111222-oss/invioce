-- A user can sign in with a phone number, a Google account, or both.
ALTER TABLE users ALTER COLUMN phone DROP NOT NULL;
ALTER TABLE users ADD COLUMN google_sub text UNIQUE;
ALTER TABLE users ADD COLUMN email text;
ALTER TABLE users ADD COLUMN name text;
ALTER TABLE users ADD CONSTRAINT users_has_identity CHECK (phone IS NOT NULL OR google_sub IS NOT NULL);
-- Only emails that Google has verified are stored, and each email belongs to one account.
CREATE UNIQUE INDEX users_email_key ON users (lower(email)) WHERE email IS NOT NULL;

-- Invitations can target a phone number or a verified email.
ALTER TABLE invitations ALTER COLUMN phone DROP NOT NULL;
ALTER TABLE invitations ADD COLUMN email text;
ALTER TABLE invitations ADD CONSTRAINT invitations_has_target CHECK (phone IS NOT NULL OR email IS NOT NULL);
