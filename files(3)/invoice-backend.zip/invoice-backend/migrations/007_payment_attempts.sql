-- Each time a customer starts a payment, Paystack gets a new unique reference, which maps back to the invoice.
CREATE TABLE payment_attempts (
  reference   text PRIMARY KEY,
  invoice_id  bigint NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  amount      bigint NOT NULL CHECK (amount > 0),
  email       text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
