-- Each business connects its own Gmail account. The refresh token is stored encrypted.
CREATE TABLE business_gmail (
  business_id       text PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  email             text NOT NULL,
  refresh_token_enc text NOT NULL,
  connected_by      text NOT NULL REFERENCES users(id),
  connected_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE invoices ADD COLUMN client_email text;

ALTER TABLE notifications DROP CONSTRAINT notifications_purpose_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_purpose_check
  CHECK (purpose IN ('otp', 'invitation', 'invoice'));
