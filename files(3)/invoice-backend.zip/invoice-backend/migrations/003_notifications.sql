-- One row per delivery attempt. Codes and full recipients are never stored here.
CREATE TABLE notifications (
  id                  bigserial PRIMARY KEY,
  purpose             text NOT NULL CHECK (purpose IN ('otp','invitation')),
  channel             text NOT NULL,
  recipient_hint      text NOT NULL,
  status              text NOT NULL CHECK (status IN ('sent','failed')),
  provider_message_id text,
  error               text,
  created_at          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_created_idx ON notifications (created_at);
