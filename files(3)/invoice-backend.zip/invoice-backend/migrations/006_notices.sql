-- Owner notices, such as failed subscription renewals.
ALTER TABLE notifications DROP CONSTRAINT notifications_purpose_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_purpose_check
  CHECK (purpose IN ('otp', 'invitation', 'invoice', 'notice'));
