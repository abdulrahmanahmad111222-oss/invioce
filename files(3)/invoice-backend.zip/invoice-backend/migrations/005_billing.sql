-- One subscription per business.
CREATE TABLE subscriptions (
  business_id            text PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  plan                   text NOT NULL,
  interval               text NOT NULL CHECK (interval IN ('monthly','yearly')),
  status                 text NOT NULL CHECK (status IN ('trialing','active','past_due','cancelled','suspended')),
  current_period_end     timestamptz NOT NULL,
  grace_until            timestamptz,
  authorization_code_enc text,
  customer_email         text,
  renewal_attempts       integer NOT NULL DEFAULT 0,
  renewal_claimed_until  timestamptz,
  updated_at             timestamptz NOT NULL DEFAULT now()
);

-- Every subscription charge: checkouts and renewals. The reference is unique, so a charge can't be recorded twice.
CREATE TABLE subscription_payments (
  reference       text PRIMARY KEY,
  business_id     text NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  plan            text NOT NULL,
  interval        text NOT NULL,
  amount          bigint NOT NULL CHECK (amount > 0),
  customer_email  text,
  status          text NOT NULL CHECK (status IN ('pending','paid','failed')),
  period_end      timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX subscription_payments_business_idx ON subscription_payments (business_id, created_at);

ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_plan_valid CHECK (plan IN ('starter','growth','scale'));
