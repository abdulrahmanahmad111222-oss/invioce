-- Users and sign-in
CREATE TABLE users (
  id          text PRIMARY KEY,
  phone       text NOT NULL UNIQUE,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE otp_codes (
  phone       text PRIMARY KEY,
  code_hash   text NOT NULL,
  expires_at  timestamptz NOT NULL,
  attempts    integer NOT NULL DEFAULT 0,
  sent_at     timestamptz NOT NULL
);

CREATE TABLE sessions (
  id          text PRIMARY KEY,
  user_id     text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at  timestamptz NOT NULL,
  revoked     boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Businesses and team
CREATE TABLE businesses (
  id             text PRIMARY KEY,
  name           text NOT NULL,
  owner_user_id  text NOT NULL REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
  business_id  text NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id      text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role         text NOT NULL CHECK (role IN ('owner','admin','manager','staff','accountant')),
  invited_by   text REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, user_id)
);

-- Exactly one owner per business, enforced by the database itself.
CREATE UNIQUE INDEX one_owner_per_business ON memberships (business_id) WHERE role = 'owner';

CREATE TABLE invitations (
  token_hash   text PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  phone        text NOT NULL,
  role         text NOT NULL CHECK (role IN ('admin','manager','staff','accountant')),
  invited_by   text NOT NULL REFERENCES users(id),
  expires_at   timestamptz NOT NULL,
  accepted_at  timestamptz,
  revoked      boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- Invoices and money
CREATE TABLE invoice_counters (
  business_id  text PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  last_no      integer NOT NULL DEFAULT 0
);

CREATE TABLE invoices (
  id                 bigserial PRIMARY KEY,
  business_id        text NOT NULL REFERENCES businesses(id),
  no                 integer NOT NULL,
  client             text NOT NULL,
  phone              text NOT NULL,
  due                text,
  lines              jsonb NOT NULL,
  vat                boolean NOT NULL,
  subtotal           bigint NOT NULL CHECK (subtotal >= 0),
  tax                bigint NOT NULL CHECK (tax >= 0),
  total              bigint NOT NULL CHECK (total > 0),
  paid               bigint NOT NULL DEFAULT 0 CHECK (paid >= 0),
  status             text NOT NULL CHECK (status IN ('Unpaid','Partly paid','Paid','Void')),
  payment_reference  text NOT NULL UNIQUE,
  created_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, no)
);

-- One row per provider event. The primary key is what stops double-counting.
CREATE TABLE payment_events (
  provider_event_id  text PRIMARY KEY,
  provider           text NOT NULL,
  invoice_id         bigint NOT NULL REFERENCES invoices(id),
  amount             bigint NOT NULL CHECK (amount > 0),
  received_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ledger_entries (
  id          bigserial PRIMARY KEY,
  business_id text NOT NULL REFERENCES businesses(id),
  invoice_id  bigint NOT NULL REFERENCES invoices(id),
  ref         text NOT NULL,
  provider    text NOT NULL,
  type        text NOT NULL CHECK (type IN ('payment','refund')),
  gross       bigint NOT NULL,
  fee         bigint NOT NULL,
  net         bigint NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Append-only audit log. The trigger rejects any UPDATE or DELETE.
CREATE TABLE audit_log (
  id           bigserial PRIMARY KEY,
  business_id  text,
  actor        text,
  action       text NOT NULL,
  target       text,
  before       jsonb,
  after        jsonb,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE FUNCTION audit_log_is_append_only() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_log is append-only';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_log_no_update_delete
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION audit_log_is_append_only();

CREATE INDEX audit_log_business_idx ON audit_log (business_id, id);
CREATE INDEX invoices_business_idx ON invoices (business_id, no);
CREATE INDEX ledger_business_idx ON ledger_entries (business_id, id);
